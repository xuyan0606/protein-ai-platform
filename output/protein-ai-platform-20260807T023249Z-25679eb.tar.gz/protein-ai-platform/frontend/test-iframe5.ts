import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Login on frontend
  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Go to wiki
  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(5000);

  const iframe = await page.$('iframe');
  const frame = await iframe.contentFrame();
  
  console.log('Iframe URL:', frame.url());
  console.log('Iframe Title:', await frame.title());
  
  // Check for Outline sidebar elements
  const homeLink = await frame.$('a[href*="/home"], span:has-text("Home")');
  const newDocBtn = await frame.$('button:has-text("New"), a:has-text("New document")');
  const collections = await frame.$('text=Collections');
  
  console.log('Home link found:', !!homeLink);
  console.log('New doc button found:', !!newDocBtn);
  console.log('Collections found:', !!collections);
  
  // Check for dashboard elements
  const bodyText = await frame.textContent('body');
  if (bodyText.includes('Home') && !bodyText.includes('Continue with')) {
    console.log('\n✅ SUCCESS: Outline dashboard loaded, user is authenticated');
  } else if (bodyText.includes('Continue with')) {
    console.log('\n❌ FAIL: Still on login page');
  } else {
    console.log('\n⚠️  UNKNOWN state');
  }
  
  await page.screenshot({ path: '/tmp/wiki-final-verify.png', fullPage: true });
  await browser.close();
  console.log('Done');
})();
