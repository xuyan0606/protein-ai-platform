import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Step 1: Login
  console.log('1. Login via API to get pa_token cookie on localhost:8000...');
  await page.goto('http://localhost:8000/api/health', { waitUntil: 'networkidle' });
  
  // Login via fetch to set the cookie
  await page.evaluate(async () => {
    await fetch('http://localhost:8000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@protein.ai', password: 'admin123' }),
      credentials: 'include',
    });
  });
  await page.waitForTimeout(1000);

  // Check cookies
  const cookies = await context.cookies();
  console.log('Cookies after login:', JSON.stringify(cookies.map(c => ({ name: c.name, domain: c.domain, path: c.path, sameSite: c.sameSite })), null, 2));

  // Step 2: Go directly to OIDC authorize to see what happens
  console.log('\n2. Go to OIDC authorize directly...');
  const oidcUrl = 'http://localhost:8000/api/oidc/authorize?client_id=protein-ai&redirect_uri=http://localhost:8000/wiki-proxy/auth/oidc.callback&response_type=code&scope=openid%20profile%20email&state=test123';
  
  const response = await page.goto(oidcUrl, { waitUntil: 'networkidle' });
  console.log('Final URL:', page.url());
  console.log('Response status:', response?.status());
  
  await page.waitForTimeout(2000);
  console.log('URL after redirects:', page.url());
  
  // Check if we're on Outline or still on OIDC
  if (page.url().includes('wiki-proxy')) {
    const title = await page.title();
    console.log('Page title:', title);
    console.log('SUCCESS: SSO redirect completed');
  } else if (page.url().includes('login')) {
    console.log('ISSUE: Redirected to login page - cookie not received');
  } else {
    console.log('UNKNOWN state:', page.url());
  }

  await page.screenshot({ path: '/tmp/oidc-debug.png', fullPage: true });
  await browser.close();
  console.log('\nDone');
})();
