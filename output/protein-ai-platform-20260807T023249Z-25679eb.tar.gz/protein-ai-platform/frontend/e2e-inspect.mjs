import { chromium } from 'playwright';

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

// Go to data browser
await page.goto('http://localhost:3000/data');
await page.waitForTimeout(3000);

// Check page title
const title = await page.title();
console.log('Title:', title);

// Check main content
const h1 = await page.locator('h1, h2').first().textContent();
console.log('Main heading:', h1);

// Check what tabs/links exist
const links = await page.locator('a').allTextContents();
console.log('Links (first 20):', links.slice(0, 20));

// Check for input placeholders
const inputs = await page.locator('input');
const inputCount = await inputs.count();
console.log('Input count:', inputCount);
for (let i = 0; i < inputCount; i++) {
  console.log('Input', i, 'placeholder:', await inputs.nth(i).getAttribute('placeholder'));
}

// Search
if (inputCount > 0) {
  await inputs.first().fill('Lysozyme');
  await page.keyboard.press('Enter');
  await page.waitForTimeout(3000);
  
  // Check search results
  const bodyText = await page.textContent('body');
  const lysozymeIndex = bodyText.indexOf('Lysozyme');
  if (lysozymeIndex > -1) {
    console.log('Found "Lysozyme" at index', lysozymeIndex);
    console.log('Context:', bodyText.substring(Math.max(0, lysozymeIndex - 50), lysozymeIndex + 100));
  }
  
  // Look for P00698 or any UniProt IDs
  const hasUniProt = bodyText.match(/[A-Z][0-9][A-Z0-9]{4,8}/g);
  console.log('UniProt-like IDs found:', hasUniProt?.slice(0, 10) || 'none');
  
  // Check for any enzyme protein names
  const proteinSection = bodyText.substring(0, 3000);
  console.log('Page body (first 2000 chars):', proteinSection.substring(0, 2000));
}

await browser.close();
