import { chromium } from 'playwright';

const BASE = 'http://localhost:3000';
const API = 'http://localhost:8000';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  // Login
  const r1 = await fetch(`${API}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' })
  });
  const { access_token: token } = await r1.json();

  // Clear old + create new
  const old = await fetch(`${API}/api/conversations`, { headers: { Authorization: `Bearer ${token}` } });
  const oldList = await old.json();
  for (const c of oldList) {
    await fetch(`${API}/api/conversations/${c.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
  }
  console.log(`Cleared ${oldList.length} old conversations`);

  for (let i = 1; i <= 2; i++) {
    await fetch(`${API}/api/conversations`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ title: `DEL-TEST-${i}` })
    });
  }
  console.log('Created 2 test conversations');

  // Navigate to chat
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);
  await page.goto(`${BASE}/chat/agent`, { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(2000);

  // Check what we have
  const bodyText = await page.evaluate(() => document.body.innerText);
  console.log(`Page has DEL-TEST-1: ${bodyText.includes('DEL-TEST-1')}`);
  console.log(`Page has DEL-TEST-2: ${bodyText.includes('DEL-TEST-2')}`);

  // Find group elements for DEL-TEST conversations
  const convElements = await page.evaluate(() => {
    const results = [];
    for (const el of document.querySelectorAll('div, button, a, li')) {
      if (el.textContent?.includes('DEL-TEST')) {
        // Find the nearest parent with class containing 'group'
        let parent = el.parentElement;
        let depth = 0;
        while (parent && depth < 10) {
          if (parent.className && parent.className.includes('group')) {
            results.push({
              text: el.textContent.trim(),
              groupClass: parent.className.slice(0, 100),
              groupTag: parent.tagName,
              depth,
            });
            break;
          }
          parent = parent.parentElement;
          depth++;
        }
      }
    }
    return results;
  });
  console.log(`Found ${convElements.length} DEL-TEST conversation elements:`);
  convElements.forEach(c => console.log(`  "${c.text}" <${c.groupTag}> class="${c.groupClass}" depth=${c.depth}`));

  // Try to click trash by selecting the group element and its button child
  console.log('\n=== Attempting delete ===');
  const allGroups = await page.locator('[class*="group"]');
  const groupCount = await allGroups.count();
  console.log(`Total group elements: ${groupCount}`);

  let deleted = 0;
  for (let i = 0; i < groupCount; i++) {
    const text = await allGroups.nth(i).textContent();
    if (text && text.includes('DEL-TEST')) {
      console.log(`\nGroup ${i}: "${text.slice(0, 40)}"`);

      // Hover
      await allGroups.nth(i).hover();
      await page.waitForTimeout(500);

      // Find trash button inside
      const buttons = await allGroups.nth(i).locator('button');
      const btnCount = await buttons.count();
      console.log(`  Buttons inside: ${btnCount}`);

      for (let j = 0; j < btnCount; j++) {
        const html = await buttons.nth(j).innerHTML();
        if (html && html.includes('trash')) {
          console.log(`  Found trash button at index ${j}`);

          // Force click regardless of visibility
          await buttons.nth(j).click({ force: true });
          console.log('  Clicked (force)');
          await page.waitForTimeout(2000);

          // Check if gone from DOM
          const gone = !(await page.evaluate((t) => document.body.innerText.includes(t), `DEL-TEST-${deleted + 1}`));
          console.log(`  Removed from UI: ${gone}`);
          if (gone) deleted++;
          break;
        }
      }
    }
  }

  // Final API check
  console.log('\n=== Final API state ===');
  const finalList = await (await fetch(`${API}/api/conversations`, { headers: { Authorization: `Bearer ${token}` } })).json();
  console.log(`Conversations in DB: ${finalList.length}`);
  finalList.forEach(c => console.log(`  ${c.id} "${c.title}"`));

  console.log(`\n=== RESULT ===`);
  if (finalList.length === 0 && deleted === 2) {
    console.log('✅ Delete works correctly!');
  } else {
    console.log(`⚠️  DB has ${finalList.length} convs, UI deleted ${deleted}`);
    if (finalList.length > 0) console.log('❌ Delete API not triggered from frontend');
    if (deleted < 2) console.log('❌ Delete buttons were not clickable');
  }

  await browser.close();
})();
