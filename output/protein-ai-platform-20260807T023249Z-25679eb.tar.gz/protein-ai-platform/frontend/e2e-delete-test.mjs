import { chromium } from 'playwright';

const BASE = 'http://localhost:3000';
const API = 'http://localhost:8000';
const SS = '/Users/xuyan/科为博/05自动化程序/04研发工作区/酶蛋白AI平台/frontend/test-results';
const bugs = [];

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  // Collect errors
  const consoleErrors = [];
  const apiErrors = [];
  page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text()); });
  page.on('response', resp => { if (resp.status() >= 400) apiErrors.push(`${resp.status()} ${resp.request().method()} ${resp.url()}`); });

  // ========== Login via API and set token ==========
  console.log('=== Login via API ===');
  const resp = await fetch(`${API}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' }),
  });
  const data = await resp.json();
  const token = data.access_token;
  console.log(`  Token obtained: ${token.slice(0, 20)}...`);

  // Navigate to app first (to set localStorage on the right origin)
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });

  // Set token in localStorage
  await page.evaluate((tok) => {
    localStorage.setItem('token', tok);
  }, token);

  // Reload to pick up token
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(2000);
  await page.screenshot({ path: `${SS}/10-logged-in.png`, fullPage: true });
  console.log('  Screenshot: 10-logged-in.png');
  console.log('  URL:', page.url());

  // ========== Create test conversations via API ==========
  console.log('\n=== Create test conversations ===');
  for (let i = 0; i < 3; i++) {
    await fetch(`${API}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ title: `Delete Test ${i + 1}` }),
    });
  }
  console.log('  Created 3 test conversations');

  // Reload page to see them
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(2000);
  await page.screenshot({ path: `${SS}/11-with-conversations.png`, fullPage: true });
  console.log('  Screenshot: 11-with-conversations.png');

  // ========== Find sidebar and conversations ==========
  console.log('\n=== Find sidebar conversations ===');

  // Dump the page HTML structure for debugging
  const sidebarHTML = await page.evaluate(() => {
    const aside = document.querySelector('aside');
    return aside ? aside.innerHTML.slice(0, 2000) : 'NO ASIDE FOUND';
  });
  console.log('  Sidebar HTML:', sidebarHTML.slice(0, 500));

  // Try to find conversation items
  const allButtons = await page.$$('button');
  const allLinks = await page.$$('a');
  console.log(`  Total buttons: ${allButtons.length}, Total links: ${allLinks.length}`);

  // Look for conversation-related elements
  const convElements = await page.$$('[class*="conversation"], [class*="chat"], [data-testid*="conv"]');
  console.log(`  Conversation-class elements: ${convElements.length}`);

  // Try various selectors for sidebar items
  const selectors = [
    'aside button', 'aside a', 'aside div[class*="group"]',
    '[class*="sidebar"] button', '[class*="sidebar"] a',
    'nav button', 'nav a',
    '[class*="ConversationList"] > div', '[class*="conversation"] > div',
  ];

  let sidebarItems = [];
  for (const sel of selectors) {
    const items = await page.$$(sel);
    if (items.length > 0) {
      sidebarItems = items;
      console.log(`  Found ${items.length} items with: ${sel}`);
      break;
    }
  }

  if (sidebarItems.length === 0) {
    // Fallback: look for elements containing "Delete Test"
    const allDivs = await page.$$('div, li, a, button');
    for (const el of allDivs) {
      const text = await el.textContent();
      if (text && text.includes('Delete Test')) {
        sidebarItems.push(el);
      }
    }
    console.log(`  Found ${sidebarItems.length} "Delete Test" elements (text search)`);
  }

  // ========== Hover and find trash button ==========
  console.log('\n=== Test delete button ===');
  if (sidebarItems.length > 0) {
    const target = sidebarItems[0];
    const text = await target.textContent();
    console.log(`  Hovering over: "${text?.trim().slice(0, 50)}"`);

    await target.hover();
    await page.waitForTimeout(800);
    await page.screenshot({ path: `${SS}/12-hover-sidebar.png`, fullPage: true });
    console.log('  Screenshot: 12-hover-sidebar.png');

    // Look for SVG trash icon or delete button
    const trashSelectors = [
      'svg.lucide-trash-2', 'svg.lucide-trash',
      'button svg[class*="trash"]',
      'button[class*="opacity-0"]',
      'button:has(svg)',  // any button with SVG
    ];

    // Get ALL visible buttons near the hovered element
    const nearbyButtons = await page.evaluate(() => {
      const hovered = document.querySelector('[class*="group"]:hover, [class*="group"]:has(:hover)');
      if (!hovered) return [];
      const btns = hovered.querySelectorAll('button');
      return Array.from(btns).map(b => ({
        classes: b.className,
        ariaLabel: b.getAttribute('aria-label'),
        innerHTML: b.innerHTML.slice(0, 100),
        visible: b.offsetParent !== null,
        rect: b.getBoundingClientRect(),
      }));
    });
    console.log(`  Nearby buttons on hover: ${nearbyButtons.length}`);
    nearbyButtons.forEach((b, i) => {
      console.log(`    [${i}] visible=${b.visible} class="${b.classes.slice(0, 80)}" aria="${b.ariaLabel}" html="${b.innerHTML.slice(0, 80)}"`);
    });

    // Try to find and click the trash button
    let clicked = false;
    for (const sel of trashSelectors) {
      const btn = await page.$(sel);
      if (btn) {
        const box = await btn.boundingBox();
        console.log(`  Found ${sel}, box:`, box);
        if (box) {
          await btn.click({ position: { x: box.width / 2, y: box.height / 2 } });
          clicked = true;
          console.log(`  ✅ Clicked: ${sel}`);
          break;
        } else {
          // Force click
          await btn.click({ force: true });
          clicked = true;
          console.log(`  Force-clicked: ${sel} (no bounding box)`);
          break;
        }
      }
    }

    if (!clicked) {
      // Last resort: find any small button near the conversation item
      const smallBtns = await page.$$('button');
      for (const btn of smallBtns) {
        const box = await btn.boundingBox();
        if (box && box.width < 30 && box.height < 30) {
          const html = await btn.innerHTML();
          if (html.includes('trash') || html.includes('Trash') || html.includes('svg')) {
            await btn.click({ force: true });
            clicked = true;
            console.log(`  Clicked small SVG button: ${html.slice(0, 60)}`);
            break;
          }
        }
      }
    }

    if (clicked) {
      await page.waitForTimeout(2000);
      await page.screenshot({ path: `${SS}/13-after-delete.png`, fullPage: true });
      console.log('  Screenshot: 13-after-delete.png');

      // Verify deletion
      const afterItems = await page.$$('aside button, aside a, nav a, [class*="conversation"] a');
      const afterText = await page.evaluate(() => document.body.innerText);
      const stillHasDeleteTest = afterText.includes('Delete Test 1');
      console.log(`  "Delete Test 1" still visible: ${stillHasDeleteTest}`);

      if (stillHasDeleteTest) {
        bugs.push({ severity: 'critical', issue: 'Delete conversation button does not work', detail: 'Conversation remains after clicking delete' });
      }
    } else {
      console.log('  ❌ Could not find any trash/delete button');
      bugs.push({ severity: 'critical', issue: 'Delete button not found or not clickable' });
    }
  } else {
    console.log('  No sidebar items to test');
  }

  // ========== Test other pages ==========
  console.log('\n=== Test other pages ===');
  const pages = ['/projects', '/wiki', '/home', '/data'];
  for (const p of pages) {
    try {
      const r = await page.goto(`${BASE}${p}`, { waitUntil: 'domcontentloaded', timeout: 8000 });
      const status = r?.status();
      const redirected = page.url() !== `${BASE}${p}`;
      console.log(`  ${p}: ${status} ${redirected ? `→ ${page.url()}` : 'OK'}`);
      if (status >= 400) {
        bugs.push({ severity: 'medium', issue: `Page ${p} returns ${status}` });
      }
    } catch (e) {
      console.log(`  ${p}: TIMEOUT`);
      bugs.push({ severity: 'medium', issue: `Page ${p} timeout` });
    }
  }
  await page.screenshot({ path: `${SS}/14-final.png`, fullPage: true });

  // ========== Summary ==========
  console.log('\n' + '='.repeat(60));
  console.log('BUG HUNT SUMMARY');
  console.log('='.repeat(60));
  console.log(`Console errors: ${consoleErrors.length}`);
  consoleErrors.slice(0, 10).forEach(e => console.log(`  ❌ ${e.slice(0, 150)}`));
  console.log(`\nAPI errors (4xx/5xx): ${apiErrors.length}`);
  apiErrors.forEach(e => console.log(`  ❌ ${e}`));
  console.log(`\nBugs found: ${bugs.length}`);
  bugs.forEach(b => console.log(`  [${b.severity.toUpperCase()}] ${b.issue}`));
  if (!bugs.length) console.log('  ✅ No bugs found');
  console.log('='.repeat(60));

  await browser.close();
})();
