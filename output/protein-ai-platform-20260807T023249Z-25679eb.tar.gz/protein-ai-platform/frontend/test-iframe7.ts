import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Login
  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Go to wiki
  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(5000);

  // Check iframe content
  const iframe = await page.$('iframe');
  const frame = await iframe.contentFrame();
  
  console.log('Iframe URL:', frame.url());
  console.log('Iframe Title:', await frame.title());
  
  // Check for javascript errors
  page.on('console', msg => {
    if (msg.type() === 'error') console.log('PAGE CONSOLE ERROR:', msg.text());
  });
  
  // Check for actual content - Outline has specific elements
  const bodyHTML = await frame.innerHTML('body');
  const hasContent = bodyHTML.length > 500; // blank page would have minimal HTML
  console.log('Body HTML length:', bodyHTML.length);
  
  // Check for Outline-specific UI
  const hasSidebar = bodyHTML.includes('sidebar') || bodyHTML.includes('Sidebar');
  const hasAppShell = bodyHTML.includes('root') || bodyHTML.includes('app');
  console.log('Has sidebar elements:', hasSidebar);
  console.log('Has app shell:', hasAppShell);
  
  // Check if Outline rendered its React app
  const reactRoot = await frame.$('#root');
  const rootChildren = reactRoot ? await reactRoot.innerHTML() : '';
  console.log('Root children length:', rootChildren.length);
  
  // Check for error messages
  const bodyText = await frame.textContent('body');
  if (bodyText.includes('Sorry') || bodyText.includes('error') || bodyText.includes('not found')) {
    console.log('⚠️  Error message found on page');
  }
  
  await page.screenshot({ path: '/tmp/wiki-assets.png', fullPage: true });
  await browser.close();
  console.log('\nDone. Screenshot saved.');
})();
