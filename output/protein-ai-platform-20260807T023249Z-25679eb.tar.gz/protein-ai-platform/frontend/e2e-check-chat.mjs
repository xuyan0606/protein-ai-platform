import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  // Login via API
  const r1 = await fetch('http://localhost:8000/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' })
  });
  const { access_token: token } = await r1.json();

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);
  await page.goto('http://localhost:3000/chat/agent', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(3000);

  // Check for empty tool names, missing text, broken elements
  const issues = await page.evaluate(() => {
    const found = [];

    // Check all buttons without text
    document.querySelectorAll('button').forEach(b => {
      const text = b.textContent?.trim();
      const aria = b.getAttribute('aria-label');
      if (!text && !aria) {
        found.push({ type: 'empty-button', classes: b.className.slice(0, 60), html: b.innerHTML.slice(0, 60) });
      }
    });

    // Check tool cards/panels
    document.querySelectorAll('[class*="tool"], [class*="Tool"]').forEach(el => {
      const text = el.textContent?.trim();
      if (!text || text.length < 2) {
        found.push({ type: 'empty-tool-element', classes: el.className.slice(0, 60), tag: el.tagName });
      }
    });

    // Check spans/divs that should have text
    document.querySelectorAll('span, div').forEach(el => {
      // Skip layout-only elements
      if (el.children.length > 0) return;
      const cn = el.className || '';
      if (cn.includes('name') || cn.includes('title') || cn.includes('label') || cn.includes('tool')) {
        const text = el.textContent?.trim();
        if (!text || text === 'undefined' || text === 'null') {
          found.push({ type: 'empty-label', classes: cn.slice(0, 60), tag: el.tagName });
        }
      }
    });

    // Check for "undefined" text
    const allText = document.body.innerText;
    if (allText.includes('undefined')) {
      const lines = allText.split('\n').filter(l => l.includes('undefined'));
      found.push({ type: 'undefined-text', occurrences: lines.slice(0, 5) });
    }
    if (allText.includes('null')) {
      const lines = allText.split('\n').filter(l => l.includes('null'));
      found.push({ type: 'null-text', occurrences: lines.slice(0, 5) });
    }

    return found;
  });

  console.log('Issues found:', JSON.stringify(issues, null, 2));

  // Also get the tool panel area content
  const toolPanel = await page.evaluate(() => {
    // Find tool panel elements
    const panels = document.querySelectorAll('[class*="panel"], [class*="Panel"], [class*="tool-panel"], [class*="ToolPanel"]');
    const results = [];
    panels.forEach(p => {
      results.push({
        class: p.className.slice(0, 80),
        text: p.textContent?.trim()?.slice(0, 300),
      });
    });
    return results;
  });
  console.log('\nTool panels:', JSON.stringify(toolPanel, null, 2));

  // Full body text (first 1000 chars)
  const bodyText = await page.evaluate(() => document.body.innerText.slice(0, 1000));
  console.log('\nBody text:', bodyText);

  await browser.close();
})();
