import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Collect console errors from the iframe
  const errors: string[] = [];
  page.on('console', msg => {
    if (msg.type() === 'error') errors.push(msg.text());
  });

  // Login
  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Go to wiki
  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(8000);  // Wait for JS to load and render

  const iframe = await page.$('iframe');
  const frame = await iframe.contentFrame();
  
  console.log('Iframe URL:', frame.url());
  console.log('Iframe Title:', await frame.title());
  
  // Check if React rendered
  const rootEl = await frame.$('#root');
  const rootHTML = rootEl ? await rootEl.innerHTML() : '';
  const hasRendered = rootHTML.length > 100;
  console.log('Root element rendered:', hasRendered, `(${rootHTML.length} chars)`);
  
  // Check for Outline UI elements
  const bodyText = await frame.textContent('body') || '';
  const hasContent = bodyText.length > 100;
  console.log('Body text length:', bodyText.length);
  
  // Check for specific Outline elements
  const hasLogin = bodyText.includes('Continue with') || bodyText.includes('Sign in');
  const hasDashboard = bodyText.includes('Home') || bodyText.includes('Collection') || bodyText.includes('Document');
  console.log('Shows login page:', hasLogin);
  console.log('Shows dashboard:', hasDashboard);
  
  console.log('Console errors:', errors.length);
  if (errors.length > 0) {
    console.log('Errors:', errors.slice(0, 5));
  }
  
  await page.screenshot({ path: '/tmp/wiki-final-v2.png', fullPage: true });
  
  if (hasRendered && hasDashboard && !hasLogin) {
    console.log('\n✅ SUCCESS: Outline fully loaded with SSO in iframe');
  } else if (hasLogin) {
    console.log('\n❌ SSO not working - still on login page');
  } else if (!hasRendered) {
    console.log('\n❌ React app not rendered - JS loading issue');
  } else {
    console.log('\n⚠️  Partial success - check screenshot');
  }
  
  await browser.close();
})();
