import { ShieldAlert, TrendingUp, Target, Download, Printer } from 'lucide-react'
import { downloadReport, printReport } from '@/lib/report'
import { ReportBadge, ReportBody, ReportHeader, ReportMetricCard, ReportMetricGrid, ReportPanel, ReportSection, ReportShell } from '@/components/analysis/ReportShell'

interface RecommendedMutation {
  mutation: string
  type: string
  purpose: string
  lipase_evidence?: {
    exact_match_count?: number
    matches?: Array<Record<string, unknown>>
    source?: string
    interpretation?: string
  }
}

interface Candidate {
  position: number
  user_position?: string | number | null
  pdb_position?: string | number | null
  uniprot_position?: string | number | null
  numbering_status?: string | null
  wild_type: string
  composite_priority: number
  tier: number
  mutation_type?: string | null
  logic: string
  recommended_mutations: RecommendedMutation[]
  is_protected?: boolean
  active_site_distance_residues?: number | null
  active_site_sources?: string[]
  categories?: string[]
  lipase_position_evidence_count?: number
  expected_effect?: string
  risk_flags?: string[]
  experiment_priority?: string
  experiment_action?: string
  candidate_evidence_status?: string
  objective_missing_evidence?: string[]
}

export interface MutationScoreData {
  sequence_length: number
  sequence_preview?: string
  engineering_goal: string
  target_ph?: number
  target_tm?: number
  active_site_positions: number[]
  active_site_position_sources?: Record<string, string[]>
  summary: {
    total_positions: number
    tier_1_count: number
    tier_2_count: number
    tier_3_count: number
    never_mutate_count: number
    never_mutate_positions: number[]
    catalytic_guardrail_enabled?: boolean
  }
  guardrails?: {
    protected_positions?: number[]
    sources?: Record<string, string[]>
    rule?: string
  }
  tier_1_candidates: Candidate[]
  tier_2_candidates: Candidate[]
  all_positions?: Candidate[]
  candidate_table_status?: string
  objective_gate?: {
    status?: string | null
    objective?: string | null
    module?: string | null
    candidate_output_allowed?: boolean | null
    missing_evidence?: string[]
    ranking_boundary?: string | null
  }
  strategy?: {
    objective?: string
    design_principle?: string
    screening_logic?: string[]
    preserved_constraints?: string[]
    experiment_plan?: Array<{ priority: string; scope: string; purpose: string; gate: string }>
    confidence_boundary?: string
  }
}

const GOAL_LABELS: Record<string, string> = {
  ph_lowering: 'pH降低改造',
  ph_raising: 'pH升高改造',
  thermostability: '热稳定性改造',
  activity: '活性改造',
  specificity: '底物特异性改造',
  general: '通用改造',
}

const TYPE_TONES: Record<string, 'info' | 'warning' | 'neutral'> = {
  表面电荷翻转: 'info',
  活性中心电荷中和: 'info',
  增加loop刚性: 'warning',
  表面电荷优化: 'info',
  表面电荷网络优化: 'info',
  loop稳定性: 'warning',
}

function TierBadge({ tier }: { tier: number }) {
  const map: Record<number, { tone: 'success' | 'warning' | 'neutral'; label: string }> = {
    1: { tone: 'success', label: '优先' },
    2: { tone: 'warning', label: '可选' },
    3: { tone: 'neutral', label: '保守' },
  }
  const badge = map[tier] || map[3]
  return <ReportBadge tone={badge.tone}>{badge.label}</ReportBadge>
}

function typeTone(type: string): 'info' | 'warning' | 'neutral' {
  return TYPE_TONES[type] || 'neutral'
}

function experimentTone(priority?: string): 'success' | 'warning' | 'danger' | 'neutral' {
  if (priority?.startsWith('P1')) return 'success'
  if (priority === 'No-Go') return 'danger'
  if (priority?.startsWith('P2') || priority?.startsWith('P3')) return 'warning'
  return 'neutral'
}

function evidenceTone(status?: string): 'success' | 'warning' | 'neutral' {
  if (status === 'ready') return 'success'
  if (status === 'exploratory_requires_objective_evidence') return 'warning'
  return 'neutral'
}

function evidenceLabel(status?: string): string {
  if (status === 'ready') return '可排单'
  if (status === 'exploratory_requires_objective_evidence') return '探索性'
  if (status === 'blocked_by_identity_gate') return '身份未过'
  return status || '待确认'
}

function formatPositionValue(value?: string | number | null): string {
  if (value === null || value === undefined || value === '') return '未映射'
  return String(value)
}

function formatUserPosition(candidate: Candidate): string {
  return formatPositionValue(candidate.user_position ?? candidate.position)
}

function formatRecommendedMutations(candidate: Candidate): string {
  if (candidate.recommended_mutations.length > 0) {
    return candidate.recommended_mutations.slice(0, 3).map((mutation) => mutation.mutation).join(' / ')
  }
  return candidate.is_protected ? '禁止突变' : `${candidate.wild_type}${candidate.position}`
}

function decisionSummary(candidates: Candidate[], protectedRows: Candidate[], tableStatus?: string, objectiveStatus?: string | null) {
  const goCount = candidates.filter((candidate) => candidate.experiment_priority?.startsWith('P1') && !candidate.is_protected).length
  const noGoCount = protectedRows.length + candidates.filter((candidate) => candidate.experiment_priority === 'No-Go' || candidate.is_protected).length
  const watchCount = candidates.filter((candidate) => {
    const priority = candidate.experiment_priority || ''
    return !candidate.is_protected && (priority.startsWith('P2') || priority.startsWith('P3') || candidate.candidate_evidence_status !== 'ready')
  }).length
  const isIdentityBlocked = tableStatus === 'blocked_by_identity_gate'
  const objectiveNeedsEvidence = objectiveStatus === 'blocked'

  return [
    {
      label: 'Go',
      value: isIdentityBlocked || objectiveNeedsEvidence ? 0 : goCount,
      tone: 'success' as const,
      description: objectiveNeedsEvidence ? '目标证据未补齐，先按 Watch 小批验证' : '首轮优先单点验证',
    },
    {
      label: 'Watch',
      value: isIdentityBlocked ? 0 : watchCount,
      tone: 'warning' as const,
      description: '探索性或第二梯队，需带对照复核',
    },
    {
      label: 'No-Go',
      value: noGoCount + (isIdentityBlocked ? goCount : 0),
      tone: 'danger' as const,
      description: isIdentityBlocked ? '身份或编号硬门控未通过' : '保护位点或禁止突变',
    },
  ]
}

export function MutationScoreCard({ data }: { data: MutationScoreData }) {
  const { summary, tier_1_candidates, tier_2_candidates, engineering_goal, active_site_positions, target_ph, target_tm } = data
  const protectedPositions = data.guardrails?.protected_positions || summary.never_mutate_positions || []
  const guardrailSources = data.guardrails?.sources || data.active_site_position_sources || {}
  const protectedRows = (data.all_positions || []).filter((item) => item.is_protected).slice(0, 8)
  const mutationTableCandidates = [...tier_1_candidates, ...tier_2_candidates].slice(0, 20)
  const decisions = decisionSummary(mutationTableCandidates, protectedRows, data.candidate_table_status, data.objective_gate?.status)

  return (
    <ReportShell>
      <ReportHeader
        icon={Target}
        title="突变优先级分析"
        subtitle={`${GOAL_LABELS[engineering_goal] || engineering_goal}${target_ph != null ? ` · 目标 pH ${target_ph}` : ''}${target_tm != null ? ` · 目标 Tm ${target_tm}°C` : ''} · 扫描 ${summary.total_positions} 个位点`}
        actions={
          <>
            <button onClick={() => downloadReport('mutation_score', data)} className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground" title="下载报告">
              <Download className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => printReport('mutation_score', data)} className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground" title="打印报告">
              <Printer className="w-3.5 h-3.5" />
            </button>
          </>
        }
      />
      <ReportBody>
        <ReportSection title="Go / Watch / No-Go" icon={ShieldAlert}>
          <div className="grid gap-2 sm:grid-cols-3">
            {decisions.map((item) => (
              <ReportPanel key={item.label} tone={item.tone} className="px-3 py-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-foreground">{item.label}</div>
                  <div className="font-mono text-lg font-bold">{item.value}</div>
                </div>
                <div className="mt-1 text-[11px] leading-5 text-muted-foreground">{item.description}</div>
              </ReportPanel>
            ))}
          </div>
        </ReportSection>

        {mutationTableCandidates.length > 0 && (
          <ReportSection title="候选突变位点" icon={TrendingUp}>
            <MutationCandidateTable candidates={mutationTableCandidates} tableStatus={data.candidate_table_status} />
          </ReportSection>
        )}

        {data.strategy && (
          <ReportSection title="改造策略" icon={Target}>
            <ReportPanel tone="info" className="space-y-4">
              <div>
                <div className="text-sm font-semibold text-foreground">目标</div>
                <p className="mt-1 text-xs leading-6 text-muted-foreground">{data.strategy.objective}</p>
              </div>
              <div>
                <div className="text-sm font-semibold text-foreground">设计原则</div>
                <p className="mt-1 text-xs leading-6 text-muted-foreground">{data.strategy.design_principle}</p>
              </div>
              {(data.strategy.screening_logic || []).length > 0 && (
                <div>
                  <div className="text-sm font-semibold text-foreground">位点筛选逻辑</div>
                  <ul className="mt-1 list-disc space-y-1 pl-4 text-xs leading-5 text-muted-foreground">
                    {data.strategy.screening_logic?.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                </div>
              )}
              {(data.strategy.preserved_constraints || []).length > 0 && (
                <div className="rounded-md border border-red-500/15 bg-red-500/5 px-3 py-2">
                  <div className="text-xs font-semibold text-red-700 dark:text-red-300">保护约束</div>
                  <ul className="mt-1 list-disc space-y-1 pl-4 text-[11px] leading-5 text-red-700/80 dark:text-red-200/80">
                    {data.strategy.preserved_constraints?.map((item) => <li key={item}>{item}</li>)}
                  </ul>
                </div>
              )}
              {(data.strategy.experiment_plan || []).length > 0 && (
                <div>
                  <div className="text-sm font-semibold text-foreground">实验优先级</div>
                  <div className="mt-2 overflow-x-auto">
                    <table className="w-full min-w-[620px] border-collapse text-left text-[11px]">
                      <thead>
                        <tr className="border-b border-border/70 text-muted-foreground">
                          <th className="px-2 py-2 font-medium">优先级</th>
                          <th className="px-2 py-2 font-medium">实验层级</th>
                          <th className="px-2 py-2 font-medium">目的</th>
                          <th className="px-2 py-2 font-medium">进入下一层的条件</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.strategy.experiment_plan?.map((item) => (
                          <tr key={`${item.priority}-${item.scope}`} className="border-b border-border/50 align-top">
                            <td className="px-2 py-2 font-mono font-semibold text-primary">{item.priority}</td>
                            <td className="px-2 py-2 font-medium">{item.scope}</td>
                            <td className="px-2 py-2 text-muted-foreground">{item.purpose}</td>
                            <td className="px-2 py-2 text-muted-foreground">{item.gate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              {data.strategy.confidence_boundary && (
                <p className="border-t border-border/60 pt-3 text-[11px] leading-5 text-muted-foreground">
                  证据边界：{data.strategy.confidence_boundary}
                </p>
              )}
            </ReportPanel>
          </ReportSection>
        )}

        <ReportSection title="Summary">
          <ReportMetricGrid>
            <ReportMetricCard label="优先改造" value={summary.tier_1_count} meta="优先级 > 7.0" tone="success" />
            <ReportMetricCard label="可选改造" value={summary.tier_2_count} meta="优先级 5.0 - 7.0" tone="warning" />
            <ReportMetricCard label="低优先" value={summary.tier_3_count} meta="优先级 < 5.0" tone="neutral" />
            <ReportMetricCard
              label="禁止突变"
              value={summary.never_mutate_count}
              meta={summary.catalytic_guardrail_enabled ? '催化护栏已启用' : '未启用催化护栏'}
              tone="danger"
            />
          </ReportMetricGrid>
        </ReportSection>

        {active_site_positions.length > 0 && (
          <ReportSection title="Catalytic Guardrails" icon={ShieldAlert}>
            <ReportPanel tone="danger" className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-medium">活性中心/保护位点</span>
                {protectedPositions.map((p) => (
                  <code key={p} className="rounded-md border border-red-500/20 bg-background/70 px-2 py-1 font-mono text-[10px] text-red-600 dark:text-red-300">
                    {p}
                  </code>
                ))}
              </div>
              <p className="text-xs leading-6 text-muted-foreground">
                {data.guardrails?.rule || '保护位点会被强制降级并禁止生成推荐突变；邻近位点也会被附加惩罚。'}
              </p>
              <div className="flex flex-wrap gap-2">
                {protectedPositions.map((position) => (
                  <div key={`source-${position}`} className="flex items-center gap-1 rounded-full border border-red-500/15 bg-background/70 px-2 py-1">
                    <code className="font-mono text-[10px] text-red-600 dark:text-red-300">{position}</code>
                    {(guardrailSources[String(position)] || []).map((source) => (
                      <ReportBadge
                        key={`${position}-${source}`}
                        tone={source === 'curated' ? 'success' : source === 'input' ? 'info' : 'warning'}
                        className="px-2 py-0.5"
                      >
                        {source}
                      </ReportBadge>
                    ))}
                  </div>
                ))}
              </div>
            </ReportPanel>
          </ReportSection>
        )}

        {protectedRows.length > 0 && (
          <ReportSection title="Blocked Positions">
            <div className="space-y-2">
              {protectedRows.map((c) => (
                <MutationRow key={`protected-${c.position}`} candidate={c} forceTone="danger" />
              ))}
            </div>
          </ReportSection>
        )}

        {tier_1_candidates.length > 0 && (
          <ReportSection title="首轮实验候选位点" icon={TrendingUp}>
            <div className="space-y-2">
              {tier_1_candidates.map((c) => (
                <MutationRow key={c.position} candidate={c} />
              ))}
            </div>
          </ReportSection>
        )}

        {tier_2_candidates.length > 0 && (
          <ReportSection title="第二梯队候选位点">
            <div className="max-h-80 space-y-2 overflow-y-auto pr-1">
              {tier_2_candidates.map((c) => (
                <MutationRow key={c.position} candidate={c} />
              ))}
            </div>
          </ReportSection>
        )}
      </ReportBody>
    </ReportShell>
  )
}

function MutationCandidateTable({ candidates, tableStatus }: { candidates: Candidate[]; tableStatus?: string }) {
  return (
    <ReportPanel className="overflow-hidden p-0">
      {tableStatus && tableStatus !== 'ready' && (
        <div className="border-b border-border/70 bg-amber-500/8 px-3 py-2 text-[11px] leading-5 text-amber-700 dark:text-amber-300">
          当前突变主表状态：{evidenceLabel(tableStatus)}。位点可用于首轮探索排单，但目标性质结论需要补充基线或对照实验后确认。
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1180px] border-collapse text-left text-xs">
          <thead className="bg-secondary/45 text-[11px] text-muted-foreground">
            <tr className="border-b border-border/70">
              <th className="w-16 px-3 py-3 font-semibold">优先级</th>
              <th className="w-24 px-3 py-3 font-semibold">用户编号</th>
              <th className="w-36 px-3 py-3 font-semibold">PDB/UniProt 编号</th>
              <th className="w-32 px-3 py-3 font-semibold">推荐突变</th>
              <th className="min-w-[260px] px-3 py-3 font-semibold">突变逻辑</th>
              <th className="min-w-[220px] px-3 py-3 font-semibold">预期方向</th>
              <th className="min-w-[180px] px-3 py-3 font-semibold">风险提示</th>
              <th className="min-w-[180px] px-3 py-3 font-semibold">实验动作</th>
            </tr>
          </thead>
          <tbody>
            {candidates.map((candidate) => {
              const riskText = (candidate.risk_flags || []).length > 0 ? candidate.risk_flags?.join('；') : '需实验确认'
              return (
                <tr key={`${candidate.position}-${formatRecommendedMutations(candidate)}`} className="border-b border-border/50 align-top last:border-b-0">
                  <td className="px-3 py-3">
                    <ReportBadge tone={experimentTone(candidate.experiment_priority)}>
                      {candidate.experiment_priority || `Tier ${candidate.tier}`}
                    </ReportBadge>
                  </td>
                  <td className="px-3 py-3">
                    <code className="rounded-md border border-primary/15 bg-primary/8 px-2 py-1 font-mono text-[12px] font-bold text-primary">
                      {formatUserPosition(candidate)}
                    </code>
                  </td>
                  <td className="px-3 py-3">
                    <div className="space-y-1 font-mono text-[11px] text-foreground/85">
                      <div>PDB: {formatPositionValue(candidate.pdb_position)}</div>
                      <div>UniProt: {formatPositionValue(candidate.uniprot_position)}</div>
                    </div>
                    {candidate.numbering_status && (
                      <div className="mt-1 text-[10px] text-muted-foreground">{candidate.numbering_status}</div>
                    )}
                  </td>
                  <td className="px-3 py-3">
                    <code className="rounded-md border border-primary/15 bg-primary/8 px-2 py-1 font-mono text-[12px] font-bold text-primary">
                      {formatRecommendedMutations(candidate)}
                    </code>
                  </td>
                  <td className="px-3 py-3 leading-6 text-foreground/85">
                    {candidate.logic}
                    {candidate.mutation_type ? (
                      <span className="ml-2 inline-flex">
                        <ReportBadge tone={typeTone(candidate.mutation_type)}>{candidate.mutation_type}</ReportBadge>
                      </span>
                    ) : null}
                    <span className="ml-2 inline-flex">
                      <ReportBadge tone={evidenceTone(candidate.candidate_evidence_status)}>
                        {evidenceLabel(candidate.candidate_evidence_status)}
                      </ReportBadge>
                    </span>
                  </td>
                  <td className="px-3 py-3 leading-6 text-muted-foreground">
                    {candidate.expected_effect || '目标性质改善方向需实验验证'}
                  </td>
                  <td className="px-3 py-3 leading-6 text-amber-700 dark:text-amber-300">
                    {riskText}
                  </td>
                  <td className="px-3 py-3 leading-6 text-foreground/85">
                    {candidate.experiment_action || '单点构建；表达、可溶性、目标性质与活性保留同步验证'}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </ReportPanel>
  )
}

function MutationRow({ candidate: c, forceTone }: { candidate: Candidate; forceTone?: 'danger' }) {
  const scoreColor = c.is_protected ? 'text-red-600 dark:text-red-300' : c.tier === 1 ? 'text-emerald-500' : 'text-amber-500'
  const panelTone = forceTone || (c.is_protected ? 'danger' : 'neutral')

  return (
    <ReportPanel className="space-y-3" tone={panelTone}>
      <div className="flex items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <TierBadge tier={c.tier} />
          <code className="text-sm font-bold font-mono">{c.wild_type}{c.position}</code>
          {c.is_protected ? <ReportBadge tone="danger">禁止突变</ReportBadge> : null}
          {c.mutation_type && (
            <ReportBadge tone={typeTone(c.mutation_type)}>
              {c.mutation_type}
            </ReportBadge>
          )}
          {c.experiment_priority && (
            <ReportBadge tone={experimentTone(c.experiment_priority)}>
              实验 {c.experiment_priority}
            </ReportBadge>
          )}
          {(c.active_site_sources || []).map((source) => (
            <ReportBadge
              key={`${c.position}-${source}`}
              tone={source === 'curated' ? 'success' : source === 'input' ? 'info' : 'warning'}
            >
              {source}
            </ReportBadge>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Priority</span>
          <span className={`font-mono text-sm font-bold ${scoreColor}`}>
            {c.composite_priority.toFixed(1)}
          </span>
        </div>
      </div>

      <p className="text-xs leading-6 text-muted-foreground">{c.logic}</p>

      {c.expected_effect && (
        <div className="text-[11px] leading-5 text-foreground/80">
          <span className="font-semibold">预期方向：</span>{c.expected_effect}
        </div>
      )}

      {(c.risk_flags || []).length > 0 && (
        <div className="rounded-md border border-amber-500/15 bg-amber-500/5 px-3 py-2 text-[11px] leading-5 text-amber-700 dark:text-amber-300">
          <span className="font-semibold">风险提示：</span>{c.risk_flags?.join('；')}
        </div>
      )}

      {c.active_site_distance_residues != null ? (
        <div className="text-[11px] text-muted-foreground">
          距离保护位点 {c.active_site_distance_residues} 个残基
        </div>
      ) : null}

      {typeof c.lipase_position_evidence_count === 'number' && c.lipase_position_evidence_count > 0 && (
        <div className="rounded-md border border-emerald-500/15 bg-emerald-500/5 px-3 py-2 text-[11px] leading-5 text-emerald-700 dark:text-emerald-300">
          KWB Lipase DB：该位点有 {c.lipase_position_evidence_count} 条文献/变体位置证据；需确认编号体系后使用。
        </div>
      )}

      {c.recommended_mutations.length > 0 && !c.is_protected && (
        <div className="flex flex-wrap gap-2">
          {c.recommended_mutations.map((m) => (
            <div key={m.mutation} className="group relative">
              <code className="cursor-default rounded-md border border-primary/15 bg-primary/8 px-2 py-1 font-mono text-[10px] font-medium text-primary">
                {m.mutation}
              </code>
              <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 -translate-x-1/2 whitespace-nowrap rounded-md border border-border/70 bg-popover px-2 py-1 text-[10px] text-foreground opacity-0 shadow-lg transition-opacity group-hover:opacity-100">
                {m.purpose}
              </div>
              {m.lipase_evidence?.exact_match_count ? (
                <span className="ml-1 rounded-full bg-emerald-500/10 px-1.5 py-0.5 text-[9px] font-semibold text-emerald-700 dark:text-emerald-300">
                  lipase {m.lipase_evidence.exact_match_count}
                </span>
              ) : null}
            </div>
          ))}
        </div>
      )}

      {c.is_protected && (
        <div className="text-[11px] font-medium text-red-700 dark:text-red-300">
          该位点已被催化护栏锁定，不生成任何推荐突变。
        </div>
      )}
    </ReportPanel>
  )
}
