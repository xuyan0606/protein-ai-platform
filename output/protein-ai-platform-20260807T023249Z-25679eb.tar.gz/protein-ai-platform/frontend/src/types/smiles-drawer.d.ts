declare module 'smiles-drawer'
