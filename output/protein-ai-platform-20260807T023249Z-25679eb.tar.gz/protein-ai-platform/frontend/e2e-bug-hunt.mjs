import { chromium } from 'playwright';

const BASE = 'http://localhost:3000';
const SCREENSHOTS = '/Users/xuyan/科为博/05自动化程序/04研发工作区/酶蛋白AI平台/frontend/test-results';
const bugs = [];
const consoleErrors = [];
const apiErrors = [];

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  // Collect console errors
  page.on('console', msg => {
    if (msg.type() === 'error') {
      consoleErrors.push(msg.text());
    }
  });

  // Collect failed API requests
  page.on('response', resp => {
    if (resp.status() >= 400) {
      apiErrors.push(`${resp.status()} ${resp.request().method()} ${resp.url()}`);
    }
  });

  // ========== STEP 1: Main page ==========
  console.log('=== STEP 1: Navigate to main page ===');
  try {
    await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });
    await page.screenshot({ path: `${SCREENSHOTS}/01-main-page.png`, fullPage: true });
    console.log('  Screenshot: 01-main-page.png');
    console.log('  URL:', page.url());
    console.log('  Title:', await page.title());
  } catch (e) {
    console.log('  ERROR loading main page:', e.message);
    bugs.push({ severity: 'critical', issue: 'Main page failed to load', detail: e.message });
  }

  // ========== STEP 2: Check if login is required ==========
  console.log('\n=== STEP 2: Check auth state ===');
  const loginForm = await page.$('input[type="password"], input[name="password"], form[action*="login"]');
  if (loginForm) {
    console.log('  Login form detected — attempting login');
    try {
      await page.fill('input[name="username"], input[type="email"], input[name="email"]', 'admin@test.com');
      await page.fill('input[type="password"], input[name="password"]', 'admin123');
      await page.click('button[type="submit"]');
      await page.waitForTimeout(2000);
      await page.screenshot({ path: `${SCREENSHOTS}/02-after-login.png`, fullPage: true });
      console.log('  Screenshot: 02-after-login.png');
    } catch (e) {
      console.log('  Login attempt failed:', e.message);
      // Try register instead
    }
  } else {
    console.log('  No login form — app may be open access or token-based');
  }

  // ========== STEP 3: Register if needed ==========
  console.log('\n=== STEP 3: Check for register/signup ===');
  const registerLink = await page.$('a[href*="register"], a[href*="signup"], button:has-text("注册"), button:has-text("Register"), button:has-text("Sign up")');
  if (registerLink) {
    console.log('  Register link found — trying to register');
    try {
      await registerLink.click();
      await page.waitForTimeout(1000);
      await page.screenshot({ path: `${SCREENSHOTS}/03-register.png`, fullPage: true });
      console.log('  Screenshot: 03-register.png');
      console.log('  URL:', page.url());
    } catch (e) {
      console.log('  Register navigation failed:', e.message);
    }
  }

  // ========== STEP 4: Navigate to chat/conversations ==========
  console.log('\n=== STEP 4: Navigate to chat ===');
  try {
    // Try various chat/conversation links
    const chatSelectors = [
      'a[href*="chat"]', 'a[href*="conversation"]',
      'button:has-text("新对话")', 'button:has-text("New Chat")', 'button:has-text("新对话")',
      'a:has-text("对话")', 'a:has-text("Chat")',
      'nav a:first-child', '[data-testid="new-chat"]'
    ];
    let navigated = false;
    for (const sel of chatSelectors) {
      const el = await page.$(sel);
      if (el) {
        await el.click();
        await page.waitForTimeout(1500);
        navigated = true;
        console.log(`  Clicked: ${sel}`);
        break;
      }
    }
    if (!navigated) {
      // Try direct navigation
      await page.goto(`${BASE}/chat`, { waitUntil: 'networkidle', timeout: 10000 }).catch(() => {});
    }
    await page.screenshot({ path: `${SCREENSHOTS}/04-chat-page.png`, fullPage: true });
    console.log('  Screenshot: 04-chat-page.png');
    console.log('  URL:', page.url());
  } catch (e) {
    console.log('  Chat navigation error:', e.message);
  }

  // ========== STEP 5: Send a test message ==========
  console.log('\n=== STEP 5: Send test message ===');
  try {
    const inputSelectors = [
      'textarea', 'input[type="text"]', '[contenteditable="true"]',
      'textarea[placeholder]', 'input[placeholder*="message"], input[placeholder*="消息"]'
    ];
    let input = null;
    for (const sel of inputSelectors) {
      input = await page.$(sel);
      if (input) {
        console.log(`  Found input: ${sel}`);
        break;
      }
    }

    if (input) {
      await input.click();
      await input.fill('Hello, this is a test message for bug testing.');
      await page.waitForTimeout(500);

      // Find and click send button
      const sendSelectors = [
        'button[type="submit"]', 'button:has-text("发送")', 'button:has-text("Send")',
        'button[aria-label*="send"], button[aria-label*="Send"]',
        'form button:last-child'
      ];
      let sent = false;
      for (const sel of sendSelectors) {
        const btn = await page.$(sel);
        if (btn) {
          await btn.click();
          sent = true;
          console.log(`  Clicked send: ${sel}`);
          break;
        }
      }
      if (!sent) {
        await input.press('Enter');
        console.log('  Pressed Enter to send');
      }

      // Wait for response
      await page.waitForTimeout(5000);
      await page.screenshot({ path: `${SCREENSHOTS}/05-message-sent.png`, fullPage: true });
      console.log('  Screenshot: 05-message-sent.png');
    } else {
      console.log('  No input field found');
      bugs.push({ severity: 'high', issue: 'No chat input field found' });
    }
  } catch (e) {
    console.log('  Send message error:', e.message);
  }

  // ========== STEP 6: Test delete conversation ==========
  console.log('\n=== STEP 6: Test delete conversation ===');
  try {
    // Look for sidebar conversation items
    const sidebarSelectors = [
      'aside', 'nav', '[class*="sidebar"]', '[class*="Sidebar"]',
      '[class*="conversation"]', '[class*="chat-list"]'
    ];

    // First, find conversation items
    const convItems = await page.$$('aside a, aside button, [class*="conversation"] a, [class*="sidebar"] a, nav a');
    console.log(`  Found ${convItems.length} sidebar/nav items`);

    if (convItems.length > 0) {
      // Hover over the first conversation item to reveal trash icon
      const firstConv = convItems[0];
      const convText = await firstConv.textContent();
      console.log(`  Hovering over: "${convText?.trim().slice(0, 50)}"`);

      await firstConv.hover();
      await page.waitForTimeout(500);
      await page.screenshot({ path: `${SCREENSHOTS}/06-hover-conversation.png`, fullPage: true });
      console.log('  Screenshot: 06-hover-conversation.png (hover state)');

      // Look for trash/delete button
      const trashBtn = await page.$('button:has(svg.lucide-trash), [class*="trash"], button:has-text("删除"), button[aria-label*="delete"], button[aria-label*="Delete"]');

      if (trashBtn) {
        console.log('  Trash button found!');
        const isVisible = await trashBtn.isVisible();
        console.log(`  Trash button visible: ${isVisible}`);

        if (isVisible) {
          await trashBtn.click();
          console.log('  Clicked trash button');
          await page.waitForTimeout(2000);
          await page.screenshot({ path: `${SCREENSHOTS}/07-after-delete.png`, fullPage: true });
          console.log('  Screenshot: 07-after-delete.png');

          // Check if conversation is gone
          const convAfter = await page.$$('aside a, aside button, [class*="conversation"] a, [class*="sidebar"] a');
          console.log(`  Conversation items after delete: ${convAfter.length} (was ${convItems.length})`);

          if (convAfter.length >= convItems.length) {
            bugs.push({ severity: 'high', issue: 'Delete conversation does not work', detail: 'Conversation count unchanged after clicking delete' });
            console.log('  ❌ BUG CONFIRMED: Conversation NOT deleted');
          } else {
            console.log('  ✅ Conversation deleted successfully');
          }
        } else {
          // Try to force-click even if not visible
          await trashBtn.click({ force: true });
          console.log('  Force-clicked trash button (was hidden)');
          await page.waitForTimeout(2000);
          await page.screenshot({ path: `${SCREENSHOTS}/07b-force-delete.png`, fullPage: true });

          const convAfter = await page.$$('aside a, aside button, [class*="conversation"] a, [class*="sidebar"] a');
          if (convAfter.length >= convItems.length) {
            bugs.push({ severity: 'high', issue: 'Delete conversation does not work (force click)', detail: 'Even force-clicking trash button does not delete' });
            console.log('  ❌ BUG: Force-click also fails');
          }
        }
      } else {
        console.log('  ❌ No trash/delete button found on hover');
        bugs.push({ severity: 'high', issue: 'Delete button not found', detail: 'Trash icon not visible or not rendered on hover' });
      }
    } else {
      console.log('  No conversation items found in sidebar');
    }
  } catch (e) {
    console.log('  Delete test error:', e.message);
    bugs.push({ severity: 'medium', issue: 'Delete test error', detail: e.message });
  }

  // ========== STEP 7: Test navigation ==========
  console.log('\n=== STEP 7: Test navigation links ===');
  try {
    const links = await page.$$('a[href]');
    const brokenLinks = [];
    for (const link of links.slice(0, 15)) {
      const href = await link.getAttribute('href');
      const text = (await link.textContent())?.trim().slice(0, 30);
      if (href && href.startsWith('/') && !href.startsWith('//')) {
        try {
          const resp = await page.goto(`${BASE}${href}`, { waitUntil: 'domcontentloaded', timeout: 8000 });
          if (resp && resp.status() >= 400) {
            brokenLinks.push({ href, text, status: resp.status() });
          }
        } catch (e) {
          brokenLinks.push({ href, text, error: 'timeout' });
        }
      }
    }
    if (brokenLinks.length > 0) {
      console.log(`  Found ${brokenLinks.length} broken links:`);
      brokenLinks.forEach(l => {
        console.log(`    ${l.status || l.error} — ${l.href} ("${l.text}")`);
        bugs.push({ severity: 'medium', issue: `Broken link: ${l.href}`, detail: `${l.status || l.error}` });
      });
    } else {
      console.log('  All tested links OK');
    }
  } catch (e) {
    console.log('  Navigation test error:', e.message);
  }

  // ========== STEP 8: Check projects page ==========
  console.log('\n=== STEP 8: Test projects page ===');
  try {
    await page.goto(`${BASE}/projects`, { waitUntil: 'networkidle', timeout: 10000 });
    await page.screenshot({ path: `${SCREENSHOTS}/08-projects.png`, fullPage: true });
    console.log('  Screenshot: 08-projects.png');
    console.log('  URL:', page.url());
  } catch (e) {
    console.log('  Projects page error:', e.message);
  }

  // ========== SUMMARY ==========
  console.log('\n' + '='.repeat(60));
  console.log('TEST SUMMARY');
  console.log('='.repeat(60));
  console.log(`Console errors: ${consoleErrors.length}`);
  consoleErrors.slice(0, 10).forEach(e => console.log(`  ❌ ${e.slice(0, 120)}`));
  console.log(`\nAPI errors (4xx/5xx): ${apiErrors.length}`);
  apiErrors.slice(0, 10).forEach(e => console.log(`  ❌ ${e}`));
  console.log(`\nBugs found: ${bugs.length}`);
  bugs.forEach(b => console.log(`  [${b.severity}] ${b.issue} — ${b.detail || ''}`));
  console.log('='.repeat(60));

  await browser.close();
})();
