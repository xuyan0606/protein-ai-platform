import { chromium } from 'playwright';

const BASE = 'http://localhost:3000';
const API = 'http://localhost:8000';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  // Login
  const r1 = await fetch(`${API}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' })
  });
  const { access_token: token } = await r1.json();

  // Clear old + create fresh
  const old = await fetch(`${API}/api/conversations`, { headers: { Authorization: `Bearer ${token}` } });
  const oldList = await old.json();
  for (const c of oldList) { await fetch(`${API}/api/conversations/${c.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }); }

  for (let i = 1; i <= 3; i++) {
    await fetch(`${API}/api/conversations`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ title: `DEL-TEST-${i}` })
    });
  }

  // Navigate
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);
  await page.goto(`${BASE}/chat/agent`, { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(2000);

  // Get visible group elements with their trash buttons
  const targetInfo = await page.evaluate(() => {
    const results = [];
    for (const g of document.querySelectorAll('[class*="group"]')) {
      if (!g.textContent?.includes('DEL-TEST')) continue;
      const rect = g.getBoundingClientRect();
      if (rect.width === 0) continue; // Skip invisible duplicates

      // Find trash button inside
      const trashBtn = g.querySelector('button');
      const trashRect = trashBtn?.getBoundingClientRect();
      results.push({
        text: g.textContent.trim().slice(0, 30),
        groupX: rect.x,
        groupY: rect.y,
        groupW: rect.width,
        groupH: rect.height,
        trashHTML: trashBtn?.innerHTML?.slice(0, 80),
        trashX: trashRect?.x,
        trashY: trashRect?.y,
        trashW: trashRect?.width,
        trashH: trashRect?.height,
      });
    }
    return results;
  });
  console.log('Visible delete targets:', JSON.stringify(targetInfo, null, 2));

  // Delete each conversation by clicking its trash button at coordinates
  for (const target of targetInfo) {
    console.log(`\nDeleting: "${target.text}"`);

    if (target.trashX !== undefined && target.trashW > 0) {
      // Click at the center of the trash button
      const cx = target.trashX + target.trashW / 2;
      const cy = target.trashY + target.trashH / 2;
      console.log(`  Clicking trash at (${cx.toFixed(0)}, ${cy.toFixed(0)})`);

      await page.mouse.click(cx, cy);
      await page.waitForTimeout(1500);
    } else {
      // Trash button has no visible box — need hover first
      console.log('  Trash hidden — hovering group first');
      // Hover center of group
      const gx = target.groupX + target.groupW / 2;
      const gy = target.groupY + target.groupH / 2;
      await page.mouse.move(gx, gy);
      await page.waitForTimeout(800);

      // Now find the newly-visible trash button
      const visibleTrash = await page.evaluate((text) => {
        for (const g of document.querySelectorAll('[class*="group"]')) {
          if (!g.textContent?.includes(text)) continue;
          const rect = g.getBoundingClientRect();
          if (rect.width === 0) continue;
          const btn = g.querySelector('button');
          if (btn) {
            const r = btn.getBoundingClientRect();
            return { x: r.x + r.width/2, y: r.y + r.height/2 };
          }
        }
        return null;
      }, target.text.slice(0, 15));

      if (visibleTrash) {
        console.log(`  Trash now at (${visibleTrash.x.toFixed(0)}, ${visibleTrash.y.toFixed(0)})`);
        await page.mouse.click(visibleTrash.x, visibleTrash.y);
        await page.waitForTimeout(1500);
      }
    }

    // Check if gone
    const gone = !(await page.evaluate((t) => document.body.innerText.includes(t), target.text));
    console.log(`  Gone from UI: ${gone}`);
  }

  // Final state
  const finalList = await (await fetch(`${API}/api/conversations`, { headers: { Authorization: `Bearer ${token}` } })).json();
  console.log(`\n=== FINAL ===`);
  console.log(`API conversations: ${finalList.length}`);
  console.log(finalList.length === 0 ? '✅ Delete works!' : '❌ Conversations not deleted from DB');

  await browser.close();
})();
