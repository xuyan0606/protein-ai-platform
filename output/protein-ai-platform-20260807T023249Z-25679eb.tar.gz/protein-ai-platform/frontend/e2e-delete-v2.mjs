import { chromium } from 'playwright';

const BASE = 'http://localhost:3000';
const API = 'http://localhost:8000';
const SS = '/Users/xuyan/科为博/05自动化程序/04研发工作区/酶蛋白AI平台/frontend/test-results';
const bugs = [];

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  const consoleErrors = [], apiErrors = [];
  page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text()); });
  page.on('response', r => { if (r.status() >= 400) apiErrors.push(`${r.status()} ${r.request().method()} ${r.url()}`); });

  // Step 1: Login via API
  console.log('=== 1. Login ===');
  const loginResp = await fetch(`${API}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' }),
  });
  const { access_token: token } = await loginResp.json();
  console.log(`  Token: ${token.slice(0, 15)}...`);

  // Step 2: Create test conversations via API
  console.log('\n=== 2. Create test conversations via API ===');
  const convIds = [];
  for (let i = 1; i <= 3; i++) {
    const r = await fetch(`${API}/api/conversations`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ title: `BUG TEST ${i}` }),
    });
    const d = await r.json();
    convIds.push(d.id);
    console.log(`  Created: "${d.title}" (id=${d.id})`);
  }

  // Step 3: Navigate to base URL, inject token, then go to chat
  console.log('\n=== 3. Navigate to /chat/agent ===');
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);

  // Navigate directly to chat page
  await page.goto(`${BASE}/chat/agent`, { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(3000);
  await page.screenshot({ path: `${SS}/20-chat-agent.png`, fullPage: true });
  console.log('  Screenshot: 20-chat-agent.png');
  console.log('  URL:', page.url());

  // Step 4: Dump page structure
  console.log('\n=== 4. Page structure ===');
  const bodyText = await page.evaluate(() => document.body.innerText.slice(0, 500));
  console.log('  Body text:', bodyText);

  const allButtons = await page.$$('button');
  console.log(`  Total buttons: ${allButtons.length}`);
  for (const btn of allButtons) {
    const text = (await btn.textContent())?.trim().slice(0, 40);
    const classes = (await btn.getAttribute('class'))?.slice(0, 60);
    const box = await btn.boundingBox();
    console.log(`    "${text}" class="${classes}" visible=${!!box}`);
  }

  // Step 5: Find conversation items
  console.log('\n=== 5. Find conversation items ===');
  // Look for elements containing "BUG TEST"
  const allElements = await page.$$('div, button, a, li, span');
  let conversationButtons = [];
  for (const el of allElements) {
    const text = (await el.textContent())?.trim() || '';
    if (text.includes('BUG TEST')) {
      const tag = await el.evaluate(e => e.tagName);
      const cls = (await el.getAttribute('class'))?.slice(0, 60);
      const box = await el.boundingBox();
      console.log(`  Found "${text.slice(0, 50)}" <${tag}> class="${cls}" visible=${!!box}`);
      conversationButtons.push({ el, text, tag, box });
    }
  }

  if (conversationButtons.length === 0) {
    console.log('  NO "BUG TEST" elements found!');
    bugs.push({ severity: 'critical', issue: 'Conversation list empty', detail: 'API conversations exist but not rendered' });
  }

  // Step 6: Test delete on first conversation
  console.log('\n=== 6. Test delete ===');
  if (conversationButtons.length > 0) {
    const { el, text } = conversationButtons[0];
    console.log(`  Attempting delete on: "${text}"`);

    // Hover over the element
    await el.hover();
    await page.waitForTimeout(800);
    await page.screenshot({ path: `${SS}/21-hover.png`, fullPage: true });
    console.log('  Screenshot: 21-hover.png');

    // After hover, look for trash button
    // Find all buttons that appeared or changed
    const buttonsAfterHover = await page.$$('button');
    console.log('  Buttons after hover:');
    for (const btn of buttonsAfterHover) {
      const t = (await btn.textContent())?.trim().slice(0, 30);
      const html = (await btn.innerHTML()).slice(0, 80);
      const box = await btn.boundingBox();
      if (box) {
        console.log(`    "${t}" html="${html}" box=(${box.x.toFixed(0)},${box.y.toFixed(0)} ${box.width}x${box.height})`);
      }
    }

    // Try to click trash via SVG selector
    const trashBtn = await page.$('svg.lucide-trash-2, svg[class*="trash"]');
    if (trashBtn) {
      console.log('  Found trash SVG!');
      // Need to click the parent button
      const parentBtn = await trashBtn.evaluateHandle(el => el.closest('button'));
      if (parentBtn) {
        const parentEl = parentBtn.asElement();
        if (parentEl) {
          await parentEl.click({ force: true });
          console.log('  Clicked trash button (parent of SVG)');
        }
      }
    } else {
      // Try force-clicking any button with class containing 'opacity'
      const opacityBtn = await page.$('button[class*="opacity-0"]');
      if (opacityBtn) {
        await opacityBtn.click({ force: true });
        console.log('  Force-clicked opacity-0 button');
      } else {
        console.log('  ❌ No trash button found');
        bugs.push({ severity: 'critical', issue: 'Delete button (trash icon) not rendered on hover' });
      }
    }

    await page.waitForTimeout(2000);
    await page.screenshot({ path: `${SS}/22-after-delete-click.png`, fullPage: true });
    console.log('  Screenshot: 22-after-delete-click.png');

    // Verify: reload and check if BUG TEST 1 is gone
    await page.goto(`${BASE}/chat/agent`, { waitUntil: 'networkidle', timeout: 15000 });
    await page.waitForTimeout(2000);
    const afterText = await page.evaluate(() => document.body.innerText);
    const stillThere = afterText.includes('BUG TEST 1');
    console.log(`  "BUG TEST 1" still visible: ${stillThere}`);
    if (stillThere) {
      bugs.push({ severity: 'critical', issue: 'Delete does not work', detail: 'Conversation remains visible after delete' });
    } else {
      console.log('  ✅ Delete worked!');
    }
  }

  // Step 7: API cross-check
  console.log('\n=== 7. Cross-check via API ===');
  const listResp = await fetch(`${API}/api/conversations`, { headers: { 'Authorization': `Bearer ${token}` } });
  const list = await listResp.json();
  console.log(`  Conversations in DB: ${list.length}`);
  console.log(`  IDs: ${list.map(c => c.id).join(', ')}`);

  // ========== Summary ==========
  console.log('\n' + '='.repeat(60));
  console.log('BUG HUNT RESULTS');
  console.log('='.repeat(60));
  console.log(`Console errors: ${consoleErrors.length}`);
  consoleErrors.slice(0, 5).forEach(e => console.log(`  ❌ ${e.slice(0, 150)}`));
  console.log(`API errors: ${apiErrors.length}`);
  apiErrors.forEach(e => console.log(`  ❌ ${e}`));
  console.log(`Bugs: ${bugs.length}`);
  bugs.forEach(b => console.log(`  [${b.severity.toUpperCase()}] ${b.issue}\n    ${b.detail || ''}`));
  if (bugs.length === 0) console.log('  ✅ No bugs found');
  console.log('='.repeat(60));

  await browser.close();
})();
