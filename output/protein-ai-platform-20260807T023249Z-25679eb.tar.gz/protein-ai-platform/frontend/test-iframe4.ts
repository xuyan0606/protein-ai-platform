import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Step 1: Login on frontend
  console.log('1. Login on frontend...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);
  
  const cookies = await context.cookies();
  console.log('Cookies:', JSON.stringify(cookies.map(c => ({ name: c.name, domain: c.domain, sameSite: c.sameSite })), null, 2));

  // Step 2: Navigate to /wiki
  console.log('\n2. Navigate to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(3000);
  
  const currentUrl = page.url();
  console.log('Current URL:', currentUrl);
  
  // Check iframe
  const iframe = await page.$('iframe');
  if (!iframe) {
    console.log('ERROR: No iframe found');
    await page.screenshot({ path: '/tmp/wiki-no-iframe.png', fullPage: true });
    await browser.close();
    return;
  }
  
  const frame = await iframe.contentFrame();
  if (!frame) {
    console.log('ERROR: Cannot access iframe content (cross-origin?)');
    await page.screenshot({ path: '/tmp/wiki-cross-origin.png', fullPage: true });
    await browser.close();
    return;
  }
  
  const iframeUrl = frame.url();
  const iframeTitle = await frame.title();
  console.log('Iframe URL:', iframeUrl);
  console.log('Iframe Title:', iframeTitle);
  
  // Wait for potential redirects in the iframe
  console.log('\n3. Waiting for iframe redirects...');
  await page.waitForTimeout(5000);
  
  const finalUrl = frame.url();
  const finalTitle = await frame.title();
  console.log('Final Iframe URL:', finalUrl);
  console.log('Final Iframe Title:', finalTitle);
  
  // Check if iframe shows Outline login or dashboard
  if (finalUrl.includes('/auth/oidc.callback') || finalUrl.includes('/wiki-proxy') && finalTitle !== 'Outline') {
    console.log('SUCCESS: Likely on Outline dashboard');
  } else if (finalUrl.includes('/api/oidc/authorize')) {
    console.log('STUCK: Iframe still on OIDC authorize page');
  } else {
    console.log('STATE: on', finalUrl);
  }
  
  // Check if the page inside the iframe has "Continue with Protein AI" button
  try {
    const loginBtn = await frame.$('a[href*="oidc"], button:has-text("Protein AI"), a:has-text("Continue")');
    if (loginBtn) {
      console.log('FOUND: Outline login button visible - SSO not completed');
    } else {
      console.log('No Outline login button - might be on dashboard');
    }
  } catch (e) {
    console.log('Error checking iframe content:', e);
  }
  
  await page.screenshot({ path: '/tmp/wiki-iframe-full.png', fullPage: true });
  await browser.close();
  console.log('\nDone. Screenshot saved.');
})();
