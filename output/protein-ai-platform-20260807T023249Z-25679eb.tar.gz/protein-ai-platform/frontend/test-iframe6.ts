import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Try to access /wiki without login
  console.log('1. Access /wiki without login...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);
  
  console.log('URL:', page.url());
  if (page.url().includes('/login')) {
    console.log('✅ Correctly redirected to login page');
  } else {
    console.log('⚠️  Not redirected, URL:', page.url());
  }

  await browser.close();
})();
