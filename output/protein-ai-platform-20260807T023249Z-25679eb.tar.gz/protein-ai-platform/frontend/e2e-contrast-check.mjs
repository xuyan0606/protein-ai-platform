import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const r1 = await fetch('http://localhost:8000/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' })
  });
  const { access_token: token } = await r1.json();
  await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);
  await page.goto('http://localhost:3000/chat/agent', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(2000);

  const checks = await page.evaluate(() => {
    const results = [];

    // Pipeline stage labels
    document.querySelectorAll('span').forEach(el => {
      const stage = el.textContent?.trim();
      if (!stage || !['Routing','Researching','Planning','Executing','Synthesizing','Complete'].includes(stage)) return;
      const style = window.getComputedStyle(el);
      results.push({ type: 'Stage', text: stage, color: style.color, weight: style.fontWeight });
    });

    // Category buttons
    document.querySelectorAll('button').forEach(btn => {
      const text = btn.textContent?.trim();
      if (!text || !/^[a-z]+ \(\d+\)$/.test(text)) return;
      const style = window.getComputedStyle(btn);
      const isActive = style.backgroundColor === 'rgb(37, 99, 235)';
      results.push({ type: 'Category', text, color: style.color, bg: style.backgroundColor, active: isActive });
    });

    return results;
  });

  console.log('=== Contrast Verification ===');
  checks.forEach(c => {
    const m = c.color.match(/[\d.]+/g);
    const r = m ? +m[0] : 0, g = m ? +m[1] : 0, b = m ? +m[2] : 0;
    const lum = 0.299*r + 0.587*g + 0.114*b;
    const ok = c.type === 'Category' && c.active ? true : lum < 100;
    console.log((ok ? '✅' : '⚠️') + ' [' + c.type + '] ' + c.text.padEnd(18) + ' color=' + c.color + ' weight=' + (c.weight || '-') + ' lum=' + lum.toFixed(0));
  });

  await browser.close();
})();
