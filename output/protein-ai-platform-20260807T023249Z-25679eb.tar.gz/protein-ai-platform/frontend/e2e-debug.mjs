import { chromium } from 'playwright';

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

// Monitor network requests
const apiCalls = [];
page.on('response', resp => {
  if (resp.url().includes('/api/')) {
    apiCalls.push({ url: resp.url(), status: resp.status() });
  }
});

await page.goto('http://localhost:3000/data');
await page.waitForTimeout(2000);

// Check what tabs/buttons exist
const tabTexts = await page.locator('button, [role="tab"]').allTextContents();
console.log('Tabs/buttons:', tabTexts);

// Try clicking "蛋白质" tab if available
const proteinTab = page.locator('button:has-text("蛋白质")');
if (await proteinTab.isVisible()) {
  await proteinTab.click();
  await page.waitForTimeout(2000);
  console.log('Clicked 蛋白质 tab');
}

// Check the page content for PDB count display
const mainContent = await page.locator('main, .container, [class*="browser"]').first().textContent().catch(() => '');
console.log('Main content (first 500 chars):', mainContent?.substring(0, 500));

// Check if there are protein cards/rows
const cardCount = await page.locator('[class*="card"], [class*="row"], [class*="item"]').count();
console.log('Card/row/item elements:', cardCount);

// Check API calls
console.log('API calls:', apiCalls);

// Try clicking 统计 tab
const statsTab = page.locator('button:has-text("统计")');
if (await statsTab.isVisible()) {
  await statsTab.click();
  await page.waitForTimeout(3000);
  const statsContent = await page.textContent('body');
  console.log('Stats content (first 800 chars):', statsContent?.substring(0, 800));
}

await browser.close();
