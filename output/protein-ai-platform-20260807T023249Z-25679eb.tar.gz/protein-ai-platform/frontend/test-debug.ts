import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Track all frame navigations
  page.on('framenavigated', frame => {
    if (frame !== page.mainFrame()) {
      console.log('IFRAME NAVIGATED:', frame.url());
    }
  });

  // Login
  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Go to wiki
  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  
  // Wait and track navigation
  for (let i = 0; i < 10; i++) {
    await page.waitForTimeout(1000);
    const iframe = await page.$('iframe');
    if (iframe) {
      const frame = await iframe.contentFrame();
      if (frame) {
        console.log(`  [${i}s] Iframe URL: ${frame.url()}`);
      }
    }
  }

  await page.screenshot({ path: '/tmp/wiki-debug.png', fullPage: true });
  await browser.close();
})();
