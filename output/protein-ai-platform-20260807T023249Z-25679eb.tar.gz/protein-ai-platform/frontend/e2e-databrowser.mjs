import { chromium } from 'playwright';

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

await page.goto('http://localhost:3000/data');
await page.waitForTimeout(3000);
await page.screenshot({ path: '/tmp/e2e-databrowser.png', fullPage: true });
console.log('1. Data Browser: OK');

const searchBox = page.locator('input').first();
if (await searchBox.isVisible()) {
  await searchBox.fill('Lysozyme');
  await page.keyboard.press('Enter');
  await page.waitForTimeout(3000);
  await page.screenshot({ path: '/tmp/e2e-search.png', fullPage: true });
  console.log('2. Search: OK');
}

const link = page.locator('text=P00698').first();
if (await link.isVisible({ timeout: 3000 })) {
  await link.click();
  await page.waitForTimeout(3000);
  await page.screenshot({ path: '/tmp/e2e-detail.png', fullPage: true });
  console.log('3. Detail: OK');
}

const bodyText = await page.textContent('body');
console.log('4. PDB visible:', bodyText.includes('PDB') || bodyText.includes('pdb') || bodyText.includes('结构'));
console.log('5. P00698 visible:', bodyText.includes('P00698'));

await browser.close();
console.log('Done');
