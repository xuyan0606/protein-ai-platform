import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Login
  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Go to wiki
  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(3000);

  // Check iframe
  const iframe = await page.$('iframe');
  if (iframe) {
    const frame = await iframe.contentFrame();
    if (frame) {
      const url = frame.url();
      const title = await frame.title();
      console.log('Iframe URL:', url);
      console.log('Iframe Title:', title);
      
      if (url === 'about:blank' || url.includes('chrome-error')) {
        console.log('ERROR: Iframe failed to load');
      } else {
        console.log('SUCCESS: Outline loaded in iframe');
      }
    } else {
      console.log('Could not access iframe content');
    }
  } else {
    console.log('No iframe found');
  }

  await page.screenshot({ path: '/tmp/wiki-final.png', fullPage: true });
  await browser.close();
  console.log('3. Done');
})();
