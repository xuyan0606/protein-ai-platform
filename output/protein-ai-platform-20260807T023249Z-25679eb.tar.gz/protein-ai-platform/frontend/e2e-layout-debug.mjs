import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  // Login
  const r1 = await fetch('http://localhost:8000/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' })
  });
  const { access_token: token } = await r1.json();

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);
  await page.goto('http://localhost:3000/chat/agent', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(3000);

  // Check for layout/display issues
  const issues = await page.evaluate(() => {
    const found = [];

    // 1. Check if any text is "undefined" or "null"
    const allText = document.body.innerText;
    if (allText.includes('undefined')) found.push('BODY CONTAINS "undefined" text');
    if (allText.includes('null')) found.push('BODY CONTAINS "null" text');

    // 2. Check elements with 0 height/width in visible area
    document.querySelectorAll('*').forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) return; // skip invisible
      const style = window.getComputedStyle(el);
      if (style.color === 'transparent' || style.opacity === '0') {
        if (el.textContent?.trim() && el.textContent.trim().length > 2) {
          found.push(`TRANSPARENT TEXT: "${el.textContent.trim().slice(0, 40)}" at (${rect.x},${rect.y})`);
        }
      }
    });

    // 3. Check for overlapping elements (input overlapping button, etc)
    const interactiveElements = [];
    document.querySelectorAll('button, input, textarea, select, a').forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      interactiveElements.push({
        tag: el.tagName,
        text: (el.textContent || '').trim().slice(0, 30),
        rect: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
      });
    });

    // Find overlapping interactive elements
    for (let i = 0; i < interactiveElements.length; i++) {
      for (let j = i + 1; j < interactiveElements.length; j++) {
        const a = interactiveElements[i].rect;
        const b = interactiveElements[j].rect;
        if (a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y) {
          if (a.x === 0 && a.y === 0) continue; // hidden elements
          found.push(`OVERLAP: "${interactiveElements[i].tag} ${interactiveElements[i].text}" with "${interactiveElements[j].tag} ${interactiveElements[j].text}"`);
          if (found.length > 20) break;
        }
      }
      if (found.length > 20) break;
    }

    // 4. Check for elements outside viewport
    const vp = { w: 1440, h: 900 };
    let outOfView = 0;
    document.querySelectorAll('button, input, textarea').forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.x + rect.w < 0 || rect.x > vp.w || rect.y + rect.h < 0 || rect.y > vp.h) {
        outOfView++;
      }
    });
    if (outOfView > 0) found.push(`${outOfView} interactive elements outside viewport`);

    // 5. Check tool list items specifically
    const toolItems = document.querySelectorAll('[class*="tool"] span, [class*="Tool"] span, button span');
    const emptySpans = [];
    document.querySelectorAll('span').forEach(s => {
      const rect = s.getBoundingClientRect();
      if (rect.width > 10 && rect.height > 5) {
        if (!s.textContent?.trim()) {
          emptySpans.push(s.className.slice(0, 40));
        }
      }
    });
    if (emptySpans.length > 0) found.push(`${emptySpans.length} visible empty spans`);

    return found;
  });

  console.log('=== UI ISSUES FOUND ===');
  if (issues.length === 0) {
    console.log('No obvious layout/text issues detected.');
  } else {
    issues.forEach(i => console.log('  ❌', i));
  }

  // Get the specific tool list HTML for inspection
  const toolListHTML = await page.evaluate(() => {
    const toolPanel = document.querySelector('[class*="ToolPanel"]');
    if (toolPanel) return toolPanel.innerHTML.slice(0, 1000);
    // Try finding by content
    for (const el of document.querySelectorAll('div')) {
      if (el.textContent?.includes('predict_properties') && el.children.length < 5) {
        return el.outerHTML.slice(0, 500);
      }
    }
    return 'NOT FOUND';
  });
  console.log('\n=== Tool panel HTML ===');
  console.log(toolListHTML);

  await browser.close();
})();
