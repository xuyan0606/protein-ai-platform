import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Collect ALL console messages
  const logs: string[] = [];
  page.on('console', msg => {
    logs.push(`[${msg.type()}] ${msg.text()}`);
  });
  page.on('pageerror', err => {
    logs.push(`[PAGE ERROR] ${err.message}`);
  });

  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'load', timeout: 10000 });
  await page.waitForTimeout(10000);

  // Check iframe
  const iframe = await page.$('iframe');
  if (iframe) {
    const frame = await iframe.contentFrame();
    if (frame) {
      console.log('URL:', frame.url());
      const rootEl = await frame.$('#root');
      if (rootEl) {
        const html = await rootEl.innerHTML();
        console.log('Root HTML length:', html.length);
        console.log('Root HTML preview:', html.substring(0, 200));
      }
    }
  }

  console.log('\nConsole logs:');
  logs.forEach(l => console.log(' ', l));

  await page.screenshot({ path: '/tmp/wiki-jsdebug.png', fullPage: true });
  await browser.close();
})();
