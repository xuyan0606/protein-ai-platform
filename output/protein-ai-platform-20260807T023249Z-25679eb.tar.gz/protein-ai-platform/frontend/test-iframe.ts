import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  // Login
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Go to wiki page
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);

  // Check iframe content
  const iframe = await page.$('iframe');
  if (iframe) {
    const frame = await iframe.contentFrame();
    if (frame) {
      const url = frame.url();
      console.log('Iframe URL:', url);
      const title = await frame.title();
      console.log('Iframe Title:', title);
      const bodyText = await frame.textContent('body');
      console.log('Iframe body (first 300):', bodyText?.substring(0, 300));
    }
  }
  await page.screenshot({ path: '/tmp/wiki-iframe-debug.png', fullPage: true });
  await browser.close();
})();
