import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: true });
  const page = await context.newPage();

  page.on('framenavigated', frame => {
    if (frame !== page.mainFrame()) {
      console.log('IFRAME:', frame.url());
    }
  });

  console.log('1. Login...');
  await page.goto('http://localhost:3000/login', { waitUntil: 'networkidle' });
  await page.fill('input[type="email"]', 'admin@protein.ai');
  await page.fill('input[type="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  console.log('2. Go to /wiki...');
  await page.goto('http://localhost:3000/wiki', { waitUntil: 'load', timeout: 10000 });
  await page.waitForTimeout(8000);

  const iframe = await page.$('iframe');
  if (iframe) {
    const frame = await iframe.contentFrame();
    if (frame) {
      console.log('Final URL:', frame.url());
      console.log('Title:', await frame.title());
      
      const bodyText = await frame.textContent('body') || '';
      console.log('Body length:', bodyText.length);
      console.log('Has login:', bodyText.includes('Continue with'));
      console.log('Has dashboard:', bodyText.includes('Home') || bodyText.includes('Collection'));
    }
  }

  await page.screenshot({ path: '/tmp/wiki-simple.png', fullPage: true });
  await browser.close();
  console.log('Done');
})();
