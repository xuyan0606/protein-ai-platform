import { chromium } from 'playwright';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  // Login
  const r1 = await fetch('http://localhost:8000/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'test@bug.com', password: 'test1234' })
  });
  const { access_token: token } = await r1.json();

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle', timeout: 15000 });
  await page.evaluate(tok => localStorage.setItem('token', tok), token);
  await page.goto('http://localhost:3000/chat/agent', { waitUntil: 'networkidle', timeout: 15000 });
  await page.waitForTimeout(3000);

  await page.screenshot({ path: '/Users/xuyan/科为博/05自动化程序/04研发工作区/酶蛋白AI平台/frontend/test-results/chat-agent-debug.png', fullPage: true });
  console.log('Screenshot saved');

  // Get body text and tool-related content
  const body = await page.evaluate(() => {
    // Find all text content
    const allText = document.body.innerText;

    // Find tool panel content
    const toolPanelElements = document.querySelectorAll('[class*="tool"], [class*="Tool"], [class*="panel"]');
    const toolTexts = [];
    toolPanelElements.forEach(el => {
      const t = el.textContent?.trim().slice(0, 100);
      if (t && t.length > 2) toolTexts.push(t);
    });

    return { allText: allText.slice(0, 2000), toolTexts: toolTexts.slice(0, 15) };
  });

  console.log('=== Body text (first 2000 chars) ===');
  console.log(body.allText);
  console.log('\n=== Tool panel text ===');
  body.toolTexts.forEach(t => console.log('  -', t));

  // Check console errors
  page.on('console', msg => {
    if (msg.type() === 'error') console.log('CONSOLE ERROR:', msg.text());
  });

  await browser.close();
})();
