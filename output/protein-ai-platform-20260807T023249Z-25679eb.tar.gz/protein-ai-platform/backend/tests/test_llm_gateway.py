"""Regression tests for the unified LLM gateway and chat model-id interface."""

from __future__ import annotations

import asyncio
import json
import time
from types import SimpleNamespace

import pytest

from app.core.security import create_access_token
from app.models.user import User


async def _create_user(session, email: str = "gateway@example.com") -> User:
    user = User(
        email=email,
        hashed_password=User.hash_password("password123"),
        name="Gateway User",
    )
    session.add(user)
    await session.flush()
    return user


def test_llm_gateway_complete_sync_resolves_model_id(monkeypatch):
    from app.core import llm
    from app.core import llm_gateway as gateway_module

    captured: dict = {}

    monkeypatch.setattr(gateway_module, "is_model_available", lambda provider, model: True)

    def fake_chat_completion_sync(messages, **kwargs):
        captured["messages"] = messages
        captured.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(llm, "chat_completion_sync", fake_chat_completion_sync)

    result = llm.llm_gateway.complete_sync(
        [{"role": "user", "content": "test unified interface"}],
        model_id="gpt55",
        max_tokens=321,
    )

    assert result == {"ok": True}
    assert captured["provider"] == "kuaPao"
    assert captured["model"] == llm.settings.KUAPAO_MODEL
    assert captured["max_tokens"] == 321


def test_llm_gateway_resolves_kuaipao_sol_model(monkeypatch):
    from app.core import llm
    from app.core import llm_gateway as gateway_module

    captured: dict = {}

    monkeypatch.setattr(gateway_module, "is_model_available", lambda provider, model: True)

    def fake_chat_completion_sync(messages, **kwargs):
        captured["messages"] = messages
        captured.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(llm, "chat_completion_sync", fake_chat_completion_sync)

    result = llm.llm_gateway.complete_sync(
        [{"role": "user", "content": "test sol model"}],
        model_id="gpt56-sol",
        max_tokens=123,
    )

    assert result == {"ok": True}
    assert captured["provider"] == "kuaPao"
    assert captured["model"] == llm.settings.KUAPAO_SOL_MODEL
    assert captured["max_tokens"] == 123


def test_llm_gateway_resolves_gpt56_model(monkeypatch):
    from app.core import llm
    from app.core import llm_gateway as gateway_module

    captured: dict = {}

    monkeypatch.setattr(gateway_module, "is_model_available", lambda provider, model: True)

    def fake_chat_completion_sync(messages, **kwargs):
        captured["messages"] = messages
        captured.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(llm, "chat_completion_sync", fake_chat_completion_sync)

    result = llm.llm_gateway.complete_sync(
        [{"role": "user", "content": "test gpt56 model"}],
        model_id="gpt56",
        max_tokens=456,
    )

    assert result == {"ok": True}
    assert captured["provider"] == "kuaPao"
    assert captured["model"] == llm.settings.KUAPAO_GPT56_MODEL
    assert captured["max_tokens"] == 456


def test_llm_gateway_list_models_reflects_runtime_health(monkeypatch):
    from app.core import llm_gateway as gateway_module

    monkeypatch.setattr(
        gateway_module,
        "is_model_available",
        lambda provider, model: provider == "kuaPao",
    )

    listed = gateway_module.llm_gateway.list_models()
    models = {item["id"]: item for item in listed}

    assert list(models) == ["gpt55", "gpt56", "gpt56-sol"]
    assert models["gpt55"]["available"] is True
    assert models["gpt55"]["name"] == "GPT-5.5"
    assert models["gpt55"]["provider"] == "model-relay"
    assert models["gpt55"]["model"] == "gpt-5.5"
    assert models["gpt56"]["available"] is True
    assert models["gpt56"]["name"] == "GPT-5.6"
    assert models["gpt56"]["provider"] == "model-relay"
    assert models["gpt56"]["model"] == "gpt-5.6-terra"
    assert models["gpt56-sol"]["available"] is True
    assert models["gpt56-sol"]["name"] == "GPT-5.6 sol"
    assert models["gpt56-sol"]["provider"] == "model-relay"
    assert models["gpt56-sol"]["model"] == "gpt-5.6-sol"
    assert "dashscope" not in models
    assert "miniMax" not in models
    assert "deepseek" not in models
    assert all("KuaPao" not in item["name"] for item in models.values())
    public_payload = json.dumps(listed, ensure_ascii=False)
    for hidden_name in ("kuaPao", "KuaPao", "miniMax", "MiniMax", "dashscope", "DashScope", "阿里", "千问"):
        assert hidden_name not in public_payload


def test_candidate_chain_skips_disabled_dashscope(monkeypatch):
    from app.core import llm_policy

    monkeypatch.setattr(llm_policy.settings, "LLM_PROVIDER", "dashscope")
    monkeypatch.setattr(llm_policy.settings, "LLM_MODEL", "qwen3.7-max")
    monkeypatch.setattr(llm_policy.settings, "LLM_FALLBACK_PROVIDER", "dashscope")
    monkeypatch.setattr(llm_policy.settings, "LLM_FALLBACK_MODEL", "qwen-plus")
    monkeypatch.setattr(llm_policy.settings, "LLM_DISABLED_PROVIDERS", "dashscope")
    monkeypatch.setattr(llm_policy.settings, "DASHSCOPE_API_KEY", "configured")
    monkeypatch.setattr(llm_policy.settings, "KUAPAO_API_KEY", "configured")
    monkeypatch.setattr(llm_policy.settings, "DEEPSEEK_API_KEY", "")

    chain = llm_policy.candidate_provider_chain(None, None)

    assert chain
    assert all(provider != "dashscope" for provider, _ in chain)
    assert chain[0] == ("kuaPao", llm_policy.settings.KUAPAO_MODEL)


def test_chat_completion_sync_sets_provider_timeout(monkeypatch):
    from app.core import llm

    captured: dict = {}

    monkeypatch.setattr(llm, "_rate_bucket", SimpleNamespace(consume=lambda tokens: True))
    monkeypatch.setattr(llm, "candidate_provider_chain", lambda provider, model: [("kuaPao", "gpt-5.5")])
    monkeypatch.setattr(llm, "get_api_key", lambda provider: "configured")
    monkeypatch.setattr(llm, "get_api_base", lambda provider: "https://example.test/v1")
    monkeypatch.setattr(llm.settings, "LLM_REQUEST_TIMEOUT", 7)

    def fake_completion(**kwargs):
        captured.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(llm, "completion", fake_completion)

    result = llm.chat_completion_sync(
        [{"role": "user", "content": "test timeout"}],
        max_tokens=12,
    )

    assert result == {"ok": True}
    assert captured["timeout"] == 7


async def test_agent_call_llm_has_coroutine_timeout(monkeypatch):
    from app.core import agent_graph

    orchestrator = agent_graph.AgentOrchestrator()
    monkeypatch.setattr(agent_graph.settings, "LLM_REQUEST_TIMEOUT", 0.01)

    def slow_complete_sync(*args, **kwargs):
        time.sleep(0.1)
        return {"ok": True}

    monkeypatch.setattr(agent_graph.llm_gateway, "complete_sync", slow_complete_sync)

    with pytest.raises(asyncio.TimeoutError):
        await orchestrator._call_llm([{"role": "user", "content": "test timeout"}])


async def test_chat_stream_forwards_model_id_to_orchestrator(client, session, monkeypatch):
    from app.api import chat as chat_api

    user = await _create_user(session)
    await session.commit()

    token = create_access_token(subject=user.id)
    captured: dict = {}

    async def fake_stream_chat(user_message, history, model_id=None, **kwargs):
        captured["message"] = user_message
        captured["history"] = history
        captured["model_id"] = model_id
        captured["agent_control"] = kwargs.get("agent_control")
        yield json.dumps({"type": "text", "content": "hello "}, ensure_ascii=False)
        yield json.dumps({"type": "done"}, ensure_ascii=False)

    async def fake_finalize_chat_response(*args, **kwargs):
        return None

    monkeypatch.setattr(chat_api.orchestrator, "stream_chat", fake_stream_chat)
    monkeypatch.setattr(chat_api, "_finalize_chat_response", fake_finalize_chat_response)

    response = await client.post(
        "/api/chat/stream",
        json={
            "message": "describe this protein",
            "history": [],
            "model": "gpt55",
            "agent_control": "execute_confirmed",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200
    assert captured["message"] == "describe this protein"
    assert captured["history"] == []
    assert captured["model_id"] == "gpt55"
    assert captured["agent_control"] == "execute_confirmed"
    assert '"type": "done"' in response.text


async def test_auto_title_uses_selected_model(monkeypatch):
    from app.api import chat as chat_api

    captured: dict = {}

    async def fake_complete(messages, **kwargs):
        captured["messages"] = messages
        captured.update(kwargs)
        return {"choices": [{"message": {"content": ""}}]}

    monkeypatch.setattr(chat_api.llm_gateway, "complete", fake_complete)

    await chat_api._auto_title(
        SimpleNamespace(id=1, title="default"),
        "analyze this protein",
        model_id="gpt55",
    )

    assert captured["model_id"] == "gpt55"


async def test_chat_stream_injects_heartbeat_during_long_gap(client, session, monkeypatch):
    from app.api import chat as chat_api

    user = await _create_user(session, "heartbeat@example.com")
    await session.commit()

    token = create_access_token(subject=user.id)

    async def fake_stream_chat(user_message, history, model_id=None, **kwargs):
        yield json.dumps({"type": "text", "content": "hello "}, ensure_ascii=False)
        await asyncio.sleep(0.03)
        yield json.dumps({"type": "done"}, ensure_ascii=False)

    async def fake_finalize_chat_response(*args, **kwargs):
        return None

    monkeypatch.setattr(chat_api.orchestrator, "stream_chat", fake_stream_chat)
    monkeypatch.setattr(chat_api, "_finalize_chat_response", fake_finalize_chat_response)
    monkeypatch.setattr(chat_api, "STREAM_HEARTBEAT_SECONDS", 0.01)

    response = await client.post(
        "/api/chat/stream",
        json={
            "message": "describe this protein",
            "history": [],
            "model": "gpt55",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200
    assert ": heartbeat" in response.text
    assert '"type": "done"' in response.text
