"""White-box tests for residue mapping and structure search tools."""

from __future__ import annotations

from pathlib import Path


MINI_PDB = """\
ATOM      1  N   MET A   5      11.104  13.207  12.411  1.00 20.00           N
ATOM      2  CA  MET A   5      12.560  13.241  12.519  1.00 20.00           C
ATOM      3  C   ALA A   6      13.101  14.650  12.778  1.00 20.00           C
ATOM      4  O   ALA A   6      12.452  15.653  12.515  1.00 20.00           O
ATOM      5  N   GLY B  10      15.104  10.207  11.411  1.00 20.00           N
ATOM      6  CA  GLY B  10      16.560  10.241  11.519  1.00 20.00           C
END
"""


class TestResidueMappingSifts:
    async def test_maps_chain_with_uniprot_offset(self):
        from app.tools.residue_mapping_sifts import residue_mapping_sifts

        result = await residue_mapping_sifts(
            pdb_data=MINI_PDB,
            chain_id="A",
            uniprot_id="PTEST1",
            uniprot_start=101,
        )

        assert result["found"] is True
        assert result["mapping_count"] == 2
        assert result["mappings"][0]["pdb_residue_no"] == 5
        assert result["mappings"][0]["uniprot_position"] == 101
        assert result["mappings"][1]["residue_aa"] == "A"

    async def test_missing_pdb_returns_error_contract(self):
        from app.tools.residue_mapping_sifts import residue_mapping_sifts

        result = await residue_mapping_sifts()

        assert result["found"] is False
        assert result["error_code"] == "MISSING_PDB"

    async def test_prefers_local_sifts_mapping_file(self, monkeypatch, tmp_path):
        from app.core.config import settings
        from app.tools.residue_mapping_sifts import residue_mapping_sifts

        mapping_dir = tmp_path / "sifts"
        mapping_dir.mkdir()
        (mapping_dir / "1abc.json").write_text(
            """
            {
              "mappings": [
                {
                  "pdb_id": "1abc",
                  "chain_id": "A",
                  "pdb_residue_no": 5,
                  "residue_name": "MET",
                  "uniprot_id": "PTEST1",
                  "uniprot_position": 205
                }
              ]
            }
            """,
            encoding="utf-8",
        )
        monkeypatch.setattr(settings, "SIFTS_MAPPING_PATH", str(mapping_dir), raising=False)

        result = await residue_mapping_sifts(
            pdb_data=MINI_PDB,
            pdb_id="1abc",
            chain_id="A",
            uniprot_id="PTEST1",
            uniprot_start=101,
        )

        assert result["found"] is True
        assert result["source"] == "local_sifts_mapping"
        assert result["mapping_count"] == 1
        assert result["mappings"][0]["uniprot_position"] == 205
        assert result["limitations"] == []


class TestStructureSearchFoldseek:
    async def test_foldseek_without_endpoint_returns_degraded_summary(self, monkeypatch):
        from app.core.config import settings
        from app.tools.structure_search_foldseek import structure_search_foldseek

        monkeypatch.setattr(settings, "FOLDSEEK_API_URL", "", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_BINARY", "", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_DATABASE_PDB", "", raising=False)

        result = await structure_search_foldseek(pdb_data=MINI_PDB, max_results=5)

        assert result["found"] is False
        assert result["status"] == "degraded"
        assert result["error_code"] == "FOLDSEEK_NOT_CONFIGURED"
        assert result["backend"] == "summary_only"
        assert result["query_structure"]["chain_count"] == 2
        assert result["query_structure"]["total_residues"] == 3

    async def test_foldseek_local_cli_returns_hits(self, monkeypatch, tmp_path):
        from app.core.config import settings
        from app.tools import structure_search_foldseek as module

        db_path = tmp_path / "foldseek-db"
        db_path.mkdir()

        def fake_execute_local_foldseek_command(
            *,
            binary: str,
            query_path: Path,
            database_path: str,
            result_path: Path,
            work_dir: Path,
            max_results: int,
        ) -> None:
            assert binary == "foldseek"
            assert query_path.exists()
            assert database_path == str(db_path)
            assert max_results == 3
            work_dir.mkdir(parents=True, exist_ok=True)
            result_path.write_text(
                "query\t8abc_A\t1e-20\t120.5\t0.81\t0.79\t0.84\t0.97\n",
                encoding="utf-8",
            )

        monkeypatch.setattr(settings, "FOLDSEEK_API_URL", "", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_BINARY", "foldseek", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_DATABASE_PDB", str(db_path), raising=False)
        monkeypatch.setattr(module, "_execute_local_foldseek_command", fake_execute_local_foldseek_command)

        result = await module.structure_search_foldseek(
            pdb_data=MINI_PDB,
            database="pdb",
            max_results=3,
        )

        assert result["found"] is True
        assert result["status"] == "completed"
        assert result["backend"] == "local_cli"
        assert result["database_path"] == str(db_path)
        assert result["results_count"] == 1
        assert result["results"][0]["target"] == "8abc_A"
        assert result["results"][0]["aligned_tm_score"] == 0.81

    async def test_foldseek_root_directory_resolves_db_prefix(self, monkeypatch, tmp_path):
        from app.core.config import settings
        from app.tools import structure_search_foldseek as module

        db_root = tmp_path / "foldseek-root"
        db_dir = db_root / "pdb"
        db_dir.mkdir(parents=True)
        (db_dir / "protein_ai_pdb").write_text("stub", encoding="utf-8")
        (db_dir / "protein_ai_pdb.dbtype").write_text("stub", encoding="utf-8")
        (db_dir / "protein_ai_pdb.index").write_text("stub", encoding="utf-8")
        (db_dir / "protein_ai_pdb.lookup").write_text("stub", encoding="utf-8")
        (db_dir / "protein_ai_pdb_ca.dbtype").write_text("stub", encoding="utf-8")

        def fake_execute_local_foldseek_command(
            *,
            binary: str,
            query_path: Path,
            database_path: str,
            result_path: Path,
            work_dir: Path,
            max_results: int,
        ) -> None:
            assert database_path == str(db_dir / "protein_ai_pdb")
            work_dir.mkdir(parents=True, exist_ok=True)
            result_path.write_text(
                "query\t8abc_A\t1e-20\t120.5\t0.81\t0.79\t0.84\t0.97\n",
                encoding="utf-8",
            )

        monkeypatch.setattr(settings, "FOLDSEEK_API_URL", "", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_BINARY", "foldseek", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_DATABASE_PDB", "", raising=False)
        monkeypatch.setattr(settings, "FOLDSEEK_DATABASE_ROOT", str(db_root), raising=False)
        monkeypatch.setattr(module, "_execute_local_foldseek_command", fake_execute_local_foldseek_command)

        result = await module.structure_search_foldseek(
            pdb_data=MINI_PDB,
            database="pdb",
            max_results=3,
        )

        assert result["found"] is True
        assert result["database_path"] == str(db_dir / "protein_ai_pdb")

    async def test_structure_tools_registered(self):
        from app.tools.registry import ToolRegistry

        ToolRegistry.discover()

        mapping_tool = ToolRegistry.get_tool("residue_mapping_sifts")
        search_tool = ToolRegistry.get_tool("structure_search_foldseek")

        assert mapping_tool is not None
        assert mapping_tool.category == "structure"
        assert search_tool is not None
        assert search_tool.category == "structure"
