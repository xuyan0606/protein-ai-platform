"""Tests for Phase 1 (requirements) and Phase 2 (docker-compose/nginx) config validity.

These tests validate configuration file syntax and content without
requiring Docker or network access.
"""

import os
import re
import subprocess
import sys
import json
import importlib.util
import gzip
import hashlib
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


class TestRequirementsFiles:
    """Phase 1: requirements split validation."""

    def test_requirements_txt_references_subfiles(self):
        req = PROJECT_ROOT / "backend" / "requirements.txt"
        assert req.exists(), "requirements.txt missing"
        content = req.read_text()
        assert "-r requirements-core.txt" in content
        assert "-r requirements-ml.txt" in content

    def test_requirements_core_exists_and_valid(self):
        core = PROJECT_ROOT / "backend" / "requirements-core.txt"
        assert core.exists(), "requirements-core.txt missing"
        lines = [l.strip() for l in core.read_text().splitlines() if l.strip() and not l.startswith("#")]
        assert len(lines) >= 10, f"requirements-core.txt too short: {len(lines)} packages"

        # Must contain FastAPI
        assert any("fastapi" in l.lower() for l in lines), "FastAPI missing from core"

    def test_requirements_ml_exists_and_valid(self):
        ml = PROJECT_ROOT / "backend" / "requirements-ml.txt"
        assert ml.exists(), "requirements-ml.txt missing"
        lines = [l.strip() for l in ml.read_text().splitlines() if l.strip() and not l.startswith("#")]
        assert len(lines) >= 3, f"requirements-ml.txt too short: {len(lines)} packages"

        # Must contain torch
        assert any("torch" in l.lower() for l in lines), "torch missing from ML"

    def test_requirements_core_no_torch(self):
        """Core requirements must NOT include torch (it goes in ML)."""
        core = PROJECT_ROOT / "backend" / "requirements-core.txt"
        content = core.read_text().lower()
        assert "torch" not in content, "torch should be in requirements-ml.txt, not core"
        assert "rdkit" not in content, "rdkit should be in requirements-ml.txt, not core"

    def test_requirements_prod_references_core(self):
        prod = PROJECT_ROOT / "backend" / "requirements-prod.txt"
        if prod.exists():
            content = prod.read_text()
            assert "-r requirements-core.txt" in content

    def test_release_bundle_installer_preserves_top_level_project_dir(self):
        package_script = PROJECT_ROOT / "scripts" / "package_deploy_bundle.py"
        install_script = PROJECT_ROOT / "scripts" / "install_release_bundle.sh"
        readme = PROJECT_ROOT / "README.md"
        aliyun_doc = PROJECT_ROOT / "docs" / "aliyun-live-environment-prep-2026-07-16.md"
        dockerignore = PROJECT_ROOT / ".dockerignore"

        package_content = package_script.read_text()
        install_content = install_script.read_text()
        assert 'archive_path=f"protein-ai-platform/{rel_posix}"' in package_content
        assert '"protein-ai-platform/PACKAGE-MANIFEST.json"' in package_content
        assert 'root_name" = "protein-ai-platform"' in install_content
        assert 'project_dir="$release_dir/protein-ai-platform"' in install_content
        assert 'docker-compose.aliyun-app.yml' in install_content
        assert 'old_current/docker/ssl' in install_content
        assert "backend/alembic/" not in dockerignore.read_text()
        assert "/releases/<release>/protein-ai-platform" in readme.read_text()
        assert "/releases/<timestamp>/protein-ai-platform" in aliyun_doc.read_text()

    def test_release_bundle_excludes_virtualenv_recovery_dirs(self, tmp_path):
        package_script = PROJECT_ROOT / "scripts" / "package_deploy_bundle.py"
        spec = importlib.util.spec_from_file_location("package_deploy_bundle", package_script)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        sys.modules["package_deploy_bundle"] = module
        spec.loader.exec_module(module)

        (tmp_path / "backend" / "app").mkdir(parents=True)
        (tmp_path / "backend" / "app" / "main.py").write_text("print('ok')\n")
        (tmp_path / "backend" / ".venv.broken-20260720T1430" / "bin").mkdir(parents=True)
        (tmp_path / "backend" / ".venv.broken-20260720T1430" / "bin" / "python").write_text("")
        (tmp_path / "backend" / "venv-old" / "bin").mkdir(parents=True)
        (tmp_path / "backend" / "venv-old" / "bin" / "python").write_text("")
        (tmp_path / "frontend" / "node_modules" / "vite").mkdir(parents=True)
        (tmp_path / "frontend" / "node_modules" / "vite" / "index.js").write_text("")
        (tmp_path / "Makefile").write_text("help:\n")

        files = module.collect_files(tmp_path, include_deploy_data=False, extra_excludes=[])
        archived = {item.archive_path for item in files}

        assert "protein-ai-platform/backend/app/main.py" in archived
        assert all(".venv" not in path for path in archived)
        assert all("venv-old" not in path for path in archived)
        assert all("node_modules" not in path for path in archived)

    def test_alembic_env_escapes_percent_encoded_database_urls(self):
        env_py = PROJECT_ROOT / "backend" / "alembic" / "env.py"
        content = env_py.read_text()
        assert 'settings.DATABASE_URL.replace("%", "%%")' in content

    def test_structure_smoke_script_exists(self):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_structure_data.py"
        content = script.read_text()
        assert "SIFTS_MAPPING_PATH" in content
        assert "SIFTS_SMOKE_USE_DEMO" in content
        assert "FOLDSEEK_SMOKE_USE_DEMO" in content
        assert "FOLDSEEK_API_URL" in content
        assert "FOLDSEEK_BINARY" in content

    def test_md_topology_smoke_script_reports_runtime_status(self):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_md_topology.py"
        content = script.read_text()
        assert "_validate_pdb_topology" in content
        assert "--require-live" in content
        assert "GROMACS pdb2gmx topology precheck" in content
        assert "DEFAULT_SMOKE_PDB_CANDIDATES" in content
        assert "deploy_data" in content and "smoke" in content and "query.pdb" in content

        result = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=PROJECT_ROOT / "backend",
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        assert payload["name"] == "md_topology_smoke"
        assert payload["summary"]["status"] in {"validated", "validated_with_warnings", "blocked", "unavailable"}
        assert "topology_validated" in payload["summary"]

    def test_ligand_toolchain_smoke_script_reports_sdf_and_runtime_status(self):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_ligand_toolchain.py"
        content = script.read_text()
        assert "Structure2D_COMPOUND_CID_5478883.sdf" in content
        assert "OpenBabel" in content
        assert "AutoDock Vina" in content
        assert "ACPYPE/Antechamber" in content
        assert "--require-live" in content
        assert 'topology_ready = bool(tools["acpype"]["available"])' in content

        result = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=PROJECT_ROOT / "backend",
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        assert payload["name"] == "ligand_toolchain_smoke"
        assert payload["summary"]["input_sdf_exists"] is True
        assert payload["summary"]["is_2d_sdf"] is True
        assert payload["summary"]["atom_count"] == 111
        assert payload["summary"]["bond_count"] == 110
        assert payload["summary"]["status"] in {"ready", "blocked_toolchain_missing"}
        assert "openbabel" in payload["tools"]
        assert "vina" in payload["tools"]
        assert "gromacs" in payload["tools"]

    def test_ligand_preprocess_tool_is_registered_for_async_execution(self):
        registry = PROJECT_ROOT / "backend" / "app" / "tools" / "registry.py"
        scheduler = PROJECT_ROOT / "backend" / "app" / "services" / "scheduler.py"
        audit = PROJECT_ROOT / "backend" / "app" / "services" / "tool_task_audit.py"
        registry_content = registry.read_text()
        scheduler_content = scheduler.read_text()
        audit_content = audit.read_text()
        assert "app.tools.ligand_preprocess" in registry_content
        assert '"ligand_preprocess"' in scheduler_content
        assert 'queue="ligand_cpu"' in scheduler_content
        assert '"sdf_data"' in audit_content

    def test_redis_settings_support_authenticated_cloud_url(self):
        sys.path.insert(0, str(PROJECT_ROOT / "backend"))
        try:
            from app.core.config import Settings
        finally:
            try:
                sys.path.remove(str(PROJECT_ROOT / "backend"))
            except ValueError:
                pass

        settings = Settings(
            REDIS_HOST="r-test.redis.rds.aliyuncs.com",
            REDIS_PORT=6379,
            REDIS_DB=2,
            REDIS_USERNAME="dms_user_1",
            REDIS_PASSWORD="6(PPvF&mOzxT#Ziy",
        )

        assert settings.REDIS_URL == (
            "redis://dms_user_1:6%28PPvF%26mOzxT%23Ziy@r-test.redis.rds.aliyuncs.com:6379/2"
        )

    def test_manual_screenshot_capture_assets_are_wired(self):
        script = PROJECT_ROOT / "scripts" / "capture_manual_screenshots.mjs"
        makefile = PROJECT_ROOT / "Makefile"
        manual = PROJECT_ROOT / "docs" / "manuals" / "screenshot-operation-placeholder-manual.md"
        manifest = PROJECT_ROOT / "docs" / "manuals" / "screenshots" / "manifest.json"
        drill_record = PROJECT_ROOT / "docs" / "manuals" / "drill-records" / "2026-07-10-local-screenshot-ligand-gate.md"

        script_content = script.read_text()
        assert "chromium.launch" in script_content
        assert "docs/manuals/screenshots" in script_content
        assert "SHOT-DATA-004" in script_content
        assert "SHOT-OPS-001" in script_content
        assert "manual-screenshots" in makefile.read_text()
        manual_content = manual.read_text()
        assert "scripts/capture_manual_screenshots.mjs" in manual_content
        assert "data-experiment-feedback.png" in manual_content
        assert manifest.exists()
        manifest_payload = json.loads(manifest.read_text())
        assert manifest_payload["screenshots"]
        assert any(item["id"] == "SHOT-DATA-004" for item in manifest_payload["screenshots"])
        drill_content = drill_record.read_text()
        assert "DRILL-20260710-LOCAL-001" in drill_content
        assert "blocked_toolchain_missing" in drill_content

    def test_remaining_backlog_readiness_aggregates_external_gates(self):
        script = PROJECT_ROOT / "scripts" / "check_remaining_backlog_readiness.py"
        makefile = PROJECT_ROOT / "Makefile"
        task_plan = PROJECT_ROOT / "task_plan.md"
        content = script.read_text()
        assert "network_io" in content
        assert "destructive_actions" in content
        assert "local_capable" in content
        assert "external_dependency" in content
        assert "real_deploy_data" in content
        assert "gpu_gromacs_md_live" in content
        assert "ligand_runtime_live" in content
        assert "oss_minio_live_e2e" in content
        assert "admin_authenticated_screenshots" in content
        assert "maintenance_window_drills" in content
        assert "SCREENSHOT_EMAIL" in content
        assert "MAINTENANCE_WINDOW_ID" in content

        task_plan_content = task_plan.read_text()
        assert "MD 科学参数层第四层第二批第七步" in task_plan_content
        assert "底物/配体预处理与对接层第二步第二批" in task_plan_content
        assert "自动化测试增强第二层" in task_plan_content
        assert "封装交付层第三层第二批" in task_plan_content
        assert "产品化文档第二层第二批剩余部分" in task_plan_content
        assert "绑定正式域名和 HTTPS 证书" in task_plan_content

        make_content = makefile.read_text()
        assert "remaining-backlog-readiness" in make_content
        assert "remaining-backlog-readiness-json" in make_content

        baseline_env = os.environ.copy()
        for key in (
            "MINIO_ENDPOINT",
            "MINIO_BUCKET",
            "MINIO_ACCESS_KEY",
            "MINIO_SECRET_KEY",
            "MINIO_REGION",
            "ALIYUN_OSS_ENDPOINT",
            "ALIYUN_OSS_REGION",
            "ALIYUN_OSS_BUCKET",
            "ALIYUN_OSS_ACCESS_KEY_ID",
            "ALIYUN_OSS_ACCESS_KEY_SECRET",
        ):
            baseline_env.pop(key, None)

        result = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=PROJECT_ROOT,
            env=baseline_env,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        assert payload["summary"]["network_io"] == "not_executed"
        assert payload["summary"]["destructive_actions"] == "not_executed"
        assert payload["summary"]["bucket_counts"] == {
            "external_dependency": 7,
            "local_capable": 2,
        }
        names = {item["name"] for item in payload["results"]}
        assert "real_deploy_data" in names
        assert "gpu_gromacs_md_live" in names
        assert "ligand_runtime_live" in names
        assert "oss_minio_live_e2e" in names
        assert "admin_authenticated_screenshots" in names
        assert "maintenance_window_drills" in names
        assert "md_blackbox_live_e2e" in names
        assert "remote_pytest_runner" in names

        by_name = {item["name"]: item for item in payload["results"]}
        assert by_name["real_deploy_data"]["bucket"] == "local_capable"
        assert by_name["gpu_gromacs_md_live"]["bucket"] == "external_dependency"
        assert by_name["ligand_runtime_live"]["bucket"] == "external_dependency"
        assert by_name["oss_minio_live_e2e"]["bucket"] == "external_dependency"
        assert by_name["admin_authenticated_screenshots"]["bucket"] == "external_dependency"
        assert by_name["maintenance_window_drills"]["bucket"] == "external_dependency"
        assert by_name["md_blackbox_live_e2e"]["bucket"] == "external_dependency"
        assert by_name["remote_pytest_runner"]["bucket"] == "local_capable"

        ready_env = os.environ.copy()
        ready_env.update(
            {
                "ALIYUN_OSS_ENDPOINT": "oss-cn-hangzhou-internal.aliyuncs.com",
                "ALIYUN_OSS_REGION": "cn-hangzhou",
                "ALIYUN_OSS_BUCKET": "protein-ai-files",
                "ALIYUN_OSS_ACCESS_KEY_ID": "test-access-key",
                "ALIYUN_OSS_ACCESS_KEY_SECRET": "test-secret-key",
            }
        )
        for key in ("MINIO_ENDPOINT", "MINIO_BUCKET", "MINIO_ACCESS_KEY", "MINIO_SECRET_KEY", "MINIO_REGION"):
            ready_env.pop(key, None)
        ready_result = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=PROJECT_ROOT,
            env=ready_env,
            capture_output=True,
            text=True,
            check=True,
        )
        ready_payload = json.loads(ready_result.stdout)
        ready_by_name = {item["name"]: item for item in ready_payload["results"]}
        assert ready_payload["summary"]["network_io"] == "not_executed"
        assert ready_by_name["oss_minio_live_e2e"]["status"] == "ready"
        assert ready_by_name["oss_minio_live_e2e"]["bucket"] == "local_capable"
        assert "--include-oss-e2e" in ready_by_name["oss_minio_live_e2e"]["next_actions"][0]

        text_result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT,
            env=baseline_env,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "本机可做" in text_result.stdout
        assert "外部依赖" in text_result.stdout
        assert "real_deploy_data" in text_result.stdout
        assert "gpu_gromacs_md_live" in text_result.stdout

    def test_lipase_db_readonly_service_and_api_are_wired(self):
        config = PROJECT_ROOT / "backend" / "app" / "core" / "config.py"
        service = PROJECT_ROOT / "backend" / "app" / "services" / "lipase_db_status.py"
        curation_service = PROJECT_ROOT / "backend" / "app" / "services" / "lipase_curation.py"
        curation_model = PROJECT_ROOT / "backend" / "app" / "models" / "lipase_curation.py"
        data_api = PROJECT_ROOT / "backend" / "app" / "api" / "data.py"
        frontend_api = PROJECT_ROOT / "frontend" / "src" / "lib" / "api.ts"
        data_page = PROJECT_ROOT / "frontend" / "src" / "pages" / "DataBrowser.tsx"
        pdb_page = PROJECT_ROOT / "frontend" / "src" / "pages" / "PDBUploadPage.tsx"
        pdb_card = PROJECT_ROOT / "frontend" / "src" / "components" / "analysis" / "PDBAnalysisCard.tsx"

        assert "LIPASE_DB_PATH" in config.read_text()
        service_content = service.read_text()
        curation_service_content = curation_service.read_text()
        curation_model_content = curation_model.read_text()
        assert "mode=ro" in service_content
        assert "immutable=1" in service_content
        assert "collect_lipase_db_status" in service_content
        assert "list_lipase_papers" in service_content
        assert "search_lipase_evidence" in service_content
        assert "build_lipase_evidence_context" in service_content
        assert "LipaseCurationRecord" in curation_model_content
        assert "LipaseCurationBatch" in curation_model_content
        assert "create_lipase_curation_record" in curation_service_content
        assert "create_lipase_curation_batch" in curation_service_content
        assert "publish_lipase_curation_batch" in curation_service_content
        assert "update_lipase_curation_review" in curation_service_content
        data_api_content = data_api.read_text()
        assert '"/lipase/status"' in data_api_content
        assert '"/lipase/search"' in data_api_content
        assert '"/lipase/evidence-context"' in data_api_content
        assert '"/lipase/papers"' in data_api_content
        assert '"/lipase/papers/{paper_key}"' in data_api_content
        assert '"/lipase/variants"' in data_api_content
        assert '"/lipase/gaps"' in data_api_content
        assert '"/lipase/curation-records"' in data_api_content
        assert '"/lipase/curation-records/{record_id}/review"' in data_api_content
        assert '"/lipase/curation-batches"' in data_api_content
        assert '"/lipase/curation-batches/{batch_id}/publish"' in data_api_content
        assert '"/experiment-feedback"' in data_api_content
        assert '"/experiment-feedback/summary"' in data_api_content
        frontend_api_content = frontend_api.read_text()
        data_page_content = data_page.read_text()
        pdb_page_content = pdb_page.read_text()
        pdb_card_content = pdb_card.read_text()
        assert "getLipaseDbStatus" in frontend_api_content
        assert "getLipasePaperDetail" in frontend_api_content
        assert "getLipaseEvidenceContext" in frontend_api_content
        assert "submitLipaseCurationRecord" in frontend_api_content
        assert "listLipaseCurationRecords" in frontend_api_content
        assert "reviewLipaseCurationRecord" in frontend_api_content
        assert "createLipaseCurationBatch" in frontend_api_content
        assert "publishLipaseCurationBatch" in frontend_api_content
        assert "searchLipaseEvidence" in frontend_api_content
        assert "submitExperimentFeedback" in frontend_api_content
        assert "listExperimentFeedback" in frontend_api_content
        assert "summarizeExperimentFeedback" in frontend_api_content
        assert "runMutationEpistasisCheck" in frontend_api_content
        assert "LipaseDbCard" in data_page_content
        assert "LipaseEvidenceBrowser" in data_page_content
        assert "LipasePaperDetailPanel" in data_page_content
        assert "ExperimentFeedbackPanel" in data_page_content
        assert "湿实验反馈录入" in data_page_content
        assert "运行组合上位性检查" in data_page_content
        assert "EpistasisResultCard" in data_page_content
        assert "结构距离" in data_page_content
        assert "机制标签" in data_page_content
        assert "同一区域" in data_page_content
        assert "parseStructuralDistances" in data_page_content
        assert "parseMechanismTags" in data_page_content
        assert "parseSameRegionGroups" in data_page_content
        assert "runLipaseEvidenceOverlay" in pdb_page_content
        assert "lipaseNumberingConfirmed" in pdb_page_content
        assert "Lipase evidence" in pdb_card_content

    def test_matvenus_feedback_tools_are_registered_and_wired(self):
        registry = PROJECT_ROOT / "backend" / "app" / "tools" / "registry.py"
        agent_roles = PROJECT_ROOT / "backend" / "app" / "core" / "agent_roles.py"
        feedback_service = PROJECT_ROOT / "backend" / "app" / "services" / "experiment_feedback.py"
        feedback_model = PROJECT_ROOT / "backend" / "app" / "models" / "experiment_feedback.py"
        migration = PROJECT_ROOT / "backend" / "alembic" / "versions" / "9c8d7e6f5a41_add_experiment_feedback_records.py"

        assert "app.tools.mutation_epistasis_check" in registry.read_text()
        assert "app.tools.residue_numbering_gate" in registry.read_text()
        agent_content = agent_roles.read_text()
        assert "mutation_epistasis_check" in agent_content
        assert "residue_numbering_gate" in agent_content
        service_content = feedback_service.read_text()
        model_content = feedback_model.read_text()
        assert "analyze_feedback_payload" in service_content
        assert "summarize_feedback_records" in service_content
        assert "ExperimentFeedbackRecord" in model_content
        assert "experiment_feedback_records" in migration.read_text()

    def test_dockerignore_keeps_backend_smoke_scripts(self):
        dockerignore = PROJECT_ROOT / ".dockerignore"
        content = dockerignore.read_text()
        assert "backend/scripts/" in content
        assert "!backend/scripts/" in content
        assert "!backend/scripts/*.py" in content

    def test_prepare_deploy_data_script_exists(self):
        script = PROJECT_ROOT / "scripts" / "prepare_deploy_data.py"
        content = script.read_text()
        assert "deploy_data" in content
        assert "--with-demo" in content
        assert "--overwrite-demo" in content
        assert "--write-manifest" in content
        assert "expected_datasets" in content

    def test_check_deploy_data_script_exists(self):
        script = PROJECT_ROOT / "scripts" / "check_deploy_data.py"
        content = script.read_text()
        assert "--require-live" in content
        assert "--plan-only" in content
        assert "live-data-ready" in content
        assert "demo-data-only" in content
        assert "materialize_foldseek_links.py" in content
        assert "FOLDSEEK_API_URL" in content
        assert "structure_smoke_readiness.py" in content
        assert "version_comparison" in content
        assert "missing_items" in content
        assert "planned_commands" in content

        result = subprocess.run(
            [sys.executable, str(script), "--plan-only", "--json"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        by_label = {item["label"]: item for item in payload}
        assert "pdb" in by_label
        assert "alphafold" in by_label
        assert "foldseek" in by_label
        assert "version_comparison" in by_label
        assert "dry_run" in by_label
        assert by_label["dry_run"]["status"] == "planned"
        assert by_label["dry_run"]["planned_commands"]
        assert "missing_items" in by_label["summary"]
        assert "next_actions" in by_label["summary"]

    def test_import_deploy_data_script_exists(self):
        script = PROJECT_ROOT / "scripts" / "import_deploy_data.py"
        content = script.read_text()
        assert "import-manifest.json" in content
        assert "--annotations" in content
        assert "--foldseek-root" in content
        assert "--symlink" in content

    def test_discover_deploy_data_sources_script_exists(self):
        script = PROJECT_ROOT / "scripts" / "discover_deploy_data_sources.py"
        content = script.read_text()
        assert "deploy_data" in content
        assert "--root" in content
        assert "alphafold" in content.lower()
        assert "sifts" in content.lower()

    def test_write_deploy_env_script_exists(self):
        script = PROJECT_ROOT / "scripts" / "write_deploy_env.py"
        content = script.read_text()
        assert ".env.deploy-data" in content
        assert "DEPLOY_DATA_HOST_PATH" in content
        assert "FOLDSEEK_API_URL" in content

    def test_makefile_contains_deploy_shortcuts(self):
        makefile = PROJECT_ROOT / "Makefile"
        content = makefile.read_text()
        assert "acceptance-matrix" in content
        assert "deploy-preflight" in content
        assert "deploy-demo-check" in content
        assert "check-deploy-data" in content
        assert "discover-deploy-data" in content
        assert "materialize-foldseek-db" in content
        assert "backend-readiness" in content
        assert "backend-live-gate" in content
        assert "deploy-live-gate" in content
        assert "docker-backend-smoke-live" in content
        assert "docker-backend-live-gate" in content
        assert "docker-backend-rebuild-and-smoke" in content
        assert "docker-up-with-deploy-env" in content
        assert "docker-config-aliyun-app" in content
        assert "docker-up-aliyun-app" in content
        assert "docker-config-aliyun-gpu" in content
        assert "docker-up-aliyun-gpu" in content
        assert "BACKEND_DEPLOY_ENV" in content
        assert "deploy-data-update-plan" in content
        assert "deploy-data-update-json" in content
        assert "backend-md-topology-smoke" in content
        assert "backend-md-topology-live-gate" in content
        assert "backend-ligand-toolchain-smoke" in content
        assert "backend-ligand-toolchain-live-gate" in content
        assert "docker-config-ligand-worker" in content
        assert "docker-build-ligand-worker" in content
        assert "config --quiet" in content

    def test_acceptance_matrix_script_plan_includes_risk_gates(self):
        script = PROJECT_ROOT / "scripts" / "run_acceptance_matrix.py"
        content = script.read_text()
        assert "--include-md-blackbox" in content
        assert "--include-browser-smoke" in content
        assert "--include-ai-blackbox" in content
        assert "--include-file-download-e2e" in content
        assert "--include-benchmark-bundle-live" in content
        assert "oss_compatibility" in content
        assert "--include-oss-e2e" in content
        assert "oss_minio_e2e_contract" in content
        assert "ai_chat_blackbox_live" in content
        assert "live_file_download_e2e" in content
        assert "benchmark_bundle_head_live" in content
        assert "blocked" in content
        assert "skipped" in content
        assert "file_download_permissions" in content
        assert "ligand_preprocess_contract" in content
        assert "ligand_toolchain_smoke" in content
        assert "browser_smoke_contract" in content

        result = subprocess.run(
            [sys.executable, str(script), "--plan-only", "--json"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        names = {item["name"] for item in payload["results"]}
        assert "file_download_permissions" in names
        assert "md_artifact_whitebox" in names
        assert "ligand_preprocess_contract" in names
        assert "ligand_toolchain_smoke" in names
        assert "data_admin_readiness" in names
        assert "oss_compatibility" in names
        assert "browser_smoke_contract" in names
        assert "browser_live_smoke" in names
        assert "ai_chat_blackbox_live" in names
        assert "live_file_download_e2e" in names
        assert "benchmark_bundle_head_live" in names
        assert "md_blackbox" in names
        assert "deploy_live_gate" in names
        assert "oss_minio_e2e_contract" in names
        statuses = {item["name"]: item["status"] for item in payload["results"]}
        assert statuses["browser_live_smoke"] == "skipped"
        assert statuses["ai_chat_blackbox_live"] == "skipped"
        assert statuses["live_file_download_e2e"] == "skipped"
        assert statuses["benchmark_bundle_head_live"] == "skipped"
        assert statuses["md_blackbox"] == "skipped"
        assert statuses["deploy_live_gate"] == "skipped"
        assert statuses["oss_minio_e2e_contract"] == "skipped"
        assert payload["summary"]["status"] == "planned"
        assert payload["summary"]["skipped"] >= 6

        opt_in = subprocess.run(
            [
                sys.executable,
                str(script),
                "--plan-only",
                "--include-browser-smoke",
                "--include-ai-blackbox",
                "--include-file-download-e2e",
                "--include-benchmark-bundle-live",
                "--include-md-blackbox",
                "--include-live",
                "--include-oss-e2e",
                "--json",
            ],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        opt_in_payload = json.loads(opt_in.stdout)
        opt_in_statuses = {item["name"]: item["status"] for item in opt_in_payload["results"]}
        assert opt_in_statuses["browser_public_smoke"] == "planned"
        assert opt_in_statuses["browser_live_smoke"] == "planned"
        assert opt_in_statuses["ai_chat_blackbox_live"] == "planned"
        assert opt_in_statuses["live_file_download_e2e"] == "planned"
        assert opt_in_statuses["benchmark_bundle_head_live"] == "planned"
        assert opt_in_statuses["md_blackbox"] == "planned"
        assert opt_in_statuses["deploy_live_gate"] == "planned"
        assert opt_in_statuses["backend_smoke_live"] == "planned"
        assert opt_in_statuses["oss_minio_e2e_contract"] == "planned"

    def test_frontend_live_contract_is_non_browser_and_uses_codex_port_range(self):
        script = PROJECT_ROOT / "frontend" / "tests" / "live-contract.mjs"
        content = script.read_text()
        assert "FRONTEND_BASE_URL" in content
        assert "4200" in content
        assert "4299" in content
        assert "public-smoke.mjs" in content
        assert "live-smoke.mjs" in content
        assert "http-smoke.mjs" in content

        result = subprocess.run(
            ["node", str(script), "--json"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        assert payload["base_url"] == "http://127.0.0.1:4200"
        assert payload["summary"]["status"] == "passed"
        names = {item["name"] for item in payload["results"]}
        assert "frontend_base_url" in names
        assert "browser_public_smoke_contract" in names
        assert "browser_live_smoke_contract" in names
        assert "http_smoke_contract" in names

    def test_oss_minio_contract_script_is_plan_only_without_network_io(self):
        script = PROJECT_ROOT / "scripts" / "smoke_oss_minio_contract.py"
        content = script.read_text()
        assert "does not create buckets" in content
        assert "--require-live" in content
        assert "drills/oss-minio-e2e" in content
        assert "network_io" in content

        env = os.environ.copy()
        env.pop("MINIO_ACCESS_KEY", None)
        env.pop("MINIO_SECRET_KEY", None)
        env.pop("ALIYUN_OSS_ACCESS_KEY_ID", None)
        env.pop("ALIYUN_OSS_ACCESS_KEY_SECRET", None)
        result = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=PROJECT_ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        assert payload["summary"]["network_io"] == "not_executed"
        assert payload["summary"]["status"] in {"planned", "blocked"}
        names = {item["name"] for item in payload["results"]}
        assert "oss_minio_endpoint" in names
        assert "oss_minio_bucket" in names
        assert "oss_minio_credentials" in names

    def test_oss_minio_contract_accepts_aliyun_oss_env_aliases(self):
        script = PROJECT_ROOT / "scripts" / "smoke_oss_minio_contract.py"
        env = os.environ.copy()
        for key in ("MINIO_ENDPOINT", "MINIO_BUCKET", "MINIO_ACCESS_KEY", "MINIO_SECRET_KEY", "MINIO_REGION"):
            env.pop(key, None)
        env.update(
            {
                "ALIYUN_OSS_ENDPOINT": "oss-cn-hangzhou-internal.aliyuncs.com",
                "ALIYUN_OSS_REGION": "cn-hangzhou",
                "ALIYUN_OSS_BUCKET": "protein-ai-files",
                "ALIYUN_OSS_ACCESS_KEY_ID": "test-access-key",
                "ALIYUN_OSS_ACCESS_KEY_SECRET": "test-secret-key",
            }
        )

        result = subprocess.run(
            [sys.executable, str(script), "--json"],
            cwd=PROJECT_ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )

        payload = json.loads(result.stdout)
        assert payload["summary"]["network_io"] == "not_executed"
        assert payload["summary"]["status"] == "passed"

    def test_release_acceptance_script_plan_includes_delivery_gates(self):
        script = PROJECT_ROOT / "scripts" / "run_release_acceptance.py"
        content = script.read_text()
        assert "check_upgrade_readiness.py" in content
        assert "run_acceptance_matrix.py" in content
        assert "package_deploy_bundle.py" in content
        assert "rollback_plan.py" in content
        assert "restore_drill.sh" in content
        assert "--include-backup-verify" in content
        assert "real_rollback" in content
        assert "deploy_package" in content

        makefile = PROJECT_ROOT / "Makefile"
        make_content = makefile.read_text()
        assert "release-acceptance" in make_content
        assert "release-acceptance-json" in make_content
        assert "release-acceptance-plan" in make_content

        result = subprocess.run(
            [sys.executable, str(script), "--plan-only", "--json"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        names = {item["name"] for item in payload["results"]}
        assert "upgrade_readiness" in names
        assert "acceptance_matrix" in names
        assert "package_deploy_bundle_dry_run" in names
        assert "rollback_plan" in names
        assert "restore_drill_dry_run" in names
        assert payload["safety"]["real_restore"] is False
        assert payload["safety"]["real_rollback"] is False

        restore_drill = PROJECT_ROOT / "scripts" / "restore_drill.sh"
        restore_content = restore_drill.read_text()
        assert "Refusing unsafe drill database name after env load" in restore_content
        assert 'DRILL_DB" == "$MAIN_DB' in restore_content

    def test_verify_backup_accepts_legacy_absolute_checksum_paths(self, tmp_path):
        backup_file = tmp_path / "protein_ai_legacy.sql.gz"
        with gzip.open(backup_file, "wb") as fh:
            fh.write(b"-- legacy plain SQL backup smoke\n")
        digest = hashlib.sha256(backup_file.read_bytes()).hexdigest()
        checksum_file = backup_file.with_suffix(backup_file.suffix + ".sha256")
        checksum_file.write_text(f"{digest}  /Users/old/path/{backup_file.name}\n")

        result = subprocess.run(
            [str(PROJECT_ROOT / "scripts" / "verify_backup.sh"), str(backup_file)],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )

        assert "checksum\tok" in result.stdout
        assert "legacy-path" in result.stdout
        assert "summary\tok\tbackup verification passed" in result.stdout

    def test_deploy_data_update_script_plan_is_safe(self):
        script = PROJECT_ROOT / "scripts" / "run_deploy_data_update.py"
        content = script.read_text()
        assert "refresh_live_deploy_data.py" in content
        assert "--plan-only" in content
        assert "deploy_data/updates" in content
        assert "schedule_hint" in content

        result = subprocess.run(
            [sys.executable, str(script), "--plan-only", "--json"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(result.stdout)
        assert payload["summary"]["status"] == "planned"
        assert payload["summary"]["executed"] is False
        names = {item["name"] for item in payload["results"]}
        assert "refresh_live_deploy_data" in names
        assert "check_deploy_data" in names
        assert "schedule_hint" in names

    def test_productization_manuals_exist(self):
        manuals = PROJECT_ROOT / "docs" / "manuals"
        acceptance = manuals / "productization-acceptance-manual.md"
        drill = manuals / "drill-record-template.md"
        admin = manuals / "admin-manual.md"
        data_import = manuals / "data-import-manual.md"
        ligand_workflow = manuals / "ligand-docking-md-workflow.md"
        acceptance_content = acceptance.read_text(encoding="utf-8")
        drill_content = drill.read_text(encoding="utf-8")
        admin_content = admin.read_text(encoding="utf-8")
        data_import_content = data_import.read_text(encoding="utf-8")
        ligand_workflow_content = ligand_workflow.read_text(encoding="utf-8")
        assert "make release-acceptance" in acceptance_content
        assert "project.chat.bind" in acceptance_content
        assert "OPS_ALERT_WEBHOOK_ENABLED" in acceptance_content
        assert "deploy_data/pdb/1QHP.cif" in acceptance_content
        assert "make verify-backup BACKUP_FILE=..." in drill_content
        assert "productization-acceptance-manual.md" in admin_content
        assert "make deploy-data-update-plan" in data_import_content
        assert "deploy_data/updates/deploy_data_update_" in data_import_content
        assert "2D SDF" in ligand_workflow_content
        assert "make backend-ligand-toolchain-live-gate" in ligand_workflow_content
        assert "ACPYPE/Antechamber" in ligand_workflow_content

    def test_deploy_aliyun_script_is_role_based(self):
        script = PROJECT_ROOT / "deploy-aliyun.sh"
        content = script.read_text()
        assert "docker-compose.aliyun-app.yml" in content
        assert "docker-compose.aliyun-gpu.yml" in content
        assert "./deploy-aliyun.sh app" in content
        assert "./deploy-aliyun.sh gpu" in content
        assert ".env.aliyun.app" in content
        assert ".env.aliyun.gpu" in content

    def test_materialize_foldseek_links_script_exists(self):
        script = PROJECT_ROOT / "scripts" / "materialize_foldseek_links.py"
        content = script.read_text()
        assert "Foldseek" in content
        assert "--dry-run" in content
        assert "symlink" in content

    def test_structure_smoke_readiness_script_exists(self):
        script = PROJECT_ROOT / "backend" / "scripts" / "structure_smoke_readiness.py"
        content = script.read_text()
        assert "--require-live" in content
        assert "live-ready" in content
        assert "demo-ready" in content
        assert "live_annotations" in content
        assert "deploy_data_root" in content
        assert "smoke_structure_data.py" in content

    def test_structure_smoke_demo_fixture_exists(self):
        fixture = PROJECT_ROOT / "backend" / "app" / "data" / "fixtures" / "structure_smoke" / "1abc.json"
        assert fixture.exists(), "Bundled structure smoke demo mapping fixture missing"

    def test_env_example_contains_structure_smoke_vars(self):
        env_example = PROJECT_ROOT / "backend" / ".env.example"
        content = env_example.read_text()
        assert "DEPLOY_DATA_ROOT" in content
        assert "LOCAL_ANNOTATION_FIXTURE_PATH" in content
        assert "SIFTS_SMOKE_USE_DEMO" in content
        assert "FOLDSEEK_SMOKE_USE_DEMO" in content
        assert "STRUCTURE_SMOKE_PDB_FILE" in content

    def test_env_example_contains_object_storage_secure_vars(self):
        env_example = PROJECT_ROOT / "backend" / ".env.example"
        content = env_example.read_text()
        assert "MINIO_SECURE" in content
        assert "MINIO_REGION" in content
        assert "REDIS_HOST" in content
        assert "REDIS_PORT" in content
        assert "REDIS_DB" in content
        assert "OPS_SLOW_REQUEST_THRESHOLD_SECONDS" in content
        assert "OPS_ALERT_WEBHOOK_ENABLED" in content
        assert "OPS_ALERT_WEBHOOK_URL" in content
        assert "OPS_ALERT_WEBHOOK_TIMEOUT_SECONDS" in content
        assert "OPS_ALERT_WEBHOOK_RETRY_ATTEMPTS" in content
        assert "OPS_ALERT_SILENCE_SECONDS" in content
        assert "OPS_ALERT_ESCALATE_AFTER_COUNT" in content

    def test_aliyun_managed_env_examples_exist(self):
        app_env = PROJECT_ROOT / "docker" / ".env.aliyun.app.example"
        gpu_env = PROJECT_ROOT / "docker" / ".env.aliyun.gpu.example"
        app_content = app_env.read_text()
        gpu_content = gpu_env.read_text()
        assert "ALIYUN_APP_DATABASE_URL" in app_content
        assert "ALIYUN_OSS_ENDPOINT" in app_content
        assert "ALIYUN_OUTLINE_DATABASE_URL" in app_content
        assert "OUTLINE_FORCE_HTTPS" in app_content
        assert "change-me-64-char-hex-outline-secret-key" in app_content
        assert "ALIYUN_APP_DATABASE_URL" in gpu_content
        assert "GPU_DEVICE_REQUEST" in gpu_content
        assert "CELERY_LIGAND_WORKER_CONCURRENCY" in gpu_content
        assert "GROMACS_BIN" in gpu_content

    def test_init_deployment_generates_outline_hex_secrets(self):
        script = PROJECT_ROOT / "scripts" / "init_deployment.py"
        content = script.read_text()
        assert "def _random_hex" in content
        assert '"OUTLINE_SECRET_KEY": _random_hex(32)' in content
        assert '"OUTLINE_UTILS_SECRET": _random_hex(32)' in content

    def test_structure_smoke_demo_modes_execute(self):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_structure_data.py"
        env = os.environ.copy()
        env["SIFTS_SMOKE_USE_DEMO"] = "1"
        env["FOLDSEEK_SMOKE_USE_DEMO"] = "1"
        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        combined = f"{result.stdout}\n{result.stderr}"
        assert "PASS sifts:" in combined
        assert "PASS foldseek-demo:" in combined

    def test_structure_smoke_readiness_reports_demo_ready(self):
        script = PROJECT_ROOT / "backend" / "scripts" / "structure_smoke_readiness.py"
        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert "demo_sifts\tready\t" in result.stdout
        assert "deploy_data_root\tready\t" in result.stdout
        assert "live_foldseek_http\tmissing\t" in result.stdout
        assert "live_foldseek_cli\tmissing\t" in result.stdout
        assert "summary\tdemo-ready\t" in result.stdout

    def test_structure_smoke_autodiscovers_deploy_data_root(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_structure_data.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        fixture = PROJECT_ROOT / "backend" / "app" / "data" / "fixtures" / "structure_smoke" / "1abc.json"
        (deploy_root / "sifts" / "1abc.json").write_text(fixture.read_text(), encoding="utf-8")
        (deploy_root / "smoke" / "query.pdb").write_text(
            "HEADER    AUTODISCOVERY TEST\nATOM      1  N   MET A   1      11.104  13.207  12.411  1.00 20.00           N\nEND\n",
            encoding="utf-8",
        )

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["SIFTS_SMOKE_PDB_ID"] = "1abc"
        env["FOLDSEEK_SMOKE_USE_DEMO"] = "1"
        env.pop("SIFTS_MAPPING_PATH", None)
        env.pop("STRUCTURE_SMOKE_PDB_FILE", None)

        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        combined = f"{result.stdout}\n{result.stderr}"
        assert "PASS sifts:" in combined
        assert "PASS foldseek-demo:" in combined

    def test_structure_smoke_infers_sifts_pdb_id_from_local_mapping_filename(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_structure_data.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        fixture = PROJECT_ROOT / "backend" / "app" / "data" / "fixtures" / "structure_smoke" / "1abc.json"
        (deploy_root / "sifts" / "1abc.json").write_text(fixture.read_text(), encoding="utf-8")
        (deploy_root / "smoke" / "query.pdb").write_text(
            "HEADER    AUTODISCOVERY TEST\nATOM      1  N   MET A   1      11.104  13.207  12.411  1.00 20.00           N\nEND\n",
            encoding="utf-8",
        )

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["FOLDSEEK_SMOKE_USE_DEMO"] = "1"
        env.pop("SIFTS_MAPPING_PATH", None)
        env.pop("SIFTS_SMOKE_PDB_ID", None)

        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        combined = f"{result.stdout}\n{result.stderr}"
        assert "PASS sifts:" in combined
        assert "PASS foldseek-demo:" in combined

    def test_structure_smoke_prefers_real_sifts_mapping_over_demo_fixture(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "smoke_structure_data.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        fixture = PROJECT_ROOT / "backend" / "app" / "data" / "fixtures" / "structure_smoke" / "1abc.json"
        (deploy_root / "sifts" / "1abc.json").write_text(fixture.read_text(), encoding="utf-8")
        (deploy_root / "sifts" / "realcase.json").write_text(
            json.dumps(
                {
                    "mappings": [
                        {
                            "pdb_id": "realcase",
                            "chain_id": "A",
                            "pdb_residue_no": 1,
                            "uniprot_id": "P00000",
                            "uniprot_position": 1,
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        (deploy_root / "smoke" / "query.pdb").write_text(
            "HEADER    AUTODISCOVERY REAL TEST\nATOM      1  N   MET A   1      11.104  13.207  12.411  1.00 20.00           N\nEND\n",
            encoding="utf-8",
        )

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["FOLDSEEK_SMOKE_USE_DEMO"] = "1"
        env.pop("SIFTS_MAPPING_PATH", None)
        env.pop("SIFTS_SMOKE_PDB_ID", None)

        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        combined = f"{result.stdout}\n{result.stderr}"
        assert "PASS sifts:" in combined
        assert "realcase.json" in combined

    def test_structure_smoke_readiness_autodiscovers_deploy_data_root(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "structure_smoke_readiness.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "foldseek" / "pdb").mkdir(parents=True)
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        (deploy_root / "sifts" / "real_mapping.json").write_text("[]", encoding="utf-8")
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"real_annotations"}',
            encoding="utf-8",
        )
        (deploy_root / "foldseek" / "pdb" / "db.index").write_text("demo", encoding="utf-8")
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER    READINESS TEST\nEND\n", encoding="utf-8")

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["FOLDSEEK_BINARY"] = "/bin/echo"

        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "deploy_data_root\tready\t" in result.stdout
        assert "live_sifts\tready\t" in result.stdout
        assert "live_annotations\tready\t" in result.stdout
        assert "live_query_pdb\tready\t" in result.stdout
        assert "live_foldseek_cli\tready\t" in result.stdout
        assert "summary\tlive-ready\t" in result.stdout

    def test_structure_smoke_readiness_marks_demo_assets_as_demo_ready(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "structure_smoke_readiness.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "foldseek" / "pdb").mkdir(parents=True)
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        (deploy_root / "sifts" / "1abc.json").write_text("[]", encoding="utf-8")
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"local_demo"}',
            encoding="utf-8",
        )
        (deploy_root / "foldseek" / "pdb" / "db.index").write_text("demo", encoding="utf-8")
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER    READINESS TEST\nEND\n", encoding="utf-8")

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["FOLDSEEK_BINARY"] = "/bin/echo"

        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "live_sifts\tdemo\t" in result.stdout
        assert "live_annotations\tdemo\t" in result.stdout
        assert "live_foldseek_cli\tready\t" in result.stdout
        assert "summary\tdemo-ready\t" in result.stdout

    def test_structure_smoke_readiness_require_live_fails_for_demo_assets(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "structure_smoke_readiness.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "foldseek" / "pdb").mkdir(parents=True)
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        (deploy_root / "sifts" / "1ABC.json").write_text("[]", encoding="utf-8")
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"local_demo"}',
            encoding="utf-8",
        )
        (deploy_root / "foldseek" / "pdb" / "db.index").write_text("demo", encoding="utf-8")
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["FOLDSEEK_BINARY"] = "/bin/echo"

        result = subprocess.run(
            [sys.executable, str(script), "--require-live"],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
        assert "summary\tdemo-ready\t" in result.stdout

    def test_structure_smoke_readiness_requires_nonempty_foldseek_db(self, tmp_path):
        script = PROJECT_ROOT / "backend" / "scripts" / "structure_smoke_readiness.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "smoke").mkdir(parents=True)
        (deploy_root / "foldseek" / "pdb").mkdir(parents=True)
        (deploy_root / "sifts" / "real_mapping.json").write_text("[]", encoding="utf-8")
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        env = os.environ.copy()
        env["DEPLOY_DATA_ROOT"] = str(deploy_root)
        env["FOLDSEEK_BINARY"] = "/bin/echo"

        result = subprocess.run(
            [sys.executable, str(script)],
            cwd=PROJECT_ROOT / "backend",
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "live_foldseek_cli\tmissing\t" in result.stdout
        assert "summary\tdemo-ready\t" in result.stdout

    def test_prepare_deploy_data_with_demo(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "prepare_deploy_data.py"
        output_root = tmp_path / "deploy_data"
        result = subprocess.run(
            [sys.executable, str(script), "--output", str(output_root), "--with-demo"],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert (output_root / "annotations" / "base.json").exists()
        assert (output_root / "sifts" / "1abc.json").exists()
        assert (output_root / "smoke" / "query.pdb").exists()
        assert "Demo assets copied" in result.stdout

    def test_import_deploy_data_stages_sources(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "import_deploy_data.py"
        sources = tmp_path / "sources"
        annotations_src = sources / "annotations"
        sifts_src = sources / "sifts"
        foldseek_src = sources / "foldseek"
        smoke_src = sources / "query.pdb"
        (annotations_src).mkdir(parents=True)
        (sifts_src).mkdir(parents=True)
        (foldseek_src / "pdb").mkdir(parents=True)
        (annotations_src / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (sifts_src / "1abc.json").write_text("[]", encoding="utf-8")
        (foldseek_src / "pdb" / "db.index").write_text("demo", encoding="utf-8")
        smoke_src.write_text("HEADER\nEND\n", encoding="utf-8")

        output_root = tmp_path / "deploy_data"
        result = subprocess.run(
            [
                sys.executable,
                str(script),
                "--output",
                str(output_root),
                "--annotations",
                str(annotations_src),
                "--sifts",
                str(sifts_src),
                "--foldseek-root",
                str(foldseek_src),
                "--smoke-pdb",
                str(smoke_src),
            ],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert (output_root / "annotations" / "base.json").exists()
        assert (output_root / "sifts" / "1abc.json").exists()
        assert (output_root / "foldseek" / "pdb" / "db.index").exists()
        assert (output_root / "smoke" / "query.pdb").exists()
        assert (output_root / "import-manifest.json").exists()
        assert "Staged deploy_data root" in result.stdout

    def test_write_deploy_env_generates_override_files(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "write_deploy_env.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "sifts").mkdir(parents=True)
        (deploy_root / "sifts" / "1abc.json").write_text("[]", encoding="utf-8")
        (deploy_root / "foldseek").mkdir(parents=True)
        (deploy_root / "lipase").mkdir(parents=True)
        (deploy_root / "lipase" / "lipase.db").write_bytes(b"sqlite-format-placeholder")
        (deploy_root / "smoke").mkdir(parents=True)
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        backend_out = tmp_path / "backend.env"
        docker_out = tmp_path / "docker.env"
        result = subprocess.run(
            [
                sys.executable,
                str(script),
                "--deploy-root",
                str(deploy_root),
                "--backend-out",
                str(backend_out),
                "--docker-out",
                str(docker_out),
                "--foldseek-api-url",
                "http://foldseek.local/search",
            ],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        backend_content = backend_out.read_text()
        docker_content = docker_out.read_text()
        assert "DEPLOY_DATA_ROOT=" in backend_content
        assert "LOCAL_ANNOTATION_FIXTURE_PATH=" in backend_content
        assert "SIFTS_MAPPING_PATH=" in backend_content
        assert "FOLDSEEK_DATABASE_ROOT=" in backend_content
        assert "STRUCTURE_SMOKE_PDB_FILE=" in backend_content
        assert "LIPASE_DB_PATH=" in backend_content
        assert "FOLDSEEK_API_URL=http://foldseek.local/search" in backend_content
        assert "DEPLOY_DATA_HOST_PATH=" in docker_content
        assert "LIPASE_DB_PATH=/app/deploy_data/lipase/lipase.db" in docker_content
        assert "FOLDSEEK_API_URL=http://foldseek.local/search" in docker_content
        assert "Wrote backend overrides" in result.stdout

    def test_check_deploy_data_reports_partial_and_ready(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "check_deploy_data.py"
        deploy_root = tmp_path / "deploy_data"
        deploy_root.mkdir(parents=True)

        partial = subprocess.run(
            [sys.executable, str(script), "--root", str(deploy_root)],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert "annotations\tmissing\t" in partial.stdout
        assert "summary\tpartial\t" in partial.stdout
        assert "deploy_data/live_manifest.json" in partial.stdout

        (deploy_root / "live_manifest.json").write_text(
            json.dumps(
                {
                    "schema_version": 2,
                    "data_version": "test-live",
                    "updated_at": "2026-07-09",
                    "required_live_components": ["annotations", "sifts", "pdb", "alphafold", "foldseek", "smoke_query"],
                    "pdb_ids": ["1ABC"],
                    "uniprot_ids": ["P12345"],
                    "download_pae_json": True,
                    "expected_datasets": {
                        "annotations": {"expected_count": 2},
                        "foldseek": {"expected_subdatabases": ["pdb", "alphafold"]},
                    },
                }
            ),
            encoding="utf-8",
        )

        (deploy_root / "annotations").mkdir()
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "interpro.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"real_annotations"}',
            encoding="utf-8",
        )
        (deploy_root / "sifts").mkdir()
        (deploy_root / "sifts" / "1ABC.json").write_text("[]", encoding="utf-8")
        (deploy_root / "pdb").mkdir()
        (deploy_root / "pdb" / "1ABC.cif").write_text("data_1ABC\n", encoding="utf-8")
        (deploy_root / "alphafold").mkdir()
        (deploy_root / "alphafold" / "AF-P12345-F1-model_v1.cif").write_text("data_AF\n", encoding="utf-8")
        (deploy_root / "alphafold" / "AF-P12345-F1-predicted_aligned_error_v1.json").write_text("{}", encoding="utf-8")
        (deploy_root / "foldseek" / "pdb").mkdir(parents=True)
        (deploy_root / "foldseek" / "pdb" / "db.index").write_text("demo", encoding="utf-8")
        (deploy_root / "foldseek" / "alphafold").mkdir(parents=True)
        (deploy_root / "foldseek" / "alphafold" / "db.index").write_text("demo", encoding="utf-8")
        (deploy_root / "smoke").mkdir()
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        ready = subprocess.run(
            [sys.executable, str(script), "--root", str(deploy_root)],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert "annotations\tready\t" in ready.stdout
        assert "sifts\tready\t" in ready.stdout
        assert "pdb\tready\t" in ready.stdout
        assert "alphafold\tready\t" in ready.stdout
        assert "foldseek\tready\t" in ready.stdout
        assert "smoke_query\tready\t" in ready.stdout
        assert "summary\tlive-data-ready\t" in ready.stdout

    def test_check_deploy_data_flags_nonportable_foldseek_symlinks(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "check_deploy_data.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"real_annotations"}',
            encoding="utf-8",
        )
        (deploy_root / "sifts").mkdir()
        (deploy_root / "sifts" / "real_mapping.json").write_text("[]", encoding="utf-8")
        foldseek_pdb = deploy_root / "foldseek" / "pdb"
        foldseek_pdb.mkdir(parents=True)
        target = tmp_path / "outside.index"
        target.write_text("real", encoding="utf-8")
        (foldseek_pdb / "db.index").write_text("demo", encoding="utf-8")
        (foldseek_pdb / "db_ss_h").symlink_to(target)
        (deploy_root / "smoke").mkdir()
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        result = subprocess.run(
            [sys.executable, str(script), "--root", str(deploy_root)],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert "foldseek\tpartial\tnon-portable symlinks detected:" in result.stdout
        assert "summary\tpartial\t" in result.stdout

    def test_materialize_foldseek_links_replaces_symlinks(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "materialize_foldseek_links.py"
        foldseek_root = tmp_path / "foldseek"
        foldseek_root.mkdir()
        target = tmp_path / "db.target"
        target.write_text("payload", encoding="utf-8")
        link = foldseek_root / "db.link"
        link.symlink_to(target)

        result = subprocess.run(
            [sys.executable, str(script), "--root", str(foldseek_root)],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert link.exists()
        assert not link.is_symlink()
        assert link.read_text(encoding="utf-8") == "payload"
        assert "Materialized 1 Foldseek symlink" in result.stdout

    def test_check_deploy_data_reports_demo_only(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "check_deploy_data.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"local_demo"}',
            encoding="utf-8",
        )
        (deploy_root / "sifts").mkdir()
        (deploy_root / "sifts" / "1abc.json").write_text("[]", encoding="utf-8")
        (deploy_root / "smoke").mkdir()
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        result = subprocess.run(
            [sys.executable, str(script), "--root", str(deploy_root)],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert "annotations\tdemo\t" in result.stdout
        assert "sifts\tdemo\t" in result.stdout
        assert "summary\tdemo-data-only\t" in result.stdout

    def test_check_deploy_data_require_live_fails_for_demo_assets(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "check_deploy_data.py"
        deploy_root = tmp_path / "deploy_data"
        (deploy_root / "annotations").mkdir(parents=True)
        (deploy_root / "annotations" / "base.json").write_text('{"records":[]}', encoding="utf-8")
        (deploy_root / "annotations" / "metadata.json").write_text(
            '{"default_source_db":"local_demo"}',
            encoding="utf-8",
        )
        (deploy_root / "sifts").mkdir()
        (deploy_root / "sifts" / "1abc.json").write_text("[]", encoding="utf-8")
        (deploy_root / "foldseek" / "pdb").mkdir(parents=True)
        (deploy_root / "foldseek" / "pdb" / "db.index").write_text("demo", encoding="utf-8")
        (deploy_root / "smoke").mkdir()
        (deploy_root / "smoke" / "query.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        result = subprocess.run(
            [sys.executable, str(script), "--root", str(deploy_root), "--require-live"],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
        assert "summary\tdemo-data-only\t" in result.stdout

    def test_discover_deploy_data_sources_finds_expected_candidates(self, tmp_path):
        script = PROJECT_ROOT / "scripts" / "discover_deploy_data_sources.py"
        root = tmp_path / "workspace"
        (root / "exports" / "annotations").mkdir(parents=True)
        (root / "exports" / "sifts").mkdir(parents=True)
        (root / "exports" / "foldseek").mkdir(parents=True)
        (root / "exports" / "alphafold").mkdir(parents=True)
        (root / "exports" / "annotations" / "interpro.json").write_text("{}", encoding="utf-8")
        (root / "exports" / "sifts" / "real_mapping.json").write_text("[]", encoding="utf-8")
        (root / "exports" / "foldseek" / "alis_pdb100.m8").write_text("", encoding="utf-8")
        (root / "exports" / "alphafold" / "A0A1.pdb").write_text("HEADER\nEND\n", encoding="utf-8")

        result = subprocess.run(
            [sys.executable, str(script), "--root", str(root)],
            cwd=PROJECT_ROOT,
            env=os.environ.copy(),
            capture_output=True,
            text=True,
            check=True,
        )
        assert "annotations\t" in result.stdout
        assert "sifts\t" in result.stdout
        assert "foldseek_reference\t" in result.stdout
        assert "alphafold_reference\t" in result.stdout


class TestDockerfiles:
    """Phase 1: Dockerfile validation."""

    def test_worker_dockerfile_has_torch_cpu(self):
        df = PROJECT_ROOT / "docker" / "Dockerfile.worker"
        content = df.read_text()
        assert "--index-url https://download.pytorch.org/whl/cpu" in content, (
            "Worker Dockerfile missing torch CPU wheel install"
        )

    def test_worker_dockerfile_has_rdkit_libs(self):
        df = PROJECT_ROOT / "docker" / "Dockerfile.worker"
        content = df.read_text()
        for lib in ["libxrender1", "libxext6", "libsm6"]:
            assert lib in content, f"Worker Dockerfile missing RDKit lib: {lib}"

    def test_worker_dockerfile_has_model_cache(self):
        df = PROJECT_ROOT / "docker" / "Dockerfile.worker"
        content = df.read_text()
        assert "esm2_t33_650M_UR50D" in content, (
            "Worker Dockerfile should pre-download ESM-2 model"
        )
        assert "COPY --from=builder /root/.cache/torch/hub" in content, (
            "Worker Dockerfile should copy model cache to runtime"
        )

    def test_backend_dockerfile_no_rdkit(self):
        """Backend uses core-only deps (no torch/ML). RDKit libs go in worker."""
        df = PROJECT_ROOT / "docker" / "Dockerfile.backend"
        content = df.read_text()
        # Backend should NOT have RDKit system libs — ML runs on worker
        for lib in ["libxrender1", "libxext6", "libsm6"]:
            assert lib not in content, (
                f"Backend Dockerfile should NOT have {lib} — RDKit runs on worker only"
            )
        # Should use requirements-prod.txt (core only, no torch)
        assert "requirements-prod.txt" in content, (
            "Backend Dockerfile must use requirements-prod.txt (core only)"
        )

    def test_backend_dockerfile_selects_foldseek_by_arch(self):
        df = PROJECT_ROOT / "docker" / "Dockerfile.backend"
        content = df.read_text()
        assert "ARG TARGETARCH" in content
        assert "foldseek-linux-arm64.tar.gz" in content
        assert "foldseek-linux-avx2.tar.gz" in content

    def test_ligand_worker_dockerfile_has_chemistry_runtime(self):
        df = PROJECT_ROOT / "docker" / "Dockerfile.ligand-worker"
        content = df.read_text()
        assert "openbabel" in content
        assert "autodock-vina" in content
        assert "gromacs" in content
        assert "acpype" in content
        assert "rdkit" in content
        assert "antechamber" in content
        assert "parmchk2" in content
        assert "AMBERHOME" in content
        assert "LIGAND_RUNTIME_BOUNDARY" in content
        assert "ligand-runtime-check" in content
        assert "--require-live" in content
        assert "--queues=ligand_cpu" in content
        assert "requirements-prod.txt" in content
        assert '"ligand_topology": tools["acpype"]["available"]' in content

    def test_aliyun_ligand_worker_dockerfile_is_backend_overlay(self):
        df = PROJECT_ROOT / "docker" / "Dockerfile.ligand-worker.aliyun"
        content = df.read_text()
        assert "FROM protein-ai-backend:aliyun" in content
        assert "openbabel" in content
        assert "autodock-vina" in content
        assert "acpype" in content
        assert "rdkit" in content
        assert "AMBERHOME" in content
        assert "antechamber" in content
        assert "parmchk2" in content
        assert "teLeap" in content
        assert "libhdf4-0" in content
        assert "libhdf5-hl-310" in content
        assert "libzip5" in content
        assert "libcrypto.so.3.bundled" in content
        assert "mirrors.aliyun.com/debian" in content
        assert "mirrors.aliyun.com/pypi/simple" in content
        assert "ligand-runtime-check" in content
        assert "COPY --chown=appuser:appuser backend/ /app/" in content
        assert "--queues=ligand_cpu" in content

    def test_ligand_runtime_check_requires_tleap_loadable(self):
        script = PROJECT_ROOT / "docker" / "ligand-runtime-check.py"
        content = script.read_text()
        assert "teLeap" in content
        assert "require_all=True" in content
        assert "error while loading shared libraries" in content
        assert "command_checks" in content


class TestDockerCompose:
    """Phase 2: docker-compose.yml hardening validation."""

    @pytest.fixture
    def compose_content(self):
        compose = PROJECT_ROOT / "docker" / "docker-compose.yml"
        return compose.read_text()

    def test_no_public_postgres_port(self, compose_content):
        """Port 5432 should NOT be exposed publicly."""
        # Look for 'ports:' followed by '5432' in the postgres section
        assert '"5432:5432"' not in compose_content, "PostgreSQL port 5432 should not be public"

    def test_no_public_redis_port(self, compose_content):
        assert '"6379:6379"' not in compose_content, "Redis port 6379 should not be public"

    def test_no_public_minio_ports(self, compose_content):
        assert '"9000:9000"' not in compose_content, "MinIO S3 port 9000 should not be public"
        assert '"9001:9001"' not in compose_content, "MinIO console port 9001 should not be public"

    def test_no_public_chromadb_port(self, compose_content):
        assert '"8001:8000"' not in compose_content, "ChromaDB port 8001 should not be public"

    def test_no_public_outline_port(self, compose_content):
        assert '"3001:3001"' not in compose_content, "Outline port 3001 should not be public"

    def test_nginx_has_443(self, compose_content):
        assert '"443:443"' in compose_content, "Nginx should expose port 443 for HTTPS"

    def test_log_rotation_present(self, compose_content):
        assert "max-size" in compose_content, "Log rotation (max-size) missing"
        assert "max-file" in compose_content, "Log rotation (max-file) missing"

    def test_health_checks_present(self, compose_content):
        assert "healthcheck:" in compose_content, "Health checks missing"
        # Should have health checks for backend, workers, frontend
        assert "curl" in compose_content or "wget" in compose_content

    def test_md_worker_queue_isolated(self, compose_content):
        assert "md-worker:" in compose_content, "Dedicated md-worker service missing"
        assert "--queues=md_cpu" in compose_content, "md-worker must consume md_cpu queue"
        assert "CELERY_MD_WORKER_CONCURRENCY" in compose_content, "md-worker concurrency env missing"

    def test_ligand_worker_queue_isolated(self, compose_content):
        assert "ligand-worker:" in compose_content, "Dedicated ligand-worker service missing"
        assert "Dockerfile.ligand-worker" in compose_content, "ligand-worker must use dedicated chemistry runtime"
        assert "--queues=ligand_cpu" in compose_content, "ligand-worker must consume ligand_cpu queue"
        assert "CELERY_LIGAND_WORKER_CONCURRENCY" in compose_content, "ligand-worker concurrency env missing"
        assert "LIGAND_RUNTIME_BOUNDARY: ligand_worker_only" in compose_content
        assert "LIGAND_RUNTIME_CHECK: /usr/local/bin/ligand-runtime-check" in compose_content
        assert "AMBERHOME: ${AMBERHOME:-/opt/ambertools}" in compose_content
        assert "ligand_scratch:/app/storage" in compose_content

    def test_deploy_data_mount_present_for_app_services(self, compose_content):
        assert "DEPLOY_DATA_ROOT: /app/deploy_data" in compose_content
        assert "${DEPLOY_DATA_HOST_PATH:-../deploy_data}:/app/deploy_data:ro" in compose_content
        assert "- .env.deploy-data" in compose_content

    def test_default_worker_stays_on_default_queue(self, compose_content):
        assert "--queues=default" in compose_content, "default worker must stay on default queue"
        assert "CELERY_DEFAULT_WORKER_CONCURRENCY" in compose_content, "default worker concurrency env missing"

    def test_https_cors_origins(self, compose_content):
        """CORS should use HTTPS origins, not HTTP."""
        # Find CORS_ORIGINS lines
        cors_lines = [l for l in compose_content.splitlines() if "CORS_ORIGINS" in l]
        for line in cors_lines:
            if "localhost" not in line:  # Skip dev defaults
                assert "https://" in line, f"CORS should use HTTPS: {line}"

    def test_ssl_volume_mount(self, compose_content):
        assert "./ssl:/etc/nginx/ssl" in compose_content, (
            "Nginx should mount SSL certificate directory"
        )

    def test_aliyun_app_compose_uses_managed_services(self):
        compose = PROJECT_ROOT / "docker" / "docker-compose.aliyun-app.yml"
        content = compose.read_text()
        assert "ALIYUN_APP_DATABASE_URL" in content
        assert "ALIYUN_REDIS_HOST" in content
        assert "ALIYUN_OSS_ENDPOINT" in content
        assert "FORCE_HTTPS: ${OUTLINE_FORCE_HTTPS:-false}" in content
        assert "ligand-worker:" in content
        assert "protein-ai-ligand-worker:aliyun" in content
        assert "--queues=ligand_cpu" in content
        assert "md-worker:" in content
        assert "--queues=md_cpu" in content
        assert "Dockerfile.ligand-worker.aliyun" in content
        assert "LIGAND_RUNTIME_CHECK: /usr/local/bin/ligand-runtime-check" in content
        assert "\n  postgres:\n" not in content
        assert "\n  minio:\n" not in content
        assert "\n  redis:\n" not in content

    def test_aliyun_gpu_compose_only_runs_md_worker(self):
        compose = PROJECT_ROOT / "docker" / "docker-compose.aliyun-gpu.yml"
        content = compose.read_text()
        assert "md-worker:" in content
        assert "ligand-worker:" in content
        assert "--queues=md_cpu" in content
        assert "--queues=ligand_cpu" in content
        assert "Dockerfile.ligand-worker.aliyun" in content
        assert "LIGAND_RUNTIME_BOUNDARY: ligand_worker_only" in content
        assert "LIGAND_RUNTIME_CHECK: /usr/local/bin/ligand-runtime-check" in content
        assert "GPU_DEVICE_REQUEST" in content
        assert "\n  frontend:\n" not in content
        assert "\n  backend:\n" not in content


class TestNginxConfig:
    """Phase 2: nginx.conf validation."""

    @pytest.fixture
    def nginx_content(self):
        conf = PROJECT_ROOT / "docker" / "nginx.conf"
        return conf.read_text()

    def test_https_redirect(self, nginx_content):
        assert "return 301 https://" in nginx_content, "HTTP→HTTPS redirect missing"

    def test_ssl_listen(self, nginx_content):
        assert "listen       443 ssl" in nginx_content, "SSL listener missing"

    def test_tls_protocols(self, nginx_content):
        assert "TLSv1.2" in nginx_content, "TLS 1.2 missing"
        assert "TLSv1.3" in nginx_content, "TLS 1.3 missing"

    def test_security_headers(self, nginx_content):
        assert "Strict-Transport-Security" in nginx_content, "HSTS header missing"
        assert "X-Content-Type-Options" in nginx_content, "X-Content-Type-Options missing"
        assert "X-XSS-Protection" in nginx_content, "X-XSS-Protection missing"

    def test_sse_streaming_preserved(self, nginx_content):
        """SSE proxy_buffering off must still be present for /api/."""
        assert "proxy_buffering        off" in nginx_content, "SSE streaming disabled!"

    def test_top_level_wiki_navigation_returns_spa(self, nginx_content):
        """Top-level /wiki/* documents must hit SPA auth before Outline."""
        assert "$wiki_spa_document" in nginx_content
        assert "~^document:/wiki/(home|search)$" in nginx_content
        assert "~^document:/wiki/(doc|collection)/" in nginx_content
        assert "error_page 418 = @frontend_spa" in nginx_content
        assert "error_page 418 = @frontend_spa_tls" in nginx_content
        assert "proxy_pass http://$frontend_host/index.html" in nginx_content

    def test_outline_native_routes_proxy_to_backend(self, nginx_content):
        """Embedded Outline documents use root routes because /wiki subpaths break Outline SPA routing."""
        assert "^/(doc|collection|search|settings|archive|drafts|trash|templates|share|s)(/|$)" in nginx_content
        assert "proxy_pass http://$backend_host$request_uri" in nginx_content

    def test_ssl_cert_paths(self, nginx_content):
        assert "/etc/nginx/ssl/server.crt" in nginx_content
        assert "/etc/nginx/ssl/server.key" in nginx_content


class TestGetCurrentUserDependency:
    """Regression: get_current_user returns dict, not User model."""

    def test_get_current_user_returns_dict(self):
        """get_current_user return type must be dict.

        Regression test for bug where projects.py used `user: User` type
        annotation which failed with AttributeError because get_current_user
        returns a dict, not a User model.
        """
        from app.core.security import get_current_user
        import inspect

        sig = inspect.signature(get_current_user)
        return_annotation = sig.return_annotation
        # from __future__ import annotations makes this a string
        annotation_str = str(return_annotation).lower()
        assert "dict" in annotation_str, (
            f"get_current_user must return dict, not {return_annotation}"
        )
        assert "user" not in annotation_str, (
            f"get_current_user must NOT return User model, got: {return_annotation}"
        )

    def test_no_user_model_import_in_projects_api(self):
        """projects.py must NOT import User model — user is dict, not ORM."""
        projects_path = Path(__file__).resolve().parent.parent / "app" / "api" / "projects.py"
        content = projects_path.read_text()
        assert "from app.models.user import User" not in content, (
            "projects.py should not import User model — user is a dict from get_current_user"
        )
        assert "user: User" not in content, (
            "projects.py should annotate user as dict, not User"
        )
        # Must use dict access pattern
        assert 'user["id"]' in content, (
            "projects.py must use user[\"id\"] (dict access), not user.id"
        )


class TestSecuritySecrets:
    """Phase 2: Verify secrets are not default/weak values."""

    def test_docker_env_no_default_postgres_password(self):
        env = PROJECT_ROOT / "docker" / ".env"
        if env.exists():
            content = env.read_text()
            assert "POSTGRES_PASSWORD=postgres" not in content, (
                "docker/.env still has default postgres password!"
            )

    def test_docker_env_no_default_minio_password(self):
        env = PROJECT_ROOT / "docker" / ".env"
        if env.exists():
            content = env.read_text()
            assert "MINIO_ROOT_PASSWORD=minioadmin" not in content, (
                "docker/.env still has default minio password!"
            )

    def test_docker_env_no_dev_secret(self):
        env = PROJECT_ROOT / "docker" / ".env"
        if env.exists():
            content = env.read_text()
            assert "dev-secret" not in content, "docker/.env still has dev SECRET_KEY!"


class TestProductionConfigGate:
    def test_production_config_script_redacts_secrets_and_allows_ip_stage(self, tmp_path):
        env_file = tmp_path / ".env.production"
        env_file.write_text(
            "\n".join([
                "DEBUG=false",
                "SECRET_KEY=this-is-a-long-random-test-secret-value",
                "OIDC_CLIENT_SECRET=this-is-a-long-oidc-test-secret",
                "ALIYUN_APP_DATABASE_URL=postgresql+asyncpg://user:pass@pg.example.com:5432/protein_ai",
                "ALIYUN_REDIS_HOST=redis.example.com",
                "ALIYUN_OSS_ENDPOINT=oss-cn-hangzhou-internal.aliyuncs.com",
                "ALIYUN_OSS_BUCKET=protein-ai-files",
                "ALIYUN_OSS_ACCESS_KEY_ID=test-access-key",
                "ALIYUN_OSS_ACCESS_KEY_SECRET=this-is-a-long-storage-secret",
                "LLM_PROVIDER=kuaPao",
                "KUAPAO_API_KEY=test-llm-key",
                "PUBLIC_BASE_URL=http://120.27.108.138",
            ]),
            encoding="utf-8",
        )

        isolated_env = os.environ.copy()
        for key in (
            "DEBUG",
            "SECRET_KEY",
            "OIDC_CLIENT_SECRET",
            "DATABASE_URL",
            "ALIYUN_APP_DATABASE_URL",
            "REDIS_URL",
            "REDIS_HOST",
            "ALIYUN_REDIS_APP_URL",
            "ALIYUN_REDIS_HOST",
            "MINIO_ENDPOINT",
            "MINIO_BUCKET",
            "MINIO_ACCESS_KEY",
            "MINIO_SECRET_KEY",
            "ALIYUN_OSS_ENDPOINT",
            "ALIYUN_OSS_BUCKET",
            "ALIYUN_OSS_ACCESS_KEY_ID",
            "ALIYUN_OSS_ACCESS_KEY_SECRET",
            "LLM_PROVIDER",
            "KUAPAO_API_KEY",
            "PUBLIC_BASE_URL",
            "FRONTEND_URL",
            "OIDC_ISSUER",
            "OIDC_PRIVATE_KEY_PATH",
            "OIDC_PUBLIC_KEY_PATH",
        ):
            isolated_env.pop(key, None)

        proc = subprocess.run(
            [
                sys.executable,
                str(PROJECT_ROOT / "scripts" / "check_production_config.py"),
                "--json",
                "--mode",
                "production",
                "--skip-domain-https",
                "--env-file",
                str(env_file),
            ],
            cwd=PROJECT_ROOT,
            env=isolated_env,
            text=True,
            capture_output=True,
            check=False,
        )

        assert proc.returncode == 0
        payload = json.loads(proc.stdout)
        assert payload["summary"]["critical"] == 0
        assert payload["secrets_printed"] is False
        assert "this-is-a-long-storage-secret" not in proc.stdout
        assert "this-is-a-long-random-test-secret-value" not in proc.stdout

    def test_acceptance_and_nightly_include_production_config_gate(self):
        acceptance = (PROJECT_ROOT / "scripts" / "run_acceptance_matrix.py").read_text(encoding="utf-8")
        nightly = (PROJECT_ROOT / "scripts" / "run_nightly_live_gates.py").read_text(encoding="utf-8")
        makefile = (PROJECT_ROOT / "Makefile").read_text(encoding="utf-8")

        assert "production_config_gate" in acceptance
        assert "check_production_config.py" in acceptance
        assert "docker/.env.aliyun.app" in acceptance
        assert "production_config" in nightly
        assert "nightly-live-gates" in makefile
