"""Tests for the Binder Design pipeline (Phase 3).

Covers:
- T8: proteinmpnn_design category is "design"
- T9: _generate_fallback_plan() binder branches (with/without sequence)
- T10: Router correctly classifies binder design intent
- T11: _load_relevant_skills loads protein_design
- T11: _build_fallback_report includes design results section
"""

import pytest
import sys
import os
import asyncio
import json
from pathlib import Path

# Ensure app package is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

ENZYME_AGENT_EVAL_CASES = json.loads(
    (Path(__file__).with_name("enzyme_agent_eval_cases.json")).read_text()
)


@pytest.fixture(autouse=True, scope="session")
def discover_tools():
    """Ensure all tools are registered before tests run."""
    from app.tools.registry import ToolRegistry
    if not ToolRegistry._tools:
        ToolRegistry.discover()


class TestProteinMPNNCategory:
    """T8: proteinmpnn_design should be category='design', not 'engineering'."""

    def test_category_is_design(self):
        from app.tools.registry import ToolRegistry
        # Force import of all tools
        import app.tools.proteinmpnn_design  # noqa: F401

        tool = ToolRegistry.get_tool("proteinmpnn_design")
        assert tool is not None, "proteinmpnn_design not registered"
        assert tool.category == "design", (
            f"Expected category='design', got '{tool.category}'"
        )

    def test_pdb_required_tools_includes_esm_if1(self):
        from app.core.agent_graph import _PDB_REQUIRED_TOOLS
        assert "proteinmpnn_design" in _PDB_REQUIRED_TOOLS
        assert "esm_if1_design" in _PDB_REQUIRED_TOOLS


class TestBinderRouting:
    """T10: Router classifies binder design intent correctly."""

    def test_binder_routes_to_design(self):
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        # These should all route to "design" via deterministic keywords
        test_cases = [
            "Design a binder for PD-L1",
            "I want to design a protein that binds EGFR",
            "de novo protein design targeting KRAS",
            "设计一个结合PD-L1的蛋白",
            "从头设计蛋白骨架",
        ]
        for msg in test_cases:
            lower = msg.lower()
            has_design_kw = any(kw in lower for kw in [
                "设计", "design", "生成序列", "generate sequence", "binder"
            ])
            assert has_design_kw, f"'{msg}' should contain design keywords"

    def test_enzyme_engineering_still_routes_to_analyze(self):
        """Regression: enzyme engineering tasks must NOT route to design."""
        lower = "提高这个酶的热稳定性".lower()
        is_design = any(kw in lower for kw in [
            "设计", "design", "生成序列", "generate sequence", "binder"
        ])
        is_analyze = any(kw in lower for kw in [
            "突变", "mutation", "stability", "stabilize", "耐热", "热稳定",
        ])
        assert not is_design, "Enzyme engineering should not be classified as design"
        assert is_analyze, "Enzyme engineering should be classified as analyze"

    def test_model_meta_question_routes_to_general(self):
        """P0: model capability/citation questions must not enter sequence_search."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        route = asyncio.run(orch._route_intent("这个模型现在的能力边界是什么？有没有文献依据？", ""))

        assert route == "general"

    def test_model_meta_question_ignores_prior_protein_context_for_routing(self):
        """P0: current meta question stays general even in an existing protein chat."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        route = asyncio.run(
            orch._route_intent(
                "这个模型会不会胡编？结果有没有文献依据？",
                "[Known protein target discussed]",
            )
        )

        assert route == "general"

    def test_governance_question_uses_local_evidence_tool_plan(self):
        from app.core.agent_graph import AgentOrchestrator

        orch = AgentOrchestrator()
        plan = orch._generate_fallback_plan("当前模型能否客户交付？release ready 吗？")
        assert [step.tool_name for step in plan] == ["external_research_evidence"]
        assert plan[0].params == {"scope": "all"}

    def test_missing_enzyme_input_requires_clarification(self):
        """P0: enzyme engineering intent without actionable input should ask first."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()
        message = "帮我改造这个酶提高耐热性，但我只给你一句需求。"

        assert orch._should_clarify_before_tools(message, "analyze", "") is True
        reply = orch._build_missing_input_reply(message, "analyze")
        assert "缺失信息" in reply
        assert "不会直接给具体位点或强结论" in reply

    def test_experiment_plan_design_does_not_route_to_protein_design(self):
        """P0: experimental-plan wording must not trigger binder/protein design."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        route = asyncio.run(orch._route_intent("请设计实验方案验证这个酶的耐热性", ""))

        assert route == "analyze"
        assert orch._should_clarify_before_tools("请设计实验方案验证这个酶的耐热性", route, "") is True


class TestBinderFallbackPlan:
    """T9: _generate_fallback_plan() binder branches."""

    def _get_orchestrator(self):
        from app.core.agent_graph import AgentOrchestrator
        # Ensure tools are registered
        from app.tools import registry as _  # noqa: F401
        return AgentOrchestrator()

    def test_binder_plan_no_sequence(self):
        """'Design a binder for PD-L1' should trigger binder pipeline without sequence."""
        orch = self._get_orchestrator()
        plan = orch._generate_fallback_plan("Design a binder for PD-L1")

        tool_names = [s.tool_name for s in plan]

        # Should have sequence_search (to find PD-L1) and design tools
        assert len(plan) > 0, "Plan should not be empty"
        assert "sequence_search" in tool_names, (
            f"No-sequence binder plan should include sequence_search. Got: {tool_names}"
        )

        # Should include at least one design tool
        design_tools = {"rfdiffusion_design", "chroma_design", "proteinmpnn_design"}
        found_design = design_tools & set(tool_names)
        assert found_design, (
            f"No-sequence binder plan should include design tools. Got: {tool_names}"
        )

    def test_binder_plan_with_sequence(self):
        """Binder task with a sequence should use inverse folding pipeline."""
        seq = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        orch = self._get_orchestrator()
        plan = orch._generate_fallback_plan(
            f"Design a binder for this scaffold: {seq}"
        )

        tool_names = [s.tool_name for s in plan]
        assert len(plan) > 0, "Plan should not be empty"

        # With sequence + binder design: should NOT have mutation_priority_score
        # (that's for enzyme engineering, not binder design)
        assert "mutation_priority_score" not in tool_names, (
            "Binder design plan should not include enzyme engineering tools"
        )

    def test_enzyme_plan_not_affected(self):
        """Regression: enzyme engineering with sequence still uses the full pipeline."""
        seq = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        orch = self._get_orchestrator()
        plan = orch._generate_fallback_plan(
            f"提高这个酶的热稳定性 {seq}"
        )

        tool_names = [s.tool_name for s in plan]
        assert "predict_properties" in tool_names, "Enzyme plan should have predict_properties"
        assert "mutation_priority_score" in tool_names, (
            "Enzyme engineering plan should include mutation_priority_score"
        )

    def test_no_binder_no_sequence_fallback(self):
        """Generic query without sequence or binder intent → sequence_search."""
        orch = self._get_orchestrator()
        plan = orch._generate_fallback_plan("Analyze the structure of EGFR")

        tool_names = [s.tool_name for s in plan]
        assert "sequence_search" in tool_names, (
            f"Generic no-sequence query should use sequence_search. Got: {tool_names}"
        )
        # Should NOT have design tools
        design_tools = {"rfdiffusion_design", "chroma_design"}
        assert not (design_tools & set(tool_names)), (
            "Non-binder query should not trigger design tools"
        )

    def test_generic_meta_question_does_not_fallback_to_sequence_search(self):
        """P0: broad system questions should not use whole-sentence UniProt search."""
        orch = self._get_orchestrator()
        plan = orch._generate_fallback_plan("这个模型有没有文献依据，会不会胡编？")

        assert plan == []

    def test_no_target_binder_design_does_not_search_whole_sentence(self):
        """P0: binder design without a concrete target should clarify, not search."""
        orch = self._get_orchestrator()
        plan = orch._generate_fallback_plan("Design a binder")

        assert plan == []
        assert orch._should_clarify_before_tools("Design a binder", "design", "") is True

    def test_stream_missing_input_returns_clarification_without_tools(self):
        """P0: stream path should stop before planning/execution when inputs are missing."""
        orch = self._get_orchestrator()

        async def collect():
            events = []
            async for event in orch.stream_chat("帮我改造这个酶提高耐热性", []):
                events.append(event)
            return events

        events = asyncio.run(collect())
        contents = [
            json.loads(event).get("content", "")
            for event in events
            if event.strip().startswith("{") and json.loads(event).get("type") == "text"
        ]
        joined = "\n".join(contents)

        assert "当前输入还不足以进入工具分析" in joined
        assert not any("sequence_search" in event for event in events)
        assert any(json.loads(event).get("type") == "done" for event in events if event.strip().startswith("{"))

    def test_stream_targetless_binder_returns_clarification_without_tools(self):
        """P0: targetless binder request should ask for a target instead of searching."""
        orch = self._get_orchestrator()

        async def collect():
            events = []
            async for event in orch.stream_chat("Design a binder", []):
                events.append(event)
            return events

        events = asyncio.run(collect())
        contents = [
            json.loads(event).get("content", "")
            for event in events
            if event.strip().startswith("{") and json.loads(event).get("type") == "text"
        ]
        joined = "\n".join(contents)

        assert "当前输入还不足以进入工具分析" in joined
        assert not any("sequence_search" in event for event in events)
        assert any(json.loads(event).get("type") == "done" for event in events if event.strip().startswith("{"))

    def test_extract_protein_name_binder(self):
        """_extract_protein_name should pull 'PD-L1' from binder queries."""
        from app.core.agent_graph import AgentOrchestrator
        name = AgentOrchestrator._extract_protein_name("Design a binder for PD-L1")
        assert "PD-L1" in name or "PD" in name, f"Expected PD-L1, got: {name}"

    def test_extract_protein_name_complex(self):
        from app.core.agent_graph import AgentOrchestrator
        name = AgentOrchestrator._extract_protein_name(
            "I need to design a high-affinity binder targeting human EGFR protein"
        )
        assert "EGFR" in name, f"Expected EGFR, got: {name}"


class TestEnzymeAgentEvalSet:
    """P2: fixed enzyme-task eval set for routing, clarification, and tool choice."""

    def _get_orchestrator(self):
        from app.core.agent_graph import AgentOrchestrator
        from app.tools import registry as _  # noqa: F401
        return AgentOrchestrator()

    @pytest.mark.parametrize("case", ENZYME_AGENT_EVAL_CASES, ids=[case["id"] for case in ENZYME_AGENT_EVAL_CASES])
    def test_eval_case_route_clarification_and_tools(self, case):
        orch = self._get_orchestrator()
        message = case["message"]

        route = asyncio.run(orch._route_intent(message, ""))
        assert route == case["expected_route"]
        assert orch._should_clarify_before_tools(message, route, "") is case["expect_clarification"]

        plan = [] if case["expect_clarification"] or route == "general" else orch._generate_fallback_plan(message)
        tool_names = [step.tool_name for step in plan]

        for tool in case["required_tools"]:
            assert tool in tool_names, f"{case['id']} should include {tool}; got {tool_names}"
        for tool in case["forbidden_tools"]:
            assert tool not in tool_names, f"{case['id']} should not include {tool}; got {tool_names}"

    def test_stream_no_plan_uses_missing_input_reply_not_generic_english_fallback(self):
        orch = self._get_orchestrator()
        history = [
            {
                "role": "user",
                "content": "之前的序列是 MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE",
            }
        ]

        async def collect_text() -> str:
            chunks = []
            async for event in orch.stream_chat("分析此蛋白质序列的热稳定性和pH稳定性。", history):
                try:
                    payload = json.loads(event)
                except json.JSONDecodeError:
                    continue
                if payload.get("type") == "text":
                    chunks.append(str(payload.get("content") or ""))
            return "".join(chunks)

        reply = asyncio.run(collect_text())
        assert "I couldn't determine how to help" not in reply
        assert "缺失信息" in reply
        assert "完整氨基酸序列" in reply

    def test_uploaded_pdb_stability_request_generates_structure_plan(self):
        orch = self._get_orchestrator()
        message = (
            "分析上传PDB附件的热稳定性和pH稳定性。\n\n"
            "[Attached files:\n"
            "- name: test.pdb, object_name: uploads/user_1/test.pdb, download_url: /api/files/uploads/user_1/test.pdb/download]"
        )

        route = asyncio.run(orch._route_intent(message, ""))
        assert route == "analyze"
        assert orch._should_clarify_before_tools(message, route, "") is False

        plan = orch._generate_fallback_plan(message)
        tool_names = [step.tool_name for step in plan]
        assert "structure_search_foldseek" in tool_names
        structure_step = next(step for step in plan if step.tool_name == "structure_search_foldseek")
        assert structure_step.params["pdb_object_name"] == "uploads/user_1/test.pdb"

    def test_uploaded_pdb_with_sequence_gates_structure_before_sequence_tools(self):
        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        message = (
            f"分析上传PDB附件的热稳定性和pH稳定性，并评估M204H。{sequence}\n\n"
            "[Attached files:\n"
            "- name: test.pdb, object_name: uploads/user_1/test.pdb, download_url: /api/files/uploads/user_1/test.pdb/download]"
        )

        plan = orch._generate_fallback_plan(message, analysis_depth="deep")
        tool_names = [step.tool_name for step in plan]

        assert tool_names[:3] == ["structure_search_foldseek", "residue_mapping_sifts", "residue_numbering_gate"]
        assert "esmfold_folding" not in tool_names
        assert tool_names.index("predict_properties") > tool_names.index("residue_mapping_sifts")
        assert tool_names.index("annotation_bundle") > tool_names.index("residue_mapping_sifts")
        assert tool_names.index("annotation_bundle") < tool_names.index("enzyme_identity_profile")
        assert tool_names.index("enzyme_identity_profile") > tool_names.index("residue_mapping_sifts")
        assert tool_names.index("enzyme_identity_profile") < tool_names.index("protein_benchmark")
        assert tool_names.index("enzyme_identity_profile") < tool_names.index("enzyme_function")
        assert tool_names.index("mutation_priority_score") > tool_names.index("residue_numbering_gate")

    def test_sequence_only_structure_request_waits_for_esmfold_before_structural_inference(self):
        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        message = f"仅有序列，请分析口袋、催化网络、结构暴露度和热稳定性。{sequence}"

        plan = orch._generate_fallback_plan(message, analysis_depth="deep")
        tool_names = [step.tool_name for step in plan]

        assert "predict_properties" in tool_names
        assert "esmfold_folding" in tool_names
        assert tool_names.index("predict_properties") < tool_names.index("annotation_bundle")
        assert tool_names.index("annotation_bundle") < tool_names.index("enzyme_identity_profile")
        assert tool_names.index("enzyme_identity_profile") < tool_names.index("protein_benchmark")
        assert tool_names.index("enzyme_identity_profile") < tool_names.index("enzyme_function")
        assert tool_names.index("enzyme_function") < tool_names.index("esmfold_folding")
        assert tool_names.index("esmfold_folding") < tool_names.index("mutation_priority_score")

    def test_chinese_uploaded_structure_context_enters_structure_tool_plan(self):
        orch = self._get_orchestrator()
        message = "酶的名称：天冬氨酸蛋白酶 结构已上传 目标：提高耐热性 底物酪蛋白，反应条件40度，表达体系毕赤酵母"
        history = [
            {
                "role": "user",
                "content": (
                    "[Attached files:\n"
                    "- name: aspartic_protease.pdb, object_name: uploads/user_7/aspartic_protease.pdb, "
                    "download_url: /api/files/uploads/user_7/aspartic_protease.pdb/download]"
                ),
            }
        ]
        context = orch._build_context(history)

        route = asyncio.run(orch._route_intent(message, context))
        assert route == "analyze"
        assert orch._should_clarify_before_tools(message, route, context) is False

        plan = orch._generate_fallback_plan(message, context=context)
        tool_names = [step.tool_name for step in plan]
        assert "structure_search_foldseek" in tool_names
        structure_step = next(step for step in plan if step.tool_name == "structure_search_foldseek")
        assert structure_step.params["pdb_object_name"] == "uploads/user_7/aspartic_protease.pdb"

    def test_chinese_named_enzyme_without_attachment_searches_instead_of_fixed_clarification(self):
        orch = self._get_orchestrator()
        message = "酶的名称：天冬氨酸蛋白酶 目标：提高耐热性 底物酪蛋白，反应条件40度，表达体系毕赤酵母"

        route = asyncio.run(orch._route_intent(message, ""))
        assert route == "analyze"
        assert orch._should_clarify_before_tools(message, route, "") is False

        plan = orch._generate_fallback_plan(message)
        tool_names = [step.tool_name for step in plan]
        assert "sequence_search" in tool_names
        search_step = next(step for step in plan if step.tool_name == "sequence_search")
        assert search_step.params["query"] == "天冬氨酸蛋白酶"

    @pytest.mark.parametrize(
        ("message", "expected_query", "expected_database"),
        [
            ("酶名称：脂肪酶 目标：提高耐热性", "脂肪酶", "uniprot"),
            ("蛋白：天冬氨酸蛋白酶 目标：耐酸", "天冬氨酸蛋白酶", "uniprot"),
            ("蛋白质：碱性蛋白酶 目标：提高 pH 9 稳定性", "碱性蛋白酶", "uniprot"),
            ("目标酶: amylase 目标: 提高40度稳定性", "amylase", "uniprot"),
            ("UniProt编号：P00691 目标：分析热稳定性", "P00691", "uniprot"),
            ("PDB编号：1BAG 目标：分析pH稳定性", "1BAG", "pdb"),
            ("PDB: 1BAG 目标：分析pH稳定性", "1BAG", "pdb"),
            ("酶名称：脂肪酶 突变M204H 目标：提高耐热性", "脂肪酶", "uniprot"),
        ],
    )
    def test_concrete_reference_variants_search_instead_of_fixed_clarification(
        self,
        message,
        expected_query,
        expected_database,
    ):
        orch = self._get_orchestrator()

        route = asyncio.run(orch._route_intent(message, ""))
        assert route == "analyze"
        assert orch._should_clarify_before_tools(message, route, "") is False

        plan = orch._generate_fallback_plan(message)
        tool_names = [step.tool_name for step in plan]
        assert "sequence_search" in tool_names
        search_step = next(step for step in plan if step.tool_name == "sequence_search")
        assert search_step.params["query"] == expected_query
        assert search_step.params["database"] == expected_database

    def test_json_style_uploaded_structure_context_enters_structure_tool_plan(self):
        orch = self._get_orchestrator()
        message = "蛋白：天冬氨酸蛋白酶 结构已上传 目标：分析热稳定性和pH稳定性"
        history = [
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "attachments": [
                            {
                                "name": "rare_structure.pdb",
                                "object_name": "uploads/user_9/rare_structure.pdb",
                                "download_url": "/api/files/uploads/user_9/rare_structure.pdb/download",
                            }
                        ]
                    },
                    ensure_ascii=False,
                ),
            }
        ]
        context = orch._build_context(history)

        assert "uploads/user_9/rare_structure.pdb" in context
        route = asyncio.run(orch._route_intent(message, context))
        assert route == "analyze"
        assert orch._should_clarify_before_tools(message, route, context) is False

        plan = orch._generate_fallback_plan(message, context=context)
        tool_names = [step.tool_name for step in plan]
        assert "structure_search_foldseek" in tool_names
        structure_step = next(step for step in plan if step.tool_name == "structure_search_foldseek")
        assert structure_step.params["pdb_object_name"] == "uploads/user_9/rare_structure.pdb"

    @pytest.mark.parametrize(
        "message",
        [
            "结构已上传，帮我提高耐热性",
            "底物酪蛋白，40度，表达体系毕赤酵母，提高耐热性",
        ],
    )
    def test_vague_inputs_without_real_target_or_attachment_still_clarify(self, message):
        orch = self._get_orchestrator()

        route = asyncio.run(orch._route_intent(message, ""))
        assert route == "analyze"
        assert orch._should_clarify_before_tools(message, route, "") is True
        plan = orch._generate_fallback_plan(message)
        assert [step.tool_name for step in plan] == []

    def test_uploaded_pdb_md_request_submits_real_background_md(self):
        orch = self._get_orchestrator()
        message = (
            "对上传PDB做分子动力学分析，看看RMSD/RMSF和热稳定性。\n\n"
            "[Attached files:\n"
            "- name: test.pdb, object_name: uploads/user_1/test.pdb, download_url: /api/files/uploads/user_1/test.pdb/download]"
        )

        plan = orch._generate_fallback_plan(message)
        md_step = next(step for step in plan if step.tool_name == "gromacs_md")

        assert md_step.params["pdb_object_name"] == "uploads/user_1/test.pdb"
        assert md_step.params["replicate_plan_only"] is False
        assert md_step.params["upload_artifacts"] is True

    def test_deep_analysis_depth_allows_slow_md_without_fixed_report(self):
        orch = self._get_orchestrator()
        message = (
            "分析这个结构的热稳定性和pH稳定性。\n\n"
            "[Attached files:\n"
            "- name: rare.pdb, object_name: uploads/user_1/rare.pdb]"
        )

        standard_plan = orch._generate_fallback_plan(message, analysis_depth="standard")
        deep_plan = orch._generate_fallback_plan(message, analysis_depth="deep")

        assert "gromacs_md" not in [step.tool_name for step in standard_plan]
        md_step = next(step for step in deep_plan if step.tool_name == "gromacs_md")
        assert md_step.params["pdb_object_name"] == "uploads/user_1/rare.pdb"
        assert md_step.params["simulation_time_ns"] == 10.0
        assert md_step.params["replicate_plan_only"] is False

    def test_objective_routing_changes_tool_plan_for_same_sequence(self):
        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        cases = {
            "thermo": f"提高这个酶的热稳定性 {sequence}",
            "activity": f"提高这个酶的比活力和催化效率 {sequence}",
            "specificity": f"提高这个酶的底物特异性 {sequence}",
            "solubility": f"提高这个酶在毕赤酵母中的可溶性表达 {sequence}",
        }

        plans = {
            key: [step.tool_name for step in orch._generate_fallback_plan(message)]
            for key, message in cases.items()
        }

        for plan in plans.values():
            assert plan[:6] == [
                "predict_properties",
                "annotation_bundle",
                "enzyme_identity_profile",
                "enzyme_objective_module_plan",
                "protein_benchmark",
                "enzyme_function",
            ]

        assert plans["thermo"] == [
            "predict_properties",
            "annotation_bundle",
            "enzyme_identity_profile",
            "enzyme_objective_module_plan",
            "protein_benchmark",
            "enzyme_function",
            "esmfold_folding",
            "mutation_priority_score",
        ]
        assert "kcat_predict" in plans["activity"]
        assert "mutation_scan" in plans["activity"]
        assert "protein_benchmark" in plans["specificity"]
        assert "enzyme_objective_module_plan" in plans["specificity"]
        assert "mutation_priority_score" in plans["specificity"]
        assert "mutation_scan" in plans["specificity"]
        assert "kcat_predict" not in plans["specificity"]
        assert "soluble_mpnn_design" in plans["solubility"]
        assert "protein_benchmark" in plans["solubility"]
        assert "enzyme_function" in plans["solubility"]
        assert "mutation_priority_score" not in plans["solubility"]
        assert len({tuple(plan) for plan in plans.values()}) == 4

    def test_uploaded_sequence_deep_md_request_submits_one_background_md_step(self):
        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        message = (
            f"对上传PDB做深度分子动力学分析，评估热稳定性。{sequence}\n\n"
            "[Attached files:\n"
            "- name: test.pdb, object_name: uploads/user_1/test.pdb]"
        )

        plan = orch._generate_fallback_plan(message, analysis_depth="deep")

        assert [step.tool_name for step in plan].count("gromacs_md") == 1

    def test_negative_tool_constraints_filter_planned_tools(self):
        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"
        message = (
            "提高这个酶的底物特异性，但禁止 ESMFold、BLAST、家族预测和突变打分。"
            f"{sequence}"
        )

        plan = orch._generate_fallback_plan(message, analysis_depth="deep")
        tool_names = [step.tool_name for step in plan]

        assert "esmfold_folding" not in tool_names
        assert "blast_search" not in tool_names
        assert "protein_benchmark" not in tool_names
        assert "enzyme_function" not in tool_names
        assert "mutation_priority_score" not in tool_names
        assert "mutation_scan" not in tool_names
        assert "predict_properties" in tool_names

    def test_extract_only_request_does_not_plan_tools(self):
        orch = self._get_orchestrator()
        sequence = "mktvrqerlksivrilerskepvqgaqlpvkelqlpgchpnpiralldssegdlsfdadstiirrmee"
        message = f"只抽取序列，不分析，不要调用工具。序列：{sequence}"

        assert orch._generate_fallback_plan(message, analysis_depth="deep") == []
        reply = orch._build_extraction_only_reply(message)

        assert "未调用任何分析工具" in reply
        assert "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE" in reply

    def test_stream_extract_only_short_circuits_before_routing_or_tools(self, monkeypatch):
        from app.tools.registry import ToolRegistry

        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"

        async def fail_route(*args, **kwargs):
            raise AssertionError("extract-only requests must not route")

        async def fail_execute(*args, **kwargs):
            raise AssertionError("extract-only requests must not execute tools")

        monkeypatch.setattr(orch, "_route_intent", fail_route)
        monkeypatch.setattr(ToolRegistry, "execute", fail_execute)

        async def collect():
            text = []
            states = []
            async for event in orch.stream_chat(f"只抽取，不分析，不要调用工具。序列：{sequence}", []):
                payload = json.loads(event)
                if payload.get("type") == "text":
                    text.append(payload.get("content", ""))
                elif payload.get("type") == "state":
                    states.append(payload)
            return "".join(text), states

        reply, states = asyncio.run(collect())

        assert "未调用任何分析工具" in reply
        assert all(not state.get("plan") for state in states)

    def test_sequence_extraction_ignores_lowercase_objective_words(self):
        from app.core.agent_graph import AgentOrchestrator

        assert AgentOrchestrator._extract_sequence("improve substrate specificity only") is None
        assert AgentOrchestrator._extract_sequence("序列：mktvrqerlksivrilersk") == "MKTVRQERLKSIVRILERSK"

    def test_gromacs_step_is_prepared_for_interactive_async_submission(self):
        from app.core.agent_graph import PlanStep

        orch = self._get_orchestrator()
        step = PlanStep(
            id=1,
            tool_name="gromacs_md",
            description="Run full MD",
            params={"pdb_object_name": "uploads/user_1/test.pdb"},
        )

        safe = orch._normalize_interactive_async_params(step)

        assert safe.params["replicate_plan_only"] is False
        assert safe.params["upload_artifacts"] is True
        assert "background task runner" in safe.description

    def test_stream_plan_confirmation_stops_before_tool_execution(self, monkeypatch):
        from app.core.agent_graph import PlanStep
        from app.tools.registry import ToolRegistry

        orch = self._get_orchestrator()
        sequence = "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"

        async def fake_route(*args, **kwargs):
            return "analyze"

        async def fake_plan(*args, **kwargs):
            return [
                PlanStep(
                    id=1,
                    tool_name="predict_properties",
                    description="Compute objective-relevant physicochemical sequence features",
                    params={"sequence": sequence},
                ),
                PlanStep(
                    id=2,
                    tool_name="mutation_priority_score",
                    description="Score residues for thermostability engineering",
                    params={"sequence": sequence, "engineering_goal": "thermostability"},
                ),
            ]

        async def fail_execute(*args, **kwargs):
            raise AssertionError("plan-only mode must not execute tools")

        monkeypatch.setattr(orch, "_route_intent", fake_route)
        monkeypatch.setattr(orch, "_plan_cb", fake_plan)
        monkeypatch.setattr(ToolRegistry, "execute", fail_execute)

        async def collect():
            text = []
            states = []
            async for event in orch.stream_chat(f"提高这个酶的热稳定性 {sequence}", []):
                payload = json.loads(event)
                if payload.get("type") == "text":
                    text.append(payload.get("content", ""))
                elif payload.get("type") == "state":
                    states.append(payload)
            return "".join(text), states

        reply, states = asyncio.run(collect())

        assert "分析策略确认" in reply
        assert "改造策略（先确认方向，再执行分析）" in reply
        assert "热稳定性" in reply
        assert "当前还没有执行任何分析工具" in reply
        assert "`predict_properties`" in reply
        assert "`mutation_priority_score`" in reply
        assert any(state.get("waiting_for") == "plan_confirmation" for state in states)
        assert not any(state.get("step_results") for state in states)

    def test_stream_md_request_enqueues_background_task_not_inline_gromacs(self, monkeypatch):
        from app.core.agent_graph import PlanStep
        from app.tools.registry import ToolRegistry

        orch = self._get_orchestrator()
        dispatched = {}

        async def fake_route(*args, **kwargs):
            return "analyze"

        async def fake_plan(*args, **kwargs):
            return [
                PlanStep(
                    id=1,
                    tool_name="gromacs_md",
                    description="Run real MD",
                    params={"pdb_object_name": "uploads/user_1/test.pdb", "replicate_plan_only": True},
                )
            ]

        async def fake_synthesize(task, tool_messages, *args, **kwargs):
            return json.dumps(tool_messages, ensure_ascii=False)

        async def fail_execute(tool_name, params, **kwargs):
            if tool_name == "gromacs_md":
                raise AssertionError("chat stream must not run GROMACS inline")
            return {}

        def fake_dispatch(tool_name, params):
            dispatched["tool_name"] = tool_name
            dispatched["params"] = params
            return "chat-md-task-id"

        class FakeProfile:
            queue = "md_cpu"
            soft_time_limit = 3600
            time_limit = 5400

        async def noop(*args, **kwargs):
            return None

        monkeypatch.setattr(orch, "_route_intent", fake_route)
        monkeypatch.setattr(orch, "_plan_cb", fake_plan)
        monkeypatch.setattr(orch, "_synthesize_sc", fake_synthesize)
        monkeypatch.setattr(ToolRegistry, "execute", fail_execute)
        monkeypatch.setattr("app.services.scheduler.dispatch_tool", fake_dispatch)
        monkeypatch.setattr("app.services.scheduler.get_task_profile", lambda tool_name: FakeProfile())
        monkeypatch.setattr("app.services.tool_task_store.record_tool_task_owner", noop)
        monkeypatch.setattr("app.services.tool_task_store.record_tool_task_runtime_policy", noop)

        async def collect_text():
            chunks = []
            async for event in orch.stream_chat(
                "对上传PDB做分子动力学分析",
                [],
                agent_control="execute_confirmed",
                current_user={"id": 7},
            ):
                try:
                    payload = json.loads(event)
                except json.JSONDecodeError:
                    continue
                if payload.get("type") == "text":
                    chunks.append(str(payload.get("content") or ""))
            return "".join(chunks)

        reply = asyncio.run(collect_text())

        assert dispatched["tool_name"] == "gromacs_md"
        assert dispatched["params"]["replicate_plan_only"] is False
        assert dispatched["params"]["upload_artifacts"] is True
        assert "chat-md-task-id" in reply
        assert '"status": "submitted"' in reply

    def test_stream_blocks_structure_dependent_tools_when_uploaded_structure_gate_fails(self, monkeypatch):
        from app.core.agent_graph import PlanStep
        from app.tools.registry import ToolRegistry

        orch = self._get_orchestrator()
        executed = []

        async def fake_route(*args, **kwargs):
            return "analyze"

        async def fake_plan(*args, **kwargs):
            return [
                PlanStep(
                    id=1,
                    tool_name="structure_search_foldseek",
                    description="Parse structure",
                    params={"pdb_object_name": "uploads/user_1/bad.pdb"},
                ),
                PlanStep(
                    id=2,
                    tool_name="gromacs_md",
                    description="Run MD",
                    params={"pdb_object_name": "uploads/user_1/bad.pdb"},
                ),
                PlanStep(
                    id=3,
                    tool_name="predict_properties",
                    description="Sequence-level properties",
                    params={"sequence": "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLDSSEGDLSFDADSTIIRRMEE"},
                ),
            ]

        async def fake_synthesize(task, tool_messages, *args, **kwargs):
            return json.dumps(tool_messages, ensure_ascii=False)

        async def fake_execute(tool_name, params, **kwargs):
            executed.append(tool_name)
            if tool_name == "structure_search_foldseek":
                return {"status": "failed", "found": False, "error": "NO_RESIDUES"}
            if tool_name == "predict_properties":
                return {"status": "completed", "length": len(params["sequence"])}
            raise AssertionError(f"{tool_name} should not execute")

        def fail_dispatch(*args, **kwargs):
            raise AssertionError("gromacs_md must not be submitted when structure gate fails")

        monkeypatch.setattr(orch, "_route_intent", fake_route)
        monkeypatch.setattr(orch, "_plan_cb", fake_plan)
        monkeypatch.setattr(orch, "_synthesize_sc", fake_synthesize)
        monkeypatch.setattr(ToolRegistry, "execute", fake_execute)
        monkeypatch.setattr("app.services.scheduler.dispatch_tool", fail_dispatch)

        async def collect_text():
            chunks = []
            async for event in orch.stream_chat(
                "上传结构有问题时不要继续跑MD",
                [],
                agent_control="execute_confirmed",
                current_user={"id": 7},
            ):
                try:
                    payload = json.loads(event)
                except json.JSONDecodeError:
                    continue
                if payload.get("type") == "text":
                    chunks.append(str(payload.get("content") or ""))
            return "".join(chunks)

        reply = asyncio.run(collect_text())

        assert executed == ["structure_search_foldseek", "predict_properties"]
        assert '"tool_name": "gromacs_md"' in reply
        assert '"status": "failed"' in reply
        assert "structure gate did not pass" in reply

    def test_plan_only_md_synthesis_skips_llm(self, monkeypatch):
        orch = self._get_orchestrator()

        async def fail_call_llm(*args, **kwargs):
            raise AssertionError("plan-only MD should not call LLM synthesis")

        monkeypatch.setattr(orch, "_call_llm", fail_call_llm)
        tool_results = [{
            "role": "tool",
            "tool_name": "gromacs_md",
            "status": "completed",
            "result": json.dumps({
                "status": "planned",
                "is_real_md": False,
                "note": "Replicate plan only; no GROMACS command was executed.",
                "replicate_execution_plan": {
                    "tasks": [{
                        "task_id": "WT:rep1",
                        "variant": "WT",
                        "replicate_index": 1,
                        "simulation_time_ns": 10.0,
                        "force_field": "amber99sb-ildn",
                        "water_model": "tip3p",
                    }],
                },
            }),
        }]

        report = asyncio.run(orch._synthesize_sc(
            "对上传PDB做分子动力学分析",
            tool_results,
            "",
            [],
            "gpt55",
        ))

        assert "Molecular Dynamics Execution Plan" in report
        assert "Replicate plan only" in report
        assert "WT:rep1" in report

    def test_uploaded_structure_without_foldseek_hits_continues_through_llm_synthesis(self, monkeypatch):
        orch = self._get_orchestrator()
        captured = {}

        async def fake_call_llm(messages, **kwargs):
            captured["messages"] = messages

            class _Message:
                content = "模型基于上传结构摘要继续分析，未因同源结构 0 命中而停止。"

            class _Choice:
                message = _Message()

            class _Response:
                choices = [_Choice()]

            return _Response()

        monkeypatch.setattr(orch, "_call_llm", fake_call_llm)
        tool_results = [{
            "role": "tool",
            "tool_name": "structure_search_foldseek",
            "status": "completed",
            "result": json.dumps({
                "found": False,
                "status": "completed",
                "backend": "local_cli",
                "database": "pdb",
                "results_count": 0,
                "results": [],
                "query_structure": {
                    "chain_count": 2,
                    "total_residues": 3,
                    "total_atoms": 6,
                    "chains": [
                        {"chain_id": "A", "residue_count": 2, "residue_range": "5-6"},
                        {"chain_id": "B", "residue_count": 1, "residue_range": "10-10"},
                    ],
                },
            }),
        }]

        report = asyncio.run(orch._synthesize_sc(
            "这个酶的PDB文件，分析热稳定性和pH稳定性",
            tool_results,
            "",
            [],
            "gpt55",
        ))

        user_prompt = captured["messages"][-1]["content"]
        assert "模型基于上传结构摘要继续分析" in report
        assert "Foldseek returned zero homolog/template hits" in user_prompt
        assert '"results_count": 0' in user_prompt
        assert '"chain_id": "A"' in user_prompt
        assert '"residue_range": "5-6"' in user_prompt

    def test_claim_audit_constraints_are_injected_into_llm_synthesis(self, monkeypatch):
        orch = self._get_orchestrator()
        captured = {}

        async def fake_call_llm(messages, **kwargs):
            captured["user_prompt"] = messages[-1]["content"]

            class _Message:
                content = "已按 Claim audit 输出：突变主表可用于实验规划，kcat 为 proxy。"

            class _Choice:
                message = _Message()

            class _Response:
                choices = [_Choice()]

            return _Response()

        monkeypatch.setattr(orch, "_call_llm", fake_call_llm)
        tool_results = [
            {
                "role": "tool",
                "tool_name": "mutation_priority_score",
                "status": "completed",
                "result": json.dumps({
                    "identity_gate": {"status": "passed"},
                    "candidate_table_status": "exploratory_requires_objective_evidence",
                    "experiment_design_table": [
                        {
                            "experiment_priority": "P1",
                            "position": 42,
                            "wild_type": "G",
                            "recommended_mutations": ["G42P"],
                            "mutation_logic": "loop rigidification",
                        }
                    ],
                    "objective_gate": {
                        "status": "blocked",
                        "missing_evidence": ["baseline Tm"],
                    },
                }),
            },
            {
                "role": "tool",
                "tool_name": "kcat_predict",
                "status": "completed",
                "result": json.dumps({
                    "is_real_inference": False,
                    "capability_status": "proxy",
                    "report_boundary": "Use only for exploratory triage.",
                }),
            },
        ]

        report = asyncio.run(orch._synthesize_sc(
            "提高这个酶的热稳定性",
            tool_results,
            "",
            [],
            "gpt55",
        ))

        assert "突变主表可用于实验规划" in report
        assert "Claim audit constraints" in captured["user_prompt"]
        assert "MUTATION_SITE_TABLE" in captured["user_prompt"]
        assert "KCAT_PREDICT_REAL_RUNTIME=RUNTIME_UNVERIFIED" in captured["user_prompt"]
        assert "MUTATION_EFFECT_VALIDATED=MISSING" in captured["user_prompt"]


class TestBinderSkillsAndReport:
    """T11: Skill loading and fallback report for design tasks."""

    def test_load_relevant_skills_design(self):
        """_load_relevant_skills should attempt to load protein_design for binder tasks."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        # This should not crash even if the skill file doesn't exist
        result = orch._load_relevant_skills("Design a binder for PD-L1")
        # Result may be empty if protein_design skill doesn't exist yet — that's OK
        assert isinstance(result, str)

    def test_build_fallback_report_with_design_data(self):
        """_build_fallback_report should include design section when design tools ran."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        tool_results = [
            {
                "tool_name": "proteinmpnn_design",
                "status": "completed",
                "result": {
                    "target_length": 100,
                    "best_recovery_rate": 0.42,
                    "best_confidence": 0.78,
                    "num_sequences_generated": 3,
                    "designs": [
                        {
                            "rank": 1,
                            "sequence": "MKTVRQERLKSIVRILERSKEPVQGAQLPVKELQLPGCHPNPIRALLD",
                            "recovery_rate": 0.42,
                            "mean_confidence": 0.78,
                            "num_mutations": 58,
                        },
                    ],
                },
            },
            {
                "tool_name": "esmfold_folding",
                "status": "completed",
                "result": {"plddt": 82.5, "sequence": "MKTVRQERLKSI..."},
            },
        ]

        report = orch._build_fallback_report("Design a binder for PD-L1", tool_results)

        assert "Protein Design Results" in report, (
            "Report should contain 'Protein Design Results' section"
        )
        assert "ProteinMPNN" in report, "Report should mention ProteinMPNN"
        assert "0.42" in report, "Report should show recovery rate"
        assert "0.78" in report, "Report should show confidence"

    def test_build_fallback_report_no_design_data(self):
        """Report without design tools should not have design section."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        tool_results = [
            {
                "tool_name": "predict_properties",
                "status": "completed",
                "result": {"molecular_weight_kda": 45.2, "isoelectric_point": 6.8},
            },
        ]

        report = orch._build_fallback_report("分析这个酶的性质", tool_results)
        assert "Protein Design Results" not in report, (
            "Non-design report should not have design section"
        )
        assert "Physicochemical Properties" in report
        assert "Evidence Layer" in report

    def test_fallback_report_surfaces_claim_audit_gate(self):
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        tool_results = [
            {
                "tool_name": "kcat_predict",
                "status": "completed",
                "result": {
                    "predicted_kcat_s1": 12.3,
                    "predicted_log10_kcat": 1.09,
                    "enzyme_class": "hydrolase",
                    "confidence_interval_kcat_s1": [1.0, 100.0],
                    "efficiency_assessment": "proxy",
                    "method": "heuristic",
                    "is_real_inference": False,
                    "capability_status": "proxy",
                },
            }
        ]

        report = orch._build_fallback_report("预测kcat", tool_results)

        assert "Claim Audit Gate" in report
        assert "KCAT_PREDICT_REAL_RUNTIME" in report
        assert "RUNTIME_UNVERIFIED" in report

    def test_claim_audit_tracks_live_evidence_source_status(self):
        from app.core.agent_graph import AgentOrchestrator

        tool_results = [
            {
                "tool_name": "annotation_bundle",
                "status": "completed",
                "result": {
                    "found": True,
                    "evidence_source": {
                        "source": "annotation_bundle",
                        "status": "degraded",
                        "mode": "local_database_or_heuristic_bundle",
                        "live_query_executed": False,
                        "reason": "No live UniProt/InterPro query executed.",
                    },
                },
            },
            {
                "tool_name": "blast_search",
                "status": "completed",
                "result": {
                    "status": "completed",
                    "results_count": 1,
                    "evidence_source": {
                        "source": "NCBI BLAST",
                        "status": "live",
                        "mode": "ncbi_blast_rest",
                        "live_query_executed": True,
                    },
                },
            },
            {
                "tool_name": "sequence_search",
                "status": "completed",
                "result": {
                    "status": "completed",
                    "results_count": 1,
                    "evidence_source": {
                        "source": "UniProt REST",
                        "status": "degraded",
                        "mode": "cache_hit",
                        "live_query_executed": False,
                    },
                },
            },
            {
                "tool_name": "interpro_live_lookup",
                "status": "completed",
                "result": {
                    "status": "completed",
                    "evidence_source": {
                        "source": "InterPro API",
                        "status": "live",
                        "mode": "interpro_api",
                        "live_query_executed": True,
                    },
                },
            },
            {
                "tool_name": "literature_live_search",
                "status": "completed",
                "result": {
                    "status": "degraded",
                    "evidence_source": {
                        "source": "PubMed/Crossref",
                        "status": "degraded",
                        "mode": "live_query_failed",
                        "live_query_executed": False,
                    },
                },
            },
            {
                "tool_name": "interproscan_sequence_submit",
                "status": "submitted",
                "result": {
                    "status": "submitted",
                    "job_id": "iprscan-test-job",
                    "evidence_source": {
                        "source": "InterProScan",
                        "status": "live",
                        "mode": "interproscan_rest_submit",
                        "live_query_executed": True,
                    },
                },
            },
            {
                "tool_name": "interproscan_sequence_status",
                "status": "completed",
                "result": {
                    "status": "pending",
                    "job_id": "iprscan-test-job",
                    "ebi_status": "RUNNING",
                    "result_available": False,
                    "results": [],
                    "results_count": 0,
                    "evidence_source": {
                        "source": "InterProScan",
                        "status": "live",
                        "mode": "interproscan_rest_status",
                        "live_query_executed": True,
                    },
                },
            },
            {
                "tool_name": "interproscan_sequence_status",
                "status": "completed",
                "result": {
                    "status": "completed",
                    "job_id": "iprscan-test-job",
                    "ebi_status": "FINISHED",
                    "result_available": True,
                    "results_count": 1,
                    "results": [
                        {
                            "interpro_accession": "IPR001461",
                            "name": "Peptidase A1",
                            "start": 1,
                            "end": 388,
                        }
                    ],
                    "evidence_source": {
                        "source": "InterProScan",
                        "status": "live",
                        "mode": "interproscan_rest_result",
                        "live_query_executed": True,
                    },
                },
            },
        ]

        audit = AgentOrchestrator._build_claim_audit(tool_results)
        claims_by_id = {}
        for claim in audit["claims"]:
            claims_by_id.setdefault(claim["claim_id"], []).append(claim)
        claims = {claim_id: items[-1] for claim_id, items in claims_by_id.items()}
        context = AgentOrchestrator._claim_audit_synthesis_context(tool_results)

        assert claims["ANNOTATION_BUNDLE_LIVE_QUERY"]["status"] == "RUNTIME_UNVERIFIED"
        assert claims["BLAST_LIVE_QUERY"]["status"] == "SUPPORTED"
        assert claims["SEQUENCE_SEARCH_LIVE_QUERY"]["status"] == "RUNTIME_UNVERIFIED"
        assert claims["INTERPRO_LIVE_QUERY"]["status"] == "SUPPORTED"
        assert claims["LITERATURE_LIVE_QUERY"]["status"] == "RUNTIME_UNVERIFIED"
        assert claims["INTERPROSCAN_SEQUENCE_SUBMITTED"]["status"] == "SUPPORTED"
        assert [claim["status"] for claim in claims_by_id["INTERPROSCAN_SEQUENCE_RESULT"]] == [
            "RUNTIME_UNVERIFIED",
            "SUPPORTED",
        ]
        assert "ANNOTATION_BUNDLE_LIVE_QUERY=RUNTIME_UNVERIFIED" in context
        assert "BLAST_LIVE_QUERY" in context
        assert "SEQUENCE_SEARCH_LIVE_QUERY=RUNTIME_UNVERIFIED" in context
        assert "INTERPRO_LIVE_QUERY" in context
        assert "LITERATURE_LIVE_QUERY=RUNTIME_UNVERIFIED" in context
        assert "INTERPROSCAN_SEQUENCE_SUBMITTED" in context
        assert "INTERPROSCAN_SEQUENCE_RESULT=RUNTIME_UNVERIFIED" in context
        assert "INTERPROSCAN_SEQUENCE_RESULT" in context

    def test_chat_keeps_blast_and_alphafold2_inline(self):
        """BLAST and AlphaFold2 should finish/degrade inline instead of staying submitted in chat."""
        from app.core.agent_graph import AgentOrchestrator, PlanStep

        orch = AgentOrchestrator()

        assert orch._should_submit_interactive_async_step(
            PlanStep(1, "blast_search", "BLAST", {"sequence": "ACDEFGHIKL"})
        ) is False
        assert orch._should_submit_interactive_async_step(
            PlanStep(2, "alphafold2_folding", "AlphaFold2", {"sequence": "ACDEFGHIKL"})
        ) is False
        assert orch._should_submit_interactive_async_step(
            PlanStep(3, "gromacs_md", "MD", {"pdb_object_name": "uploads/user_1/a.pdb"})
        ) is True

    def test_build_fallback_report_with_mutation_strategy(self):
        """Mutation fallback report should prioritize first-screen experiment decisions."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()

        tool_results = [
            {
                "tool_name": "mutation_priority_score",
                "status": "completed",
                "result": {
                    "engineering_goal": "thermostability",
                    "strategy": {
                        "objective": "提高热稳定性，同时尽量保持催化活性、表达和可溶性。",
                        "design_principle": "优先加固非催化、可突变的柔性环和局部疏松区域。",
                        "screening_logic": ["排除催化位点", "优先表面暴露残基"],
                    },
                    "summary": {"tier_1_count": 1, "tier_2_count": 0, "never_mutate_positions": [10]},
                    "tier_1_candidates": [
                        {
                            "position": 42,
                            "user_position": 42,
                            "pdb_position": None,
                            "uniprot_position": None,
                            "numbering_status": "user_sequence_only",
                            "wild_type": "G",
                            "composite_priority": 8.2,
                            "logic": "位于蛋白表面，高度溶剂可及；与活性中心距离适中",
                            "expected_effect": "候选增稳方向，需实验确认",
                            "risk_flags": ["Gly→Pro可能误伤必要柔性"],
                            "experiment_action": "构建单点突变体；与 WT 同批表达纯化；测 Tm/热处理残余活性；同步复测比活、可溶性和聚集风险。",
                            "experiment_priority": "P1",
                            "candidate_evidence_status": "计算候选，待实验验证",
                            "recommended_mutations": [{"mutation": "G42P", "purpose": "test"}],
                        }
                    ],
                    "tier_2_candidates": [],
                },
            }
        ]

        report = orch._build_fallback_report("提高这个酶的热稳定性", tool_results)

        assert "## 结论卡片 / 状态摘要" in report
        assert "当前决策**：Go" in report
        assert "提高热稳定性" in report
        assert "## 突变位点主表（实验排单）" in report
        assert "用户编号" in report
        assert "PDB编号" in report
        assert "UniProt编号" in report
        assert "未映射" in report
        assert "## 推荐突变与实验批次" in report
        assert "## 位点突变逻辑 / 风险 / 实验动作" in report
        assert "## Go / Watch / No-Go" in report
        assert "## 改造策略说明" in report
        assert "G42P" in report
        assert "Gly→Pro可能误伤必要柔性" in report
        assert "突变逻辑" in report
        assert "风险提示" in report
        assert "实验动作" in report
        assert "构建单点突变体" in report
        assert "P1" in report
        assert "不得写成已证实增稳或提活" in report

        main_table_index = report.index("## 突变位点主表（实验排单）")
        evidence_index = report.index("## Evidence Layer")
        strategy_index = report.index("## 改造策略说明")
        assert main_table_index < evidence_index
        assert main_table_index < strategy_index

    def test_empty_sequence_search_result_builds_no_evidence_reply(self):
        """P0/P1: empty search evidence must not be hidden by a full report."""
        from app.core.agent_graph import AgentOrchestrator
        orch = AgentOrchestrator()
        tool_results = [
            {
                "tool_name": "sequence_search",
                "status": "completed",
                "result": '{"query":"能力边界 文献依据","database":"uniprot","results_count":0,"results":[],"status":"completed"}',
            }
        ]

        assert orch._tool_results_have_no_evidence(tool_results) is True
        reply = orch._build_no_evidence_reply("这个模型有没有文献依据？", tool_results)
        assert "不能给出确定性改造建议" in reply
        assert "results=0" in reply


class TestSanitizeMessages:
    """Test _sanitize_messages for Dashscope/Qwen API compatibility.

    Dashscope requires 'content' to be a string — tool_calls, None, list,
    and dict content types all cause 'Unexpected item type in content' errors.
    """

    def setup_method(self):
        from app.core.agent_graph import AgentOrchestrator
        self.orch = AgentOrchestrator()

    def test_none_content_becomes_empty_string(self):
        messages = [
            {"role": "assistant", "content": None, "tool_calls": [{"id": "tc_1"}]},
            {"role": "user", "content": "hello"},
        ]
        result = self.orch._sanitize_messages(messages)
        # Assistant with None content → dropped (pure tool_calls message)
        assert len(result) == 1
        assert result[0]["content"] == "hello"

    def test_list_content_extracted_to_string(self):
        messages = [
            {"role": "user", "content": [
                {"type": "text", "text": "Describe this protein"},
                {"type": "image_url", "image_url": {"url": "data:image/png;base64,..."}},
            ]},
        ]
        result = self.orch._sanitize_messages(messages)
        assert len(result) == 1
        assert isinstance(result[0]["content"], str)
        assert "Describe this protein" in result[0]["content"]

    def test_dict_content_coerced_to_string(self):
        messages = [
            {"role": "user", "content": {"query": "protein analysis"}},
        ]
        result = self.orch._sanitize_messages(messages)
        assert isinstance(result[0]["content"], str)

    def test_normal_messages_unchanged(self):
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Analyze this sequence: MVLSPAD"},
            {"role": "assistant", "content": "Here is the analysis."},
        ]
        result = self.orch._sanitize_messages(messages)
        assert len(result) == 3
        assert result[0]["content"] == "You are a helpful assistant."
        assert result[2]["content"] == "Here is the analysis."

    def test_tool_message_preserves_tool_call_id(self):
        messages = [
            {"role": "tool", "content": "result data", "tool_call_id": "call_abc123"},
        ]
        result = self.orch._sanitize_messages(messages)
        assert result[0]["tool_call_id"] == "call_abc123"
        assert result[0]["content"] == "result data"

    def test_empty_assistant_dropped(self):
        messages = [
            {"role": "system", "content": "System prompt"},
            {"role": "assistant", "content": "   "},  # whitespace only
            {"role": "user", "content": "Next question"},
        ]
        result = self.orch._sanitize_messages(messages)
        assert len(result) == 2
        assert all(r["role"] != "assistant" for r in result)

    def test_no_tool_calls_field_in_output(self):
        """tool_calls field should never leak into sanitized messages."""
        messages = [
            {"role": "assistant", "content": "I'll use a tool", "tool_calls": []},
        ]
        result = self.orch._sanitize_messages(messages)
        for msg in result:
            assert "tool_calls" not in msg


class TestChatMarkdownStreaming:
    """Regression coverage for long Markdown/checklist replies."""

    def setup_method(self):
        from app.core.agent_graph import AgentOrchestrator
        self.orch = AgentOrchestrator()

    def test_stream_chunks_preserve_markdown_whitespace(self):
        text = "标题\n\n- A\n- B\n\n| 列 | 值 |\n|---|---|\n| M1 | 通过 |"
        chunks = list(self.orch._iter_text_stream_chunks(text, chunk_size=8))

        assert "".join(chunks) == text
        assert "\n\n- A" in "".join(chunks)
        assert "|---|---|" in "".join(chunks)

    def test_document_reply_request_detects_execution_checklist(self):
        assert self.orch._is_document_reply_request("整理成实验执行清单和数据记录表格")
        assert self.orch._is_document_reply_request("Create an SOP template")
        assert not self.orch._is_document_reply_request("hello")

    @pytest.mark.asyncio
    async def test_document_reply_uses_larger_token_budget(self, monkeypatch):
        calls = {}

        class _Message:
            content = "## 实验执行清单\n\n- step 1"

        class _Choice:
            message = _Message()

        class _Response:
            choices = [_Choice()]

        async def fake_call_llm(messages, model_id=None, **kwargs):
            calls["messages"] = messages
            calls["max_tokens"] = kwargs.get("max_tokens")
            return _Response()

        monkeypatch.setattr(self.orch, "_call_llm", fake_call_llm)

        reply = await self.orch._chat_reply("请整理成给学生直接执行的 SOP 版清单", [])

        assert reply.startswith("## 实验执行清单")
        assert calls["max_tokens"] == 2200
        assert "Do not shorten" in calls["messages"][0]["content"]
        assert "Manual enzyme analysis flow v1" in calls["messages"][0]["content"]
        assert "input normalization" in calls["messages"][0]["content"]
        assert "minimal enzyme profile" in calls["messages"][0]["content"]
        assert "activity-stability" in calls["messages"][0]["content"]

    def test_sc_prompt_contains_manual_enzyme_analysis_protocol(self):
        from app.core.agent_roles import SC_SYSTEM_PROMPT

        assert "Manual enzyme analysis flow v1" in SC_SYSTEM_PROMPT
        assert "structure acquisition/status" in SC_SYSTEM_PROMPT
        assert "minimal enzyme profile" in SC_SYSTEM_PROMPT
        assert "prediction conflicts with wet-lab feedback" in SC_SYSTEM_PROMPT
        assert "activity-stability" in SC_SYSTEM_PROMPT
        assert "Go/No-Go" in SC_SYSTEM_PROMPT
        assert "residue" in SC_SYSTEM_PROMPT
        assert "numbering alignment" in SC_SYSTEM_PROMPT
        assert "epistasis risk" in SC_SYSTEM_PROMPT
        assert "success probability" in SC_SYSTEM_PROMPT
