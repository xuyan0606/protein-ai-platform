"""Plan-Execute-Synthesize Agent Graph with checkpoint-based pause/resume.

Inspired by VenusFactory2's multi-role agent pattern:
  PI (Principal Investigator) → CB (Computational Biologist)
  → MLS (Machine Learning Specialist) → SC (Scientific Critic)
"""

from dataclasses import dataclass, field
from typing import TypedDict, Annotated, Any, AsyncGenerator
import asyncio
import functools
import hashlib
import json
import logging
import re
import time

logger = logging.getLogger(__name__)

from app.core.llm_gateway import llm_gateway
from app.core.config import settings
from app.tools.registry import ToolRegistry
from app.tools.scientific_claim_gate import scientific_claim_gate
from app.core.skills import get_skills_metadata, read_skill
from app.core.agent_roles import (
    PI_SYSTEM_PROMPT, CB_SYSTEM_PROMPT,
    MLS_SYSTEM_PROMPT, SC_SYSTEM_PROMPT,
    ROUTER_SYSTEM_PROMPT,
    ENZYME_ENGINEERING_REPORT_PROTOCOL,
)
from app.core.coordinator_agent import CoordinatorAgent

# Lazy import for experience store (avoids circular import at module load)
def _get_experience_store():
    from app.memory.experience_store import get_experience_store, ExperienceRecord
    return get_experience_store(), ExperienceRecord

# Tools that require a protein sequence — skip if no sequence available
_SEQUENCE_REQUIRED_TOOLS = frozenset({
    "alphafold_folding", "esmfold_folding", "predict_properties",
    "mutation_scan", "mutation_priority_score", "protein_benchmark",
    "enzyme_identity_profile", "enzyme_function", "kcat_predict", "protssn_score", "blast_search",
    "enzyme_objective_module_plan",
    "rosetta_ddg",
})

# Tools that require a PDB structure — skip if no PDB available
_PDB_REQUIRED_TOOLS = frozenset({
    "proteinmpnn_design",
    "esm_if1_design",
    "gromacs_md",
})

_STRUCTURE_GATE_TOOLS = frozenset({
    "structure_search_foldseek",
    "residue_mapping_sifts",
    "residue_numbering_gate",
})

_STRUCTURE_DEPENDENT_TOOLS = frozenset({
    "gromacs_md",
    "proteinmpnn_design",
    "esm_if1_design",
})

_ENZYME_FOUNDATION_TOOLS = frozenset({
    "annotation_bundle",
    "enzyme_identity_profile",
    "enzyme_objective_module_plan",
    "protein_benchmark",
    "enzyme_function",
    "mutation_priority_score",
})

_IDENTITY_GATED_CANDIDATE_TOOLS = frozenset({
    "mutation_scan",
    "protssn_score",
})

_OBJECTIVE_GATED_CANDIDATE_TOOLS = frozenset({
    "mutation_scan",
    "protssn_score",
})

@dataclass
class PlanStep:
    id: int
    tool_name: str
    description: str
    params: dict = field(default_factory=dict)
    status: str = "pending"  # pending | running | submitted | completed | failed
    result: Any = None
    error: str | None = None
    duration: float = 0.0


@dataclass
class ChatSnapshot:
    """Full state snapshot for SSE streaming (inspired by VenusFactory2)."""
    stage: str  # router | research | plan | execute | synthesize | done
    plan: list[dict] = field(default_factory=list)
    current_step: int = 0
    step_results: list[dict] = field(default_factory=list)
    research_notes: str = ""
    final_report: str = ""
    waiting_for: str | None = None  # plan_confirmation | step_review | clarification
    tokens: str = ""
    error: str | None = None


class AgentOrchestrator:
    """Multi-role agent orchestrator with Plan-Execute-Synthesize pattern."""

    # Tool result cache: (tool_name, params_hash) → result  (max 256 entries)
    _tool_cache: dict[str, Any] = {}
    _TOOL_CACHE_MAX = 256

    @classmethod
    def _cache_key(cls, tool_name: str, params: dict) -> str:
        raw = json.dumps(params, sort_keys=True, default=str)
        h = hashlib.md5(raw.encode()).hexdigest()[:12]
        return f"{tool_name}:{h}"

    @classmethod
    def _cache_get(cls, key: str) -> Any | None:
        return cls._tool_cache.get(key)

    @classmethod
    def _cache_put(cls, key: str, result: Any) -> None:
        if len(cls._tool_cache) >= cls._TOOL_CACHE_MAX:
            # Evict oldest entry
            oldest = next(iter(cls._tool_cache))
            del cls._tool_cache[oldest]
        cls._tool_cache[key] = result

    def __init__(self):
        self._snapshot: ChatSnapshot | None = None
        self._coordinator = CoordinatorAgent()

    @staticmethod
    def _is_governance_evidence_request(message: str) -> bool:
        """Detect platform-state questions that require audited local evidence."""
        lower = str(message or "").lower()
        return any(token in lower for token in (
            "model claim", "model quality", "training eligible", "training status",
            "release ready", "release status", "customer delivery", "customer-ready",
            "模型声明", "模型质量", "训练资格", "训练状态", "发布状态", "客户交付",
            "客户可交付", "能不能交付",
        ))

    @staticmethod
    def _wants_live_literature_search(message: str) -> bool:
        """Detect requests that should use the live PubMed/Crossref search tool."""
        lower = str(message or "").lower()
        return any(token in lower for token in (
            "联网", "网络搜索", "在线搜索", "实时搜索", "最新", "最近", "文献",
            "论文", "pubmed", "crossref", "doi", "pmid", "literature",
            "paper", "papers", "publication", "publications",
        ))

    @staticmethod
    def _iter_text_stream_chunks(text: str, chunk_size: int = 96):
        """Yield text chunks without normalizing whitespace or Markdown layout."""
        if not text:
            return
        for start in range(0, len(text), chunk_size):
            yield text[start:start + chunk_size]

    @staticmethod
    def _is_document_reply_request(message: str) -> bool:
        lower = message.lower()
        return any(kw in lower for kw in [
            "checklist", "sop", "protocol", "schedule", "template", "table",
            "清单", "执行清单", "实验执行", "排期", "模板", "表格", "登记表",
            "整理成", "直接执行", "给学生", "给同事",
        ])

    @staticmethod
    def _is_design_pipeline_step(tool_name: str) -> bool:
        return tool_name in {
            "sequence_search",
            "rfdiffusion_design",
            "chroma_design",
            "proteinmpnn_design",
            "esmfold_folding",
            "soluble_mpnn_design",
            "predict_properties",
        }

    @staticmethod
    def _is_structure_gate_step(tool_name: str) -> bool:
        return tool_name in _STRUCTURE_GATE_TOOLS

    @staticmethod
    def _is_structure_dependent_step(tool_name: str) -> bool:
        return tool_name in _STRUCTURE_DEPENDENT_TOOLS

    @classmethod
    def _requires_ordered_execution(cls, plan: list[PlanStep]) -> bool:
        return (
            any(cls._is_structure_gate_step(step.tool_name) for step in plan)
            or any(cls._is_design_pipeline_step(step.tool_name) for step in plan)
            or any(step.tool_name in _ENZYME_FOUNDATION_TOOLS for step in plan)
        )

    @classmethod
    def _identity_gate_passed(cls, completed_steps: list[PlanStep]) -> bool:
        """Require a confirmed, coordinate-ready profile before candidate generation."""
        latest_identity = next(
            (
                step.result for step in reversed(completed_steps)
                if step.tool_name == "enzyme_identity_profile" and step.status == "completed"
            ),
            None,
        )
        profile = latest_identity if isinstance(latest_identity, dict) else cls._safe_parse_json(str(latest_identity or ""))
        guardrail = profile.get("guardrail") if isinstance(profile, dict) else {}
        return (
            isinstance(profile, dict)
            and profile.get("identity_status") == "identified"
            and isinstance(guardrail, dict)
            and guardrail.get("status") == "ready"
        )

    @classmethod
    def _objective_gate_passed(cls, completed_steps: list[PlanStep]) -> bool:
        """Require objective-specific evidence before mutation candidate generation."""
        latest_objective = next(
            (
                step.result for step in reversed(completed_steps)
                if step.tool_name == "enzyme_objective_module_plan" and step.status == "completed"
            ),
            None,
        )
        if latest_objective is None:
            return True
        payload = latest_objective if isinstance(latest_objective, dict) else cls._safe_parse_json(str(latest_objective or ""))
        return (
            isinstance(payload, dict)
            and payload.get("status") == "ready"
            and payload.get("candidate_output_allowed") is True
        )

    @classmethod
    def _structure_gate_passed(cls, step: PlanStep) -> bool:
        if step.status not in {"completed", "submitted"}:
            return False
        payload = step.result if isinstance(step.result, dict) else cls._safe_parse_json(str(step.result or ""))
        if step.tool_name == "structure_search_foldseek":
            query_structure = payload.get("query_structure") if isinstance(payload, dict) else None
            return bool(query_structure) or payload.get("found") is True
        if step.tool_name == "residue_mapping_sifts":
            return bool(payload.get("found")) and str(payload.get("status") or "").lower() == "completed"
        if step.tool_name == "residue_numbering_gate":
            return str(payload.get("status") or "").lower() in {"allowed", "warning"}
        return True

    @staticmethod
    def _should_submit_interactive_async_step(step: PlanStep) -> bool:
        """Return true when chat should enqueue a tool instead of running it inline."""
        try:
            from app.services.scheduler import ASYNC_TOOLS
        except Exception:
            logger.exception("Unable to load async tool registry")
            return False
        return step.tool_name in ASYNC_TOOLS and not step.params.get("allow_interactive_sync_run")

    @staticmethod
    def _normalize_interactive_async_params(step: PlanStep) -> PlanStep:
        """Prepare async tool params for real background execution."""
        if step.tool_name != "gromacs_md":
            return step

        step.params = {
            **step.params,
            "replicate_plan_only": False,
            "upload_artifacts": step.params.get("upload_artifacts", True),
        }
        step.description = (
            "Submit a real molecular dynamics job to the background task runner; "
            "poll the returned task status for progress, cancellation, and artifacts."
        )
        return step

    @staticmethod
    async def _submit_interactive_async_step(
        step: PlanStep,
        *,
        current_user: dict | None = None,
        audit_session: Any | None = None,
    ) -> dict:
        """Submit a long-running tool from chat without blocking the SSE stream."""
        if not current_user or current_user.get("id") is None:
            raise RuntimeError(f"Cannot submit async tool {step.tool_name}: missing current user")

        from app.services.scheduler import dispatch_tool, get_task_profile
        from app.services.tool_task_audit import record_task_submitted
        from app.services.tool_task_store import (
            record_tool_task_owner,
            record_tool_task_runtime_policy,
        )

        task_id = dispatch_tool(step.tool_name, step.params)
        profile = get_task_profile(step.tool_name)
        await record_tool_task_owner(task_id, current_user["id"], step.tool_name)
        await record_tool_task_runtime_policy(
            task_id,
            queue=profile.queue,
            soft_time_limit=profile.soft_time_limit,
            time_limit=profile.time_limit,
        )
        audit_recorded = False
        audit_error = None
        if audit_session is not None:
            try:
                await record_task_submitted(
                    audit_session,
                    task_id=task_id,
                    user_id=current_user["id"],
                    tool_name=step.tool_name,
                    params=step.params,
                    queue=profile.queue,
                    soft_time_limit=profile.soft_time_limit,
                    time_limit=profile.time_limit,
                )
                await audit_session.commit()
                audit_recorded = True
            except Exception as exc:
                logger.exception("Failed to record interactive async task audit for %s", task_id)
                audit_error = str(exc)
                with suppress(Exception):
                    await audit_session.rollback()

        return {
            "status": "submitted",
            "tool": step.tool_name,
            "task_id": task_id,
            "queue": profile.queue,
            "soft_time_limit": profile.soft_time_limit,
            "time_limit": profile.time_limit,
            "status_url": f"/api/tools/tasks/{task_id}",
            "cancel_url": f"/api/tools/tasks/{task_id}/cancel",
            "artifacts_url": f"/api/tools/tasks/{task_id}/artifacts",
            "audit_recorded": audit_recorded,
            "audit_error": audit_error,
            "note": (
                "Long-running tool submitted to the background worker. "
                "This is not a fixed report or plan-only shortcut; poll status_url for real execution progress."
            ),
        }

    @staticmethod
    def _extract_pdb_from_design_result(result: Any) -> str | None:
        if not isinstance(result, dict):
            return None

        def _format_chain(chain_id: str, coords: list[tuple[float, float, float]]) -> list[str]:
            lines: list[str] = []
            for idx, (x, y, z) in enumerate(coords, start=1):
                lines.append(
                    f"ATOM  {idx:5d}  CA  ALA {chain_id:>2}{idx:4d}    "
                    f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00 80.00           C"
                )
            return lines

        if "designs" not in result or not result["designs"]:
            return None

        design0 = result["designs"][0]
        sym = design0.get("symmetry_result", {})
        chains = sym.get("chains", [])
        if not chains:
            return None

        pdb_lines: list[str] = []
        atom_serial = 1
        for chain in chains:
            chain_id = str(chain.get("chain_id", "A"))[:2].strip() or "A"
            coords = chain.get("coordinates") or []
            for residue_index, coord in enumerate(coords, start=1):
                if not isinstance(coord, (list, tuple)) or len(coord) != 3:
                    continue
                x, y, z = coord
                pdb_lines.append(
                    f"ATOM  {atom_serial:5d}  CA  ALA {chain_id:>2}{residue_index:4d}    "
                    f"{float(x):8.3f}{float(y):8.3f}{float(z):8.3f}  1.00 80.00           C"
                )
                atom_serial += 1
            pdb_lines.append("TER")

        if not pdb_lines:
            return None
        pdb_lines.append("END")
        return "\n".join(pdb_lines)

    @staticmethod
    def _extract_sequence_from_result(result: Any) -> str | None:
        if not isinstance(result, dict):
            return None

        if isinstance(result.get("best_sequence"), str) and result["best_sequence"].strip():
            return result["best_sequence"].strip()

        designs = result.get("designs")
        if isinstance(designs, list) and designs:
            first = designs[0]
            if isinstance(first, dict) and isinstance(first.get("sequence"), str) and first["sequence"].strip():
                return first["sequence"].strip()

        seq = result.get("sequence")
        if isinstance(seq, str) and seq.strip():
            return seq.strip()

        return None

    def _bridge_step_params(self, step: PlanStep, completed_steps: list[PlanStep]) -> PlanStep:
        """Inject missing dependent parameters from earlier completed design steps."""
        if not completed_steps:
            return step

        latest_pdb_result = next(
            (s.result for s in reversed(completed_steps) if s.tool_name == "rfdiffusion_design" and s.status == "completed"),
            None,
        )
        latest_sequence_result = next(
            (
                s.result for s in reversed(completed_steps)
                if s.tool_name in {"proteinmpnn_design", "chroma_design", "soluble_mpnn_design", "sequence_search"}
                and s.status == "completed"
            ),
            None,
        )
        latest_identity_result = next(
            (
                s.result for s in reversed(completed_steps)
                if s.tool_name == "enzyme_identity_profile" and s.status == "completed"
            ),
            None,
        )
        latest_annotation_result = next(
            (
                s.result for s in reversed(completed_steps)
                if s.tool_name == "annotation_bundle" and s.status == "completed"
            ),
            None,
        )
        latest_mapping_result = next(
            (
                s.result for s in reversed(completed_steps)
                if s.tool_name == "residue_mapping_sifts" and s.status == "completed"
            ),
            None,
        )
        latest_objective_result = next(
            (
                s.result for s in reversed(completed_steps)
                if s.tool_name == "enzyme_objective_module_plan" and s.status == "completed"
            ),
            None,
        )

        if step.tool_name == "proteinmpnn_design" and not step.params.get("pdb_structure"):
            pdb_text = self._extract_pdb_from_design_result(latest_pdb_result)
            if pdb_text:
                step.params = {**step.params, "pdb_structure": pdb_text}

        if step.tool_name == "esmfold_folding" and not step.params.get("sequence"):
            sequence = self._extract_sequence_from_result(latest_sequence_result)
            if sequence:
                step.params = {**step.params, "sequence": sequence}

        if step.tool_name == "chroma_design" and not step.params.get("length"):
            rf_params = latest_pdb_result.get("parameters", {}) if isinstance(latest_pdb_result, dict) else {}
            length = rf_params.get("length")
            if isinstance(length, int) and length > 0:
                step.params = {**step.params, "length": length}

        if step.tool_name in {"protein_benchmark", "enzyme_function", "mutation_priority_score"} and not step.params.get("identity_profile"):
            identity_profile = self._safe_parse_json(str(latest_identity_result)) if latest_identity_result is not None else {}
            if identity_profile:
                step.params = {**step.params, "identity_profile": identity_profile}

        if step.tool_name == "enzyme_objective_module_plan" and not step.params.get("identity_profile"):
            identity_profile = self._safe_parse_json(str(latest_identity_result)) if latest_identity_result is not None else {}
            if identity_profile:
                step.params = {**step.params, "identity_profile": identity_profile}

        if step.tool_name == "mutation_priority_score" and not step.params.get("objective_module_plan"):
            objective_plan = self._safe_parse_json(str(latest_objective_result)) if latest_objective_result is not None else {}
            if objective_plan:
                step.params = {**step.params, "objective_module_plan": objective_plan}

        if step.tool_name == "enzyme_identity_profile" and not step.params.get("evidence_bundle"):
            annotation_bundle = self._safe_parse_json(str(latest_annotation_result)) if latest_annotation_result is not None else {}
            if annotation_bundle:
                step.params = {**step.params, "evidence_bundle": annotation_bundle}

        if step.tool_name == "residue_numbering_gate" and not step.params.get("mapping_rows"):
            mappings = latest_mapping_result.get("mappings", []) if isinstance(latest_mapping_result, dict) else []
            mapping_rows = []
            for row in mappings:
                if not isinstance(row, dict):
                    continue
                source_position = row.get("uniprot_position")
                target_position = row.get("pdb_residue_no")
                try:
                    source_position = int(source_position)
                    target_position = int(target_position)
                except (TypeError, ValueError):
                    continue
                confidence = str(row.get("mapping_confidence") or row.get("confidence") or "unknown")
                mapping_rows.append({
                    "source_scheme": "user_sequence",
                    "source_position": source_position,
                    "target_scheme": "pdb",
                    "target_position": target_position,
                    "chain_id": row.get("chain_id"),
                    "confidence": confidence,
                    "method": str(row.get("source") or "residue_mapping_sifts"),
                    "missing_in_structure": False,
                })
            if mapping_rows:
                step.params = {**step.params, "mapping_rows": mapping_rows}

        return step

    @property
    def tools_schema(self) -> list[dict]:
        """Lazy-load tools schema — ToolRegistry is populated after import."""
        return ToolRegistry.get_tools_schema()

    @property
    def skills_metadata(self) -> list[dict]:
        """Lazy-load skills — SkillRegistry is populated after import."""
        return get_skills_metadata()

    def get_snapshot_data(self) -> dict | None:
        """Return current snapshot data for report generation (used by auto-publish)."""
        if self._snapshot is None:
            return None
        s = self._snapshot
        return {
            "stage": s.stage,
            "research_notes": s.research_notes,
            "plan": s.plan,
            "step_results": s.step_results,
            "final_report": s.final_report,
        }

    def _build_context(self, history: list[dict]) -> str:
        """Build protein context from conversation history."""
        context_parts = []
        for msg in history:
            content = msg.get("content", "")
            if not isinstance(content, str):
                continue
            object_name = self._extract_attached_object_name(content)
            if object_name:
                context_parts.append(f"[Uploaded structure object_name: {object_name}]")
            if ">" in content:
                # Extract potential FASTA sequences
                if content.count(">") >= 1:
                    context_parts.append("[Protein sequence detected in conversation]")
            if any(kw in content.lower() for kw in ["pd-l1", "egfr", "her2", "kras", "p53"]):
                context_parts.append("[Known protein target discussed]")
        return "\n".join(context_parts) if context_parts else ""

    @staticmethod
    def _extract_sequence(text: str) -> str | None:
        """Extract a valid amino-acid sequence from FASTA, labelled, or raw sequence text.

        The raw fallback is intentionally case-sensitive. Otherwise ordinary words such
        as "specificity" are valid one-letter amino-acid strings and get misread as
        short protein fragments in mixed Chinese/English prompts.
        """
        if not isinstance(text, str) or not text.strip():
            return None

        def _clean(candidate: str) -> str:
            return re.sub(r"[^ACDEFGHIKLMNPQRSTVWY]", "", candidate.upper())

        fasta_blocks = re.findall(r">[^\n\r]*(?:\r?\n)([A-Za-z\s\r\n-]{10,})", text)
        fasta_matches = [_clean(block) for block in fasta_blocks]
        fasta_matches = [seq for seq in fasta_matches if len(seq) >= 10]
        if fasta_matches:
            return max(fasta_matches, key=len)

        labelled_matches = re.findall(
            r"(?:序列|氨基酸序列|protein sequence|sequence)\s*(?:为|是|=|[:：])?\s*([A-Za-z\s\r\n-]{10,})",
            text,
            re.IGNORECASE,
        )
        labelled = [_clean(match) for match in labelled_matches]
        labelled = [seq for seq in labelled if len(seq) >= 10]
        if labelled:
            return max(labelled, key=len)

        matches = re.findall(r'(?<![A-Za-z])[ACDEFGHIKLMNPQRSTVWY]{10,}(?![A-Za-z])', text)
        if matches:
            return max(matches, key=len).upper()
        return None

    @staticmethod
    def _clean_literature_query(text: str) -> str:
        """Keep live literature queries focused on the user's natural-language ask."""
        if not isinstance(text, str):
            return ""
        cleaned = re.split(r"\n\s*\[Attached files:", text, maxsplit=1)[0]
        cleaned = re.sub(r"\[[^\]]+\]", " ", cleaned)
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        for marker in ("请联网", "联网搜索", "网络搜索", "在线搜索", "实时搜索", "查一下", "检索一下"):
            cleaned = cleaned.replace(marker, " ")
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" ：:，,。")
        return cleaned[:240] or text.strip()[:240]

    @staticmethod
    def _task_requests_no_tools(text: str) -> bool:
        if not isinstance(text, str):
            return False
        lower = text.lower()
        return any(pattern in lower for pattern in [
            "不要调用工具",
            "不调用工具",
            "禁止调用工具",
            "不要跑工具",
            "不要使用工具",
            "不使用工具",
            "只抽取",
            "只提取",
            "只解析",
            "只要抽取",
            "只做抽取",
            "不分析",
            "不要分析",
            "do not call tools",
            "don't call tools",
            "without tools",
            "no tools",
            "only extract",
            "extract only",
            "do not analyze",
            "don't analyze",
        ])

    @classmethod
    def _build_extraction_only_reply(cls, message: str) -> str:
        sequence = cls._extract_sequence(message)
        pdb_object_name = cls._extract_attached_object_name(message)
        protein_name = cls._extract_named_protein_reference(message)
        uniprot_id = cls._extract_uniprot_reference(message)
        pdb_id = cls._extract_pdb_id_reference(message)

        lines = ["## 抽取结果\n"]
        if sequence:
            lines.append(f"- 氨基酸序列：`{sequence}`")
            lines.append(f"- 序列长度：{len(sequence)} aa")
        if pdb_object_name:
            lines.append(f"- 已上传结构对象：`{pdb_object_name}`")
        if protein_name:
            lines.append(f"- 蛋白/酶名称：{protein_name}")
        if uniprot_id:
            lines.append(f"- UniProt：`{uniprot_id}`")
        if pdb_id:
            lines.append(f"- PDB：`{pdb_id}`")
        if len(lines) == 1:
            lines.append("- 未抽取到明确的序列、结构对象、UniProt/PDB 编号或蛋白名称。")
        lines.append("\n未调用任何分析工具。")
        return "\n".join(lines)

    @staticmethod
    def _is_negative_tool_context(text: str) -> bool:
        if not isinstance(text, str):
            return False
        lower = text.lower()
        return any(kw in lower for kw in [
            "禁止", "不要", "不允许", "别", "无需", "不能", "不得",
            "do not", "don't", "without", "no ", "not call", "forbid", "forbidden",
        ])

    @classmethod
    def _extract_forbidden_tools(cls, text: str) -> set[str]:
        if not cls._is_negative_tool_context(text):
            return set()
        lower = text.lower()
        forbidden: set[str] = set()
        tool_groups: list[tuple[tuple[str, ...], tuple[str, ...]]] = [
            (("esmfold", "folding", "结构预测", "折叠预测", "折叠"), ("esmfold_folding", "alphafold_folding", "alphafold2_folding", "rosettafold_folding")),
            (("blast", "同源", "比对"), ("blast_search",)),
            (("家族预测", "家族分析", "保守分析", "保守位点", "motif", "family", "conservation"), ("blast_search", "protein_benchmark", "enzyme_function")),
            (("突变打分", "突变评分", "突变排序", "mutation scoring", "mutation score", "priority score"), ("mutation_priority_score", "mutation_scan", "protssn_score")),
            (("mutation_priority_score",), ("mutation_priority_score",)),
            (("mutation_scan", "突变扫描", "饱和突变"), ("mutation_scan",)),
            (("protssn",), ("protssn_score",)),
            (("predict_properties", "理化性质", "性质预测"), ("predict_properties",)),
            (("sequence_search", "序列搜索", "查库", "检索序列"), ("sequence_search",)),
            (("gromacs", "分子动力学", "rmsd", "rmsf"), ("gromacs_md",)),
            (("foldseek", "结构检索"), ("structure_search_foldseek",)),
            (("编号映射", "residue mapping", "sifts"), ("residue_mapping_sifts", "residue_numbering_gate")),
        ]
        for triggers, tools in tool_groups:
            if any(trigger in lower for trigger in triggers):
                forbidden.update(tools)
        return forbidden

    @classmethod
    def _apply_tool_constraints(cls, plan: list[PlanStep], task: str, context: str = "") -> list[PlanStep]:
        combined = f"{task}\n{context}".strip()
        if cls._task_requests_no_tools(combined):
            return []
        forbidden = cls._extract_forbidden_tools(combined)
        if not forbidden:
            return plan
        filtered = [step for step in plan if step.tool_name not in forbidden]
        for index, step in enumerate(filtered, start=1):
            step.id = index
        return filtered

    @classmethod
    def _classify_engineering_objectives(cls, text: str) -> set[str]:
        lower = text.lower()
        objectives: set[str] = set()
        if any(kw in lower for kw in ["耐热", "热稳定", "热稳定性", "thermostability", "thermal stability", "temperature stability", "melting temperature", "tm", "heat"]):
            objectives.add("thermostability")
        if any(kw in lower for kw in ["降低最适ph", "降低ph", "酸化", "耐酸", "酸性", "酸稳定", "lower ph", "ph lowering"]):
            objectives.add("ph_lowering")
        if any(kw in lower for kw in ["提高最适ph", "提高ph", "碱化", "耐碱", "碱性", "碱稳定", "raise ph", "ph raising"]):
            objectives.add("ph_raising")
        if any(kw in lower for kw in ["底物特异", "特异性", "选择性", "specificity", "substrate specificity", "selectivity"]):
            objectives.add("specificity")
        if any(kw in lower for kw in ["比活", "酶活", "活性", "催化效率", "kcat", "km", "activity", "specific activity", "catalytic efficiency"]):
            objectives.add("activity")
        if any(kw in lower for kw in ["可溶", "可溶性", "表达", "表达量", "solubility", "soluble expression", "expression yield"]):
            objectives.add("solubility")
        return objectives

    @staticmethod
    def _primary_engineering_goal(objectives: set[str]) -> str:
        for goal in ("thermostability", "ph_lowering", "ph_raising", "specificity", "activity"):
            if goal in objectives:
                return goal
        return "general"

    @staticmethod
    def _extract_assay_context(text: str) -> dict[str, Any]:
        """Extract only explicit assay context signals; absence remains missing evidence."""
        if not isinstance(text, str):
            return {}
        lower = text.lower()
        context: dict[str, Any] = {}
        if re.search(r"\btm\s*[=:]?\s*\d{2,3}", lower) or "熔解温度" in lower:
            context["tm"] = True
        if any(kw in lower for kw in ["half-life", "half life", "半衰期"]):
            context["half_life"] = True
        if any(kw in lower for kw in ["residual activity", "残余活性", "热处理后活性"]):
            context["residual_activity"] = True
        if any(kw in lower for kw in ["specific activity", "比活", "protein-normalized", "蛋白归一化"]):
            context["specific_activity"] = True
            context["protein_normalized"] = True
        if any(kw in lower for kw in ["kcat", "k_cat"]):
            context["kcat"] = True
        if re.search(r"\bkm\b", lower) or "米氏常数" in lower:
            context["km"] = True
        if any(kw in lower for kw in ["ph curve", "ph-activity curve", "ph 活性曲线", "ph曲线", "完整ph"]):
            context["ph_curve"] = True
        if re.search(r"ph\s*\d(?:\.\d)?\s*/\s*ph\s*\d(?:\.\d)?", lower) or any(
            kw in lower for kw in ["点比值", "point ratio", "单点比值"]
        ):
            context["point_ratio"] = True
        target_match = re.search(r"(?:target_substrate|目标底物)\s*[:：=]\s*([^,，;\n]+)", text, re.IGNORECASE)
        off_target_match = re.search(r"(?:off_target_substrate|非目标底物|对照底物)\s*[:：=]\s*([^,，;\n]+)", text, re.IGNORECASE)
        if target_match:
            context["target_substrate"] = target_match.group(1).strip()
        if off_target_match:
            context["off_target_substrate"] = off_target_match.group(1).strip()
        return context

    @staticmethod
    def _extract_requested_positions(text: str) -> list[int]:
        """Extract residue positions that require numbering confirmation."""
        if not isinstance(text, str):
            return []
        positions: set[int] = set()
        for match in re.finditer(r"[ACDEFGHIKLMNPQRSTVWY]([0-9]{1,5})[ACDEFGHIKLMNPQRSTVWY]", text, re.IGNORECASE):
            positions.add(int(match.group(1)))
        for match in re.finditer(r"(?:位点|残基|position|residue)\s*([0-9]{1,5})", text, re.IGNORECASE):
            positions.add(int(match.group(1)))
        return sorted(pos for pos in positions if pos > 0)

    @staticmethod
    def _extract_requested_mutations(text: str) -> list[str]:
        """Extract concrete point mutations in WT-position-mutant format."""
        if not isinstance(text, str):
            return []
        mutations: list[str] = []
        seen: set[str] = set()
        for match in re.finditer(
            r"\b([ACDEFGHIKLMNPQRSTVWY][0-9]{1,5}[ACDEFGHIKLMNPQRSTVWY])\b",
            text,
            re.IGNORECASE,
        ):
            mutation = match.group(1).upper()
            if mutation not in seen:
                seen.add(mutation)
                mutations.append(mutation)
        return mutations

    @staticmethod
    def _extract_attached_object_name(text: str) -> str | None:
        """Extract an uploaded structure object name from the chat attachment block."""
        if not isinstance(text, str) or "object_name" not in text:
            return None

        candidates = re.findall(
            r"['\"]?object_name['\"]?\s*[:=]\s*['\"]?([^'\"\s,\]\}]+)",
            text,
        )
        for candidate in candidates:
            normalized = candidate.strip().strip("'\"")
            lowered = normalized.lower()
            if lowered.endswith((".pdb", ".ent", ".cif")):
                return normalized

        for candidate in candidates:
            normalized = candidate.strip().strip("'\"")
            if normalized.startswith("uploads/"):
                return normalized
        return None

    @classmethod
    def _has_concrete_protein_input(cls, text: str, context: str = "") -> bool:
        """Return true only when a request contains actionable protein input.

        This deliberately excludes broad natural-language questions. Without this
        gate, generic Chinese questions can fall through to a UniProt
        sequence_search using the whole sentence as a keyword query.
        """
        combined = f"{text}\n{context}".strip()
        if cls._extract_sequence(combined):
            return True
        if cls._extract_attached_object_name(combined):
            return True
        if cls._extract_uniprot_reference(text) or cls._extract_pdb_id_reference(text):
            return True
        if cls._extract_named_protein_reference(text):
            return True
        if "[Protein sequence detected" in context or "[Known protein target discussed" in context:
            return True
        uppercase_hits = re.findall(r"\b([A-Z][A-Z0-9]{1,14}(?:[-/][A-Z0-9]{1,14})*)\b", text)
        ignored = {"AI", "IT", "PDB", "MD", "SOP", "JSON", "CSV", "API", "RDS", "OSS"}
        mutation_code = re.compile(r"^[ACDEFGHIKLMNPQRSTVWY][0-9]{1,5}[ACDEFGHIKLMNPQRSTVWY]$")
        if any(hit.upper() not in ignored and not mutation_code.match(hit.upper()) for hit in uppercase_hits):
            return True
        if re.search(r"\b[OPQ][0-9][A-Z0-9]{3}[0-9]\b", text):
            return True
        return False

    @staticmethod
    def _extract_named_protein_reference(text: str) -> str:
        """Extract explicit Chinese protein/enzyme naming fields from user text."""
        if not isinstance(text, str):
            return ""
        patterns = [
            r"(?:酶的?名称|蛋白(?:质)?名称|目标蛋白|目标酶|蛋白质?|酶)\s*(?:为|是|=|[:：])\s*([^\n，,。；;]+)",
            r"(?:enzyme|protein)\s+(?:name\s*)?(?:is|=|[:：])\s*([^\n,;]+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                name = re.split(
                    r"(?:\s+|^)?(?:结构|目标|底物|反应|表达|条件|体系|突变|mutation|mutant|variant)\s*[:：]?",
                    name,
                    maxsplit=1,
                    flags=re.IGNORECASE,
                )[0].strip()
                if name:
                    return name[:120]
        return ""

    @staticmethod
    def _extract_uniprot_reference(text: str) -> str:
        """Extract an explicit UniProt accession from labelled user input."""
        if not isinstance(text, str):
            return ""
        patterns = [
            r"(?:uniprot(?:kb)?(?:\s*(?:id|accession|编号|号))?|UniProt编号)\s*[:：=]?\s*([A-Za-z0-9]{6,10}(?:-\d+)?)",
            r"(?:UniProt|uniprot)\s+([A-Za-z0-9]{6,10}(?:-\d+)?)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                accession = match.group(1).strip().upper()
                if re.fullmatch(r"[A-Z][A-Z0-9]{5,9}(?:-\d+)?", accession):
                    return accession
        return ""

    @staticmethod
    def _extract_pdb_id_reference(text: str) -> str:
        """Extract an explicit four-character PDB ID from labelled user input."""
        if not isinstance(text, str):
            return ""
        patterns = [
            r"(?:pdb(?:\s*(?:id|编号|号))?|PDB编号)\s*[:：=]?\s*([0-9][A-Za-z0-9]{3})",
            r"(?:PDB|pdb)\s+([0-9][A-Za-z0-9]{3})",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip().upper()
        return ""

    @classmethod
    def _extract_lookup_target(cls, task: str) -> tuple[str, str]:
        """Return a conservative lookup query and target database."""
        named = cls._extract_named_protein_reference(task)
        if named:
            return named, "uniprot"
        uniprot_id = cls._extract_uniprot_reference(task)
        if uniprot_id:
            return uniprot_id, "uniprot"
        pdb_id = cls._extract_pdb_id_reference(task)
        if pdb_id:
            return pdb_id, "pdb"
        name = cls._extract_protein_name(task)
        return name, "uniprot"

    @classmethod
    def _is_model_meta_question(cls, message: str, context: str = "") -> bool:
        """Detect questions about the model/system itself, not a protein task."""
        if cls._has_concrete_protein_input(message, ""):
            return False
        lower = message.lower()
        subject_terms = [
            "模型", "系统", "平台", "你", "你们", "回答", "结果", "报告",
            "model", "system", "platform", "you", "your answer", "result",
        ]
        topic_terms = [
            "能力边界", "边界", "文献依据", "依据", "胡编", "编造", "可靠", "可信",
            "证据", "怎么用", "能不能", "会不会", "是否", "实验方案",
            "capability", "limitation", "citation", "evidence", "hallucinat",
            "reliable", "trust", "how to use",
        ]
        return any(term in lower for term in subject_terms) and any(term in lower for term in topic_terms)

    @staticmethod
    def _is_enzyme_engineering_request(message: str) -> bool:
        lower = message.lower()
        return any(kw in lower for kw in [
            "enzyme", "酶", "ph", "酸性", "碱性", "最适", "酶活", "engineering", "改造",
            "mutation", "mutant", "variant", "stability", "stabilize", "activity",
            "catalytic", "substrate", "kcat", "km", "specificity", "optimum",
            "突变", "耐酸", "耐碱", "耐热", "热稳定", "比活力",
        ])

    @classmethod
    def _should_clarify_before_tools(cls, message: str, route: str, context: str = "") -> bool:
        """Decide whether an apparent protein task lacks enough input for tools."""
        if route == "general":
            return False
        if cls._has_concrete_protein_input(message, context):
            return False
        lower = message.lower()
        if route == "design":
            return True
        mutation_code_only = bool(
            re.search(r"\b[ACDEFGHIKLMNPQRSTVWY][0-9]{1,5}[ACDEFGHIKLMNPQRSTVWY]\b", message, re.IGNORECASE)
        )
        vague_subject = any(kw in lower for kw in [
            "这个酶", "该酶", "这个蛋白", "该蛋白", "this enzyme", "this protein",
            "这个模型", "这个序列", "只给你一句需求",
        ])
        search_without_target = any(kw in lower for kw in [
            "查", "搜索", "检索", "文献", "证据", "search", "find", "literature", "evidence",
        ]) and any(kw in lower for kw in ["酶", "蛋白", "protein", "enzyme"])
        return mutation_code_only or cls._is_enzyme_engineering_request(message) or vague_subject or search_without_target

    @staticmethod
    def _build_missing_input_reply(message: str, route: str) -> str:
        """Ask for missing scientific inputs instead of fabricating a report."""
        return (
            "## 任务理解\n"
            "你提出的是酶/蛋白分析或改造相关任务，但当前输入还不足以进入工具分析。\n\n"
            "## 已知输入\n"
            f"- 用户需求：{message.strip()[:300]}\n"
            f"- 初步任务类型：{route}\n\n"
            "## 缺失信息\n"
            "- 酶或蛋白名称、UniProt/PDB 编号，或完整氨基酸序列\n"
            "- 如需结构分析：PDB/mmCIF 结构或已上传结构文件\n"
            "- 明确改造目标：耐热、pH 适应性、活性、底物特异性、表达量等\n"
            "- 底物、反应条件、表达体系和实验筛选约束\n\n"
            "## 下一步\n"
            "请先补充上述至少一类可定位输入。补齐后我再选择检索、结构、突变评分或实验设计工具；"
            "在信息不足时不会直接给具体位点或强结论。"
        )

    @classmethod
    def _tool_results_have_no_evidence(cls, tool_results: list[dict]) -> bool:
        """Identify empty evidence paths before synthesis templates can mask them."""
        if not tool_results:
            return False

        saw_search = False
        saw_support = False
        for result in tool_results:
            tool_name = result.get("tool_name")
            status = result.get("status")
            payload = cls._safe_parse_json(str(result.get("result", "")))
            if tool_name == "sequence_search":
                saw_search = True
                count = payload.get("results_count")
                results = payload.get("results")
                if status == "completed" and ((isinstance(count, int) and count > 0) or bool(results)):
                    saw_support = True
                continue
            if status == "completed" and payload:
                saw_support = True

        return saw_search and not saw_support

    @staticmethod
    def _build_no_evidence_reply(task: str, tool_results: list[dict]) -> str:
        search_summaries = []
        for result in tool_results:
            if result.get("tool_name") != "sequence_search":
                continue
            payload = AgentOrchestrator._safe_parse_json(str(result.get("result", "")))
            query = payload.get("query", "")
            database = payload.get("database", "")
            status = payload.get("status", result.get("status", "unknown"))
            search_summaries.append(f"- `sequence_search`：query=`{query}`，database=`{database}`，status=`{status}`，results=0")
        summary = "\n".join(search_summaries) if search_summaries else "- 未获得可用检索证据"
        return (
            "## 任务理解\n"
            f"你希望分析：{task.strip()[:300]}\n\n"
            "## 工具调用摘要\n"
            f"{summary}\n\n"
            "## 结论\n"
            "当前没有检索到可支撑结论的序列、结构或文献证据，因此不能给出确定性改造建议。\n\n"
            "## 建议补充\n"
            "- 提供完整氨基酸序列、UniProt/PDB 编号或明确酶名称\n"
            "- 说明改造目标、底物、pH/温度、表达体系和筛选约束\n"
            "- 如已有实验结果，请提供 WT 与突变体的活性、稳定性或表达数据\n\n"
            "补齐后再进入工具链分析。"
        )

    @staticmethod
    def _format_plan_params(params: dict) -> str:
        if not params:
            return "{}"
        try:
            rendered = json.dumps(params, ensure_ascii=False, default=str)
        except TypeError:
            rendered = str(params)
        return rendered if len(rendered) <= 320 else rendered[:317] + "..."

    @classmethod
    def _build_strategy_checkpoint(cls, task: str) -> dict:
        """Describe the design hypothesis before listing executable tools."""
        objectives = cls._classify_engineering_objectives(task)
        goal = cls._primary_engineering_goal(objectives)
        if goal == "thermostability":
            return {
                "title": "热稳定性：先加固非催化柔性区，再逐级验证组合",
                "logic": [
                    "先保护催化中心、金属结合位点和可能影响底物通道的关键残基。",
                    "优先从表面暴露、保守性较低、远离活性中心的 loop/局部疏松区域找候选。",
                    "候选替换按机制分组：降低 loop 构象熵、改善核心 packing、降低游离 Cys 氧化风险。",
                    "实验顺序是 P1 单点验证，P2 第二梯队单点，P3 仅组合已验证且机制互补的位点。",
                ],
                "output": "最终必须输出候选突变位点、每个位点的增稳逻辑、风险提示和实验优先级；工具清单只是为这些结论提供证据。",
            }
        if goal in {"ph_lowering", "ph_raising"}:
            direction = "降低" if goal == "ph_lowering" else "提高"
            return {
                "title": f"pH 改造：围绕表面电荷/pKa 调整，优先保持催化效率",
                "logic": [
                    f"目标是{direction}最适或耐受 pH，不是简单按分数挑位点。",
                    "优先筛选表面暴露、远离催化核心的电荷残基，并保留同一位点的多个替换方向形成梯度。",
                    "活性中心和底物结合位点作为保护约束，任何 pH 改善都要同时比较原始条件活性。",
                    "实验顺序是表面电荷单点梯度、不同机制单点、最后再做组合。",
                ],
                "output": "最终输出候选位点、具体替换方向、pH 改造逻辑、活性保持风险和实验优先级。",
            }
        if goal in {"activity", "specificity"}:
            target = "比活力/催化效率" if goal == "activity" else "底物特异性"
            return {
                "title": f"{target}：保护催化核心，优先调节口袋边缘和二壳层",
                "logic": [
                    f"先确认催化残基、底物结合约束和结构编号，再围绕{target}拆解可调区域。",
                    "候选优先来自口袋入口、通道和二壳层，而不是直接改造催化核心。",
                    "同时评估活性收益、底物谱、表达和稳定性风险，避免只输出单一活性分数。",
                    "实验顺序是单点方向验证、机制互补单点、通过上位性检查后再组合。",
                ],
                "output": "最终输出候选位点、具体替换方向、催化/底物作用逻辑、风险和实验优先级。",
            }
        return {
            "title": "通用改造：先建立酶画像，再按目标筛选可解释候选",
            "logic": [
                "先核验序列、结构、功能和编号，区分已知事实、计算推断和未知项。",
                "保护催化、金属结合、二硫键和其他功能核心，再按暴露度、保守性和结构距离筛选。",
                "每个候选都要绑定具体突变逻辑、预期影响、风险和实验优先级。",
            ],
            "output": "最终输出可进入实验设计的候选位点和突变方向，而不是只有工具执行动作。",
        }

    @classmethod
    def _build_plan_confirmation_reply(
        cls,
        task: str,
        plan: list[PlanStep],
        research_notes: str = "",
        *,
        revised: bool = False,
    ) -> str:
        """Build a user-visible strategy checkpoint before tools execute."""
        heading = "## 修改后的分析策略" if revised else "## 分析策略确认"
        lines = [heading, ""]
        lines.append("我已按平台人工分析流程 v1 生成本次策略，当前还没有执行任何分析工具。")
        lines.append("")
        lines.append("### 任务理解")
        lines.append(f"- 用户目标：{task.strip()[:500]}")
        if research_notes:
            compact_research = " ".join(research_notes.split())[:500]
            if compact_research:
                lines.append(f"- 初步背景：{compact_research}")
        lines.append("")
        strategy = cls._build_strategy_checkpoint(task)
        lines.append("### 改造策略（先确认方向，再执行分析）")
        lines.append(f"**{strategy['title']}**")
        for item in strategy["logic"]:
            lines.append(f"- {item}")
        lines.append(f"- **预期输出：** {strategy['output']}")
        lines.append("")
        lines.append("### 执行流程")
        if not plan:
            lines.append("- 当前输入不足，暂未生成可执行工具流程。")
        else:
            for step in plan:
                lines.append(
                    f"{step.id}. `{step.tool_name}`：{step.description}；参数：`{cls._format_plan_params(step.params)}`"
                )
        if any(step.tool_name == "rosetta_ddg" for step in plan):
            lines.append("")
            lines.append("### Rosetta ΔΔG 判读规则")
            lines.append("- 约定：ΔΔG 为负值表示突变体预测更稳定；正值表示预测更不稳定。")
            lines.append("- 默认阈值：<= -2.0 强稳定；(-2.0, -1.0] 稳定；(-1.0, 1.0] 中性/不确定；(1.0, 2.0] 不稳定；> 2.0 强不稳定。")
            lines.append("- 该工具必须核实残基编号、链 ID、PDB/UniProt/用户序列映射后才能用于实验排单。")
        lines.append("")
        lines.append("### 确认方式")
        lines.append("- 点“确认执行”后，我才会开始调用上面列出的工具。")
        lines.append("- 如果要调整策略，请在输入框写修改要求，我会重新出策略，不会直接执行。")
        lines.append("")
        lines.append("状态：等待确认，未执行工具。")
        return "\n".join(lines)

    async def stream_chat(
        self, user_message: str, history: list[dict],
        model_id: str | None = None,
        analysis_depth: str = "standard",
        agent_control: str | None = None,
        current_user: dict | None = None,
        audit_session: Any | None = None,
    ) -> AsyncGenerator[str, None]:
        """Main entry: route → research → plan → execute → synthesize."""
        self._snapshot = ChatSnapshot(stage="router")
        protein_context = self._build_context(history)
        analysis_depth = (analysis_depth or "standard").strip().lower()
        if analysis_depth not in {"fast", "standard", "deep"}:
            analysis_depth = "standard"
        control = (agent_control or "plan_only").strip().lower()
        if control not in {"plan_only", "execute_confirmed", "revise_plan"}:
            control = "plan_only"

        # --- Stage 1: ROUTER ---
        yield self._emit_state()
        if self._task_requests_no_tools(f"{user_message}\n{protein_context}".strip()):
            self._snapshot.stage = "done"
            yield self._emit_state()
            reply = self._build_extraction_only_reply(user_message)
            for chunk in self._iter_text_stream_chunks(reply):
                yield json.dumps({"type": "text", "content": chunk}, ensure_ascii=False)
            yield json.dumps({"type": "done"})
            return

        route = await self._route_intent(user_message, protein_context, model_id)
        if self._is_governance_evidence_request(user_message):
            route = "research"
        if self._wants_live_literature_search(user_message):
            route = "research"
        self._snapshot.stage = route

        # --- General chat shortcut: no protein intent → direct LLM reply ---
        if route == "general":
            self._snapshot.stage = "done"
            yield self._emit_state()
            reply = await self._chat_reply(user_message, history, model_id)
            for chunk in self._iter_text_stream_chunks(reply):
                yield json.dumps({"type": "text", "content": chunk}, ensure_ascii=False)
            yield json.dumps({"type": "done"})
            return

        clarification = None
        if self._should_clarify_before_tools(user_message, route, protein_context):
            clarification = self._build_missing_input_reply(user_message, route)
        if clarification:
            self._snapshot.stage = "done"
            self._snapshot.waiting_for = "clarification"
            yield self._emit_state()
            for chunk in self._iter_text_stream_chunks(clarification):
                yield json.dumps({"type": "text", "content": chunk}, ensure_ascii=False)
            yield json.dumps({"type": "done"})
            return

        # --- Stage 2+3: RESEARCH (PI) + PLAN (CB) — parallel ---
        yield self._emit_state()
        yield json.dumps({"type": "text", "content": "\n\n"}, ensure_ascii=False)
        if route in ("research", "design", "analyze"):
            # Run research+plan concurrently — knowledge gathering is fire-and-forget
            # with a short timeout so it doesn't block the pipeline
            async def _fast_research():
                try:
                    return await asyncio.wait_for(
                        self._research_pi(user_message, history, protein_context, model_id, task_type=route),
                        timeout=15,  # cap research at 15s
                    )
                except asyncio.TimeoutError:
                    logger.info("Research PI timed out after 15s, proceeding without")
                    return ""

            research_task = asyncio.create_task(_fast_research())
            plan_task = asyncio.create_task(
                self._plan_cb(user_message, "", history, model_id, protein_context, analysis_depth=analysis_depth)
            )
            research, plan = await asyncio.gather(research_task, plan_task)
            self._snapshot.research_notes = research
            yield self._emit_state()
        else:
            self._snapshot.research_notes = ""
            plan = await self._plan_cb(user_message, "", history, model_id, protein_context, analysis_depth=analysis_depth)
        self._snapshot.plan = [{
            "id": s.id, "tool_name": s.tool_name,
            "description": s.description, "params": s.params,
            "status": s.status,
        } for s in plan]
        self._snapshot.waiting_for = "plan_confirmation"
        yield self._emit_state()

        # If no plan steps were generated, use research notes as the reply
        if not plan:
            self._snapshot.stage = "done"
            yield self._emit_state()
            reply = self._snapshot.research_notes or self._build_missing_input_reply(user_message, route)
            for chunk in self._iter_text_stream_chunks(reply):
                yield json.dumps({"type": "text", "content": chunk}, ensure_ascii=False)
            yield json.dumps({"type": "done"})
            return

        if control != "execute_confirmed":
            self._snapshot.stage = "done"
            self._snapshot.waiting_for = "plan_confirmation"
            yield self._emit_state()
            reply = self._build_plan_confirmation_reply(
                user_message,
                plan,
                self._snapshot.research_notes,
                revised=control == "revise_plan",
            )
            for chunk in self._iter_text_stream_chunks(reply):
                yield json.dumps({"type": "text", "content": chunk}, ensure_ascii=False)
            yield json.dumps({"type": "done"})
            return

        self._snapshot.waiting_for = None

        # --- Stage 4: EXECUTE (MLS) — parallel where possible ---
        self._snapshot.stage = "execute"
        yield self._emit_state()

        # Per-step timeout cap — prevents slow external APIs from blocking the pipeline
        PER_STEP_TIMEOUT = 300  # seconds (enzyme_function needs ~2min, esmfold up to 5min)

        def _resolve_step_timeout(tool_name: str) -> int:
            tool_def = ToolRegistry.get_tool(tool_name)
            if tool_def and tool_def.timeout_seconds:
                return max(PER_STEP_TIMEOUT, int(tool_def.timeout_seconds))
            return PER_STEP_TIMEOUT

        # --- Execute plan: design pipelines are dependency-ordered; analysis can stay parallel ---
        # Keep planned steps pending until execution actually starts. Marking
        # every step running up front makes the UI look stuck during slow calls.
        for i, step in enumerate(plan):
            if self._should_submit_interactive_async_step(step):
                step = self._normalize_interactive_async_params(step)
            plan[i] = step
            self._snapshot.plan[i]["description"] = step.description
            self._snapshot.plan[i]["params"] = step.params
            self._snapshot.plan[i]["status"] = step.status
        yield self._emit_state()

        # Semaphore: max 2 tools concurrently (safe with 8GB VM memory)
        _tool_semaphore = asyncio.Semaphore(2)

        async def _run_step(i: int, step: PlanStep) -> tuple[int, PlanStep]:
            """Execute a single tool step with caching and timeout."""
            cache_key = self._cache_key(step.tool_name, step.params)
            cached = self._cache_get(cache_key)
            if cached is not None:
                step.status = "completed"
                step.result = cached
                step.duration = 0.0
                logger.info("Tool cache hit: %s", step.tool_name)
                return i, step

            async with _tool_semaphore:
                start = time.time()
                step_timeout = _resolve_step_timeout(step.tool_name)
                try:
                    step.status = "running"
                    self._snapshot.plan[i]["status"] = "running"
                    if self._should_submit_interactive_async_step(step):
                        result = await self._submit_interactive_async_step(
                            step,
                            current_user=current_user,
                            audit_session=audit_session,
                        )
                        step.status = "submitted"
                    else:
                        result = await asyncio.wait_for(
                            ToolRegistry.execute(step.tool_name, step.params),
                            timeout=step_timeout,
                        )
                        step.status = "completed"
                    step.result = result
                    step.duration = round(time.time() - start, 2)
                    if step.status == "completed":
                        self._cache_put(cache_key, result)
                except asyncio.TimeoutError:
                    step.status = "failed"
                    step.error = f"Step timed out after {step_timeout}s"
                    step.duration = round(time.time() - start, 2)
                except Exception as e:
                    step.status = "failed"
                    step.error = str(e)
                    step.duration = round(time.time() - start, 2)
                    # Retry once on transient errors
                    if self._should_retry(step):
                        try:
                            result = await asyncio.wait_for(
                                ToolRegistry.execute(step.tool_name, step.params),
                                timeout=step_timeout,
                            )
                            step.status = "completed"
                            step.result = result
                            step.error = None
                            self._cache_put(cache_key, result)
                        except Exception:
                            logger.exception("Retry failed for tool %s", step.tool_name)
            return i, step

        is_ordered_pipeline = self._requires_ordered_execution(plan)
        results: list[Any] = []
        completed_steps: list[PlanStep] = []
        structure_gate_failed = False
        structure_gate_error = ""
        if is_ordered_pipeline:
            for i, step in enumerate(plan):
                step = self._bridge_step_params(step, completed_steps)
                if step.tool_name in _IDENTITY_GATED_CANDIDATE_TOOLS and not self._identity_gate_passed(completed_steps):
                    step.status = "completed"
                    step.result = {
                        "status": "blocked",
                        "code": "IDENTITY_OR_NUMBERING_NOT_CONFIRMED",
                        "reason": (
                            "Candidate-generation tool was not run because enzyme family identity "
                            "or residue numbering was not confirmed by enzyme_identity_profile."
                        ),
                    }
                    step.duration = 0.0
                    self._snapshot.plan[i]["status"] = "completed"
                    completed_steps.append(step)
                    results.append((i, step))
                    continue
                if step.tool_name in _OBJECTIVE_GATED_CANDIDATE_TOOLS and not self._objective_gate_passed(completed_steps):
                    step.status = "completed"
                    step.result = {
                        "status": "blocked",
                        "code": "OBJECTIVE_MODULE_NOT_READY",
                        "reason": (
                            "Candidate-generation tool was not run because the objective-specific "
                            "module did not have the required assay/evidence context."
                        ),
                    }
                    step.duration = 0.0
                    self._snapshot.plan[i]["status"] = "completed"
                    completed_steps.append(step)
                    results.append((i, step))
                    continue
                if structure_gate_failed and self._is_structure_dependent_step(step.tool_name):
                    step.status = "failed"
                    step.error = (
                        "Skipped: uploaded/predicted structure gate did not pass; "
                        f"{structure_gate_error or 'structure evidence is unavailable or unconfirmed'}"
                    )
                    step.duration = 0.0
                    self._snapshot.plan[i]["status"] = "failed"
                    completed_steps.append(step)
                    results.append((i, step))
                    continue
                res = await _run_step(i, step)
                if not isinstance(res, Exception):
                    _, resolved_step = res
                    completed_steps.append(resolved_step)
                    if self._is_structure_gate_step(resolved_step.tool_name) and not self._structure_gate_passed(resolved_step):
                        structure_gate_failed = True
                        structure_gate_error = resolved_step.error or self._compact_result(
                            resolved_step.tool_name,
                            resolved_step.result,
                        )[:400]
                results.append(res)
        else:
            results = await asyncio.gather(
                *[_run_step(i, step) for i, step in enumerate(plan)],
                return_exceptions=True,
            )

        # Collect results in order and build tool_messages
        tool_messages = []
        for res in results:
            if isinstance(res, Exception):
                logger.error("Parallel step exception: %s", res)
                continue
            i, step = res
            self._snapshot.plan[i]["status"] = step.status
            self._snapshot.current_step = i + 1
            result_payload_dict = step.result if isinstance(step.result, dict) else self._safe_parse_json(str(step.result or ""))
            evidence_source = (
                result_payload_dict.get("evidence_source")
                if isinstance(result_payload_dict, dict) and isinstance(result_payload_dict.get("evidence_source"), dict)
                else None
            )
            self._snapshot.step_results.append({
                "step": i + 1, "tool": step.tool_name,
                "status": step.status,
                "result_preview": (self._compact_result(step.tool_name, step.result)[:2000] if step.result else step.error),
                "duration": step.duration,
                "evidence_source": evidence_source,
            })
            result_payload = self._compact_result(step.tool_name, step.result) if step.result else step.error
            tool_messages.append({
                "role": "tool",
                "tool_name": step.tool_name,
                "result": result_payload,
                "status": step.status,
            })

        yield self._emit_state()

        # --- Stage 4.5: SC REVIEW (multi-round iterative refinement) ---
        # MLEvolve-inspired: SC reviews results, may trigger supplementary tools,
        # records experience after each round. Up to MAX_REVIEW_ROUNDS iterations.
        # Smart review: skip for simple queries (≤3 tools), limit to 1 for moderate, 2 for complex
        num_tools = len(plan)
        if num_tools <= 3:
            MAX_REVIEW_ROUNDS = 0  # skip review entirely
        elif num_tools <= 6:
            MAX_REVIEW_ROUNDS = 1
        else:
            MAX_REVIEW_ROUNDS = 2
        execution_start = time.time()
        review_round = 0

        for review_round in range(1, MAX_REVIEW_ROUNDS + 1):
            self._snapshot.stage = "review"
            yield self._emit_state()

            review_result = await self._review_results_sc(
                user_message, tool_messages, self._snapshot.research_notes, model_id
            )

            # If SC is satisfied, break out of the loop
            if not review_result.get("needs_supplement"):
                break

            # If this is the last round, don't execute more supplements
            if review_round >= MAX_REVIEW_ROUNDS:
                logger.info("Max review rounds (%d) reached", MAX_REVIEW_ROUNDS)
                break

            # SC found gaps — execute supplementary tools
            has_sequence = bool(self._extract_sequence(user_message))
            has_pdb = any(
                "pdb" in str(r.get("result", "")).lower() and "ATOM" in str(r.get("result", ""))
                for r in tool_messages
            )

            for extra in review_result.get("supplementary_steps", []):
                tool_name = extra["tool_name"]
                if tool_name in self._extract_forbidden_tools(f"{user_message}\n{protein_context}".strip()):
                    tool_messages.append({
                        "role": "tool",
                        "tool_name": tool_name,
                        "result": f"Skipped: user explicitly forbade {tool_name}.",
                        "status": "skipped",
                    })
                    continue

                # Skip tools that need a sequence when none is available
                if not has_sequence and tool_name in _SEQUENCE_REQUIRED_TOOLS:
                    tool_messages.append({
                        "role": "tool",
                        "tool_name": tool_name,
                        "result": f"Skipped: no protein sequence available. Provide a sequence to use {tool_name}.",
                        "status": "skipped",
                    })
                    continue

                # Skip tools that need a PDB structure when none is available
                if not has_pdb and tool_name in _PDB_REQUIRED_TOOLS:
                    tool_messages.append({
                        "role": "tool",
                        "tool_name": tool_name,
                        "result": f"Skipped: no PDB structure available. Upload a PDB file or run structure prediction first.",
                        "status": "skipped",
                    })
                    continue
                extra_step = PlanStep(
                    id=len(plan) + 1,
                    tool_name=extra["tool_name"],
                    description=extra.get("description", f"Supplementary: {extra['tool_name']}"),
                    params=extra.get("params", {}),
                    status="running",
                )
                if self._should_submit_interactive_async_step(extra_step):
                    extra_step = self._normalize_interactive_async_params(extra_step)
                plan.append(extra_step)
                self._snapshot.plan.append({
                    "id": extra_step.id, "tool_name": extra_step.tool_name,
                    "description": extra_step.description, "params": extra_step.params,
                    "status": "running",
                })
                self._snapshot.current_step = extra_step.id
                yield self._emit_state()

                # Validate params: check required parameters exist for the tool
                tool_def = ToolRegistry.get_tool(extra_step.tool_name)
                if tool_def and tool_def.parameters:
                    required = tool_def.parameters.get("required", [])
                    missing = [p for p in required if p not in extra_step.params or not extra_step.params[p]]
                    if missing:
                        tool_messages.append({
                            "role": "tool",
                            "tool_name": extra_step.tool_name,
                            "result": f"Skipped: missing required parameters: {missing}",
                            "status": "skipped",
                        })
                        continue

                start = time.time()
                step_timeout = _resolve_step_timeout(extra_step.tool_name)
                try:
                    if self._should_submit_interactive_async_step(extra_step):
                        result = await self._submit_interactive_async_step(
                            extra_step,
                            current_user=current_user,
                            audit_session=audit_session,
                        )
                        extra_step.status = "submitted"
                    else:
                        result = await asyncio.wait_for(
                            ToolRegistry.execute(extra_step.tool_name, extra_step.params),
                            timeout=step_timeout,
                        )
                        extra_step.status = "completed"
                    extra_step.result = result
                    extra_step.duration = round(time.time() - start, 2)
                    idx = extra_step.id - 1
                    self._snapshot.plan[idx]["status"] = extra_step.status
                    self._snapshot.step_results.append({
                        "step": extra_step.id, "tool": extra_step.tool_name,
                        "status": extra_step.status, "result_preview": self._compact_result(extra_step.tool_name, result)[:2000],
                        "duration": extra_step.duration,
                    })
                    tool_messages.append({
                        "role": "tool",
                        "tool_name": extra_step.tool_name,
                        "result": self._compact_result(extra_step.tool_name, result),
                        "status": extra_step.status,
                    })
                except asyncio.TimeoutError:
                    extra_step.status = "failed"
                    extra_step.error = f"Step timed out after {step_timeout}s"
                    extra_step.duration = round(time.time() - start, 2)
                    idx = extra_step.id - 1
                    self._snapshot.plan[idx]["status"] = "failed"
                    tool_messages.append({
                        "role": "tool",
                        "tool_name": extra_step.tool_name,
                        "result": extra_step.error,
                        "status": "failed",
                    })
                except Exception as e:
                    extra_step.status = "failed"
                    extra_step.error = str(e)
                    idx = extra_step.id - 1
                    self._snapshot.plan[idx]["status"] = "failed"
                    tool_messages.append({
                        "role": "tool",
                        "tool_name": extra_step.tool_name,
                        "result": str(e)[:500],
                        "status": "failed",
                    })

            yield self._emit_state()

        # Record experience after execution (before synthesis)
        total_duration = time.time() - execution_start
        await self._record_experience(
            user_message, route, plan, tool_messages,
            self._snapshot.research_notes, total_duration, round_number=review_round,
        )

        # --- Stage 5: SYNTHESIZE (SC) ---
        self._snapshot.stage = "synthesize"
        yield self._emit_state()
        final_report = await self._synthesize_sc(
            user_message, tool_messages, self._snapshot.research_notes, history, model_id
        )
        self._snapshot.final_report = final_report
        self._snapshot.stage = "done"
        yield self._emit_state()

        # Stream final report as text tokens
        for chunk in self._iter_text_stream_chunks(final_report):
            yield json.dumps({"type": "text", "content": chunk}, ensure_ascii=False)

        yield json.dumps({"type": "done"})

    async def _record_experience(
        self, user_message: str, task_type: str, plan: list, tool_messages: list[dict],
        research_notes: str, total_duration: float, round_number: int = 1,
    ) -> None:
        """Record this execution as an experience for future reference."""
        try:
            store, ExperienceRecord = _get_experience_store()
            sequence = self._extract_sequence(user_message) or ""
            protein_name = self._extract_protein_name(user_message)

            # Determine task type from route
            pipeline = [step.tool_name for step in plan]
            completed = sum(1 for m in tool_messages if m["status"] == "completed")
            total = len(tool_messages) if tool_messages else 1

            record = ExperienceRecord(
                task_type=task_type,
                protein_family=protein_name or "unknown",
                sequence_hash=ExperienceRecord.hash_sequence(sequence),
                pipeline=pipeline,
                pipeline_hash=ExperienceRecord.hash_pipeline(pipeline),
                step_results={m["tool_name"]: m["status"] for m in tool_messages},
                success_rate=completed / total,
                total_duration=total_duration,
                user_message_short=user_message[:100],
                research_notes_short=research_notes[:200],
                round_number=round_number,
            )
            await store.record(record)
        except Exception:
            logger.debug("Failed to record experience")

    async def _get_experience_hints(self, user_message: str, task_type: str) -> str:
        """Query past experiences for planning hints."""
        try:
            store, _ = _get_experience_store()
            protein_name = self._extract_protein_name(user_message)
            sequence = self._extract_sequence(user_message) or ""

            experiences = await store.search_similar(
                task_type=task_type,
                protein_family=protein_name or "",
                sequence=sequence,
                top_k=3,
            )
            if not experiences:
                return ""

            lines = ["Past execution experiences for similar tasks:"]
            for exp in experiences:
                status = "✓" if exp.success_rate >= 0.8 else "⚠"
                lines.append(
                    f"- {status} Pipeline [{', '.join(exp.pipeline[:5])}...] "
                    f"({exp.success_rate:.0%} success, {exp.total_duration:.0f}s)"
                )
            best = await store.get_best_pipeline(task_type, protein_name or "")
            if best:
                lines.append(f"Recommended pipeline: {' → '.join(best)}")
            return "\n".join(lines)
        except Exception:
            logger.debug("Experience query failed")
            return ""

    def _emit_state(self) -> str:
        """Emit full state snapshot as JSON (sse-starlette handles SSE framing)."""
        if self._snapshot is None:
            return ""
        return json.dumps({
            "type": "state",
            "stage": self._snapshot.stage,
            "plan": self._snapshot.plan,
            "current_step": self._snapshot.current_step,
            "step_results": self._snapshot.step_results,
            "research_notes": self._snapshot.research_notes[:200],
            "waiting_for": self._snapshot.waiting_for,
        }, ensure_ascii=False)

    # --- Role Implementations ---

    async def _route_intent(self, message: str, context: str, model_id: str | None = None) -> str:
        """Router: classify user intent into workflow type."""
        lower = message.lower()

        # Deterministic overrides for common patterns
        if self._is_model_meta_question(message, context):
            return "general"
        design_intent = (
            any(kw in lower for kw in [
                "binder", "de novo", "backbone", "scaffold", "生成序列", "generate sequence",
                "结合蛋白", "蛋白设计", "从头设计", "骨架设计",
            ])
            or ("design" in lower and any(kw in lower for kw in ["protein", "binder", "sequence", "backbone", "scaffold"]))
            or ("设计" in lower and any(kw in lower for kw in ["蛋白", "序列", "骨架", "结合"]))
        )
        if design_intent:
            return "design"
        has_explicit_reference = bool(
            self._extract_named_protein_reference(message)
            or self._extract_uniprot_reference(message)
            or self._extract_pdb_id_reference(message)
        )
        if has_explicit_reference and any(kw in lower for kw in [
            "目标", "提高", "降低", "分析", "改造", "优化", "稳定性", "热", "酸", "碱",
            "ph", "activity", "stability", "improve", "optimize", "engineer",
        ]):
            return "analyze"
        if has_explicit_reference:
            return "research"
        if self._extract_attached_object_name(message) and any(kw in lower for kw in [
            "上传", "结构", "pdb", "object_name", "uploaded", "structure",
        ]) and "附件" not in lower:
            return "research"
        if re.search(r"\b[ACDEFGHIKLMNPQRSTVWY][0-9]{1,5}[ACDEFGHIKLMNPQRSTVWY]\b", message, re.IGNORECASE):
            return "analyze"
        if any(kw in lower for kw in ["突变", "mutation", "mutant", "variant", "ddg"]):
            return "analyze"
        if any(kw in lower for kw in ["对接", "docking", "dock", "结合", "binding"]):
            return "analyze"
        if any(kw in lower for kw in ["ph", "酸性", "碱性", "最适", "酶活", "活性", "engineering", "改造",
                                        "stability", "stabilize", "catalytic", "substrate", "kcat", "km",
                                        "specificity", "optimum", "耐酸", "耐碱", "耐热", "热稳定", "稳定性"]):
            return "analyze"
        if any(kw in lower for kw in ["结构", "structure", "fold", "pdb", "预测结构"]):
            return "research"
        if any(kw in lower for kw in ["性质", "property", "properties", "理化", "predict", "预测", "analyze", "分析"]):
            return "analyze"
        if any(kw in lower for kw in ["ec", "酶功能", "enzyme function", "classify", "分类", "ec number"]):
            return "research"
        if any(kw in lower for kw in ["kcat", "km", "turnover", "动力学", "kinetics", "催化效率", "催化速率"]):
            return "analyze"
        if any(kw in lower for kw in [
            "搜索", "search", "blast", "查找", "find", "查一下", "查询", "检索",
            "文献", "literature", "evidence", "证据",
        ]):
            return "research"

        # Messages with protein sequences → analyze or research
        if self._extract_sequence(message):
            return "analyze"

        # Short messages without protein context → general chat
        protein_kw = ["protein", "蛋白", "sequence", "序列", "peptide", "residue",
                      "amino", "mutation", "structure", "docking", "binder"]
        has_protein_context = any(kw in lower for kw in protein_kw)
        if not has_protein_context and len(message.split()) < 15:
            return "general"

        # LLM-based routing for ambiguous queries
        skills_hint = "\n".join([
            f"- {s['name']}: {s['description'][:80]}"
            for s in self.skills_metadata[:5]
        ])

        try:
            resp = await self._call_llm([
                {"role": "system", "content": ROUTER_SYSTEM_PROMPT.format(skills=skills_hint)},
                {"role": "user", "content": message},
            ], model_id=model_id, max_tokens=10)
            route = (resp.choices[0].message.content or "general").strip().lower()
            if route in ("design", "research", "analyze", "general"):
                return route
        except Exception:
            logger.exception("Router LLM call failed")
        return "general"

    async def _get_knowledge_context(self, message: str, task_type: str = "research") -> str:
        """Gather knowledge context via Coordinator (parallel Data + Literature agents).

        Replaces the old inline sequential queries. The Coordinator runs:
        1. DataAgent — enzyme knowledge graph + ESM-2 vector search
        2. LiteratureAgent — PubMed/Europe PMC + ChromaDB RAG + experience memory
        Both agents run in parallel with a shared timeout.

        Returns a combined context string for injection into PI/SC prompts.
        Gracefully degrades if any source is unavailable.
        """
        result = await self._coordinator.gather(message, task_type=task_type)
        return result.context

    async def _research_pi(
        self, message: str, history: list[dict], context: str,
        model_id: str | None = None,
        task_type: str = "research",
    ) -> str:
        """PI: Research phase — gather background, clarify requirements."""
        # Gather knowledge graph + literature + vector search context (via Coordinator)
        knowledge_context = await self._get_knowledge_context(message, task_type=task_type)

        user_content = f"Task: {message}\nProtein context: {context}"
        if knowledge_context:
            user_content += f"\n\n{knowledge_context}"

        messages = [
            {"role": "system", "content": PI_SYSTEM_PROMPT},
            *history[-6:],  # Last 3 turns for context
            {"role": "user", "content": user_content},
        ]
        try:
            resp = await self._call_llm(messages, model_id=model_id, max_tokens=600)
            return resp.choices[0].message.content or ""
        except Exception:
            logger.exception("PI research LLM call failed")
            return ""

    async def _plan_cb(
        self, message: str, research: str, history: list[dict],
        model_id: str | None = None,
        context: str = "",
        analysis_depth: str = "standard",
    ) -> list[PlanStep]:
        """CB: Planning phase — create tool execution plan."""
        skills_text = "\n".join([
            f"- {s['name']}: {s['description']}"
            for s in self.skills_metadata
        ])
        tools_text = "\n".join([
            f"- {t['function']['name']}: {t['function']['description']}"
            for t in (self.tools_schema or [])
        ])

        # Extract sequence from message to help the LLM fill params
        seq = self._extract_sequence(message)
        seq_hint = f"\n\nDetected protein sequence: {seq}" if seq else ""

        plan_prompt = CB_SYSTEM_PROMPT.format(
            skills=skills_text,
            tools=tools_text,
            research=research,
            task=message + seq_hint,
        )

        messages = [
            {"role": "system", "content": plan_prompt},
            *history[-4:],
            {"role": "user", "content": f"Create a step-by-step tool execution plan for: {message}"},
        ]

        # Query past experiences for planning hints (MLEvolve retrospective memory)
        # Infer task type from message keywords (same logic as router)
        lower = message.lower()
        if any(kw in lower for kw in ["design", "binder", "de novo", "backbone", "scaffold"]):
            task_type_hint = "design"
        elif any(kw in lower for kw in ["mutat", "stability", "engineer", "optim", "enhanc"]):
            task_type_hint = "analyze"
        else:
            task_type_hint = "research"
        await self._get_experience_hints(message, task_type_hint)

        # Use deterministic fallback plan — LLM-generated plans are unreliable for now
        # (wrong parameter names, missing essential steps). The fallback covers all
        # common enzyme engineering tasks with correct tool params.
        return self._generate_fallback_plan(message, context=context, analysis_depth=analysis_depth)

    def _parse_plan(self, response: Any, task: str) -> list[PlanStep]:
        """Parse CB's response into structured PlanSteps."""
        steps = []
        msg = response.choices[0].message

        # If LLM returned tool calls, use them directly
        if hasattr(msg, 'tool_calls') and msg.tool_calls:
            for i, tc in enumerate(msg.tool_calls):
                try:
                    params = json.loads(tc.function.arguments) if isinstance(
                        tc.function.arguments, str
                    ) else tc.function.arguments
                except (json.JSONDecodeError, TypeError):
                    params = {}
                steps.append(PlanStep(
                    id=i + 1,
                    tool_name=tc.function.name,
                    description=f"Execute {tc.function.name}",
                    params=params,
                ))
            return self._apply_tool_constraints(steps, task)

        # Otherwise extract from text
        content = msg.content or ""
        # Look for JSON plan blocks
        if "```json" in content:
            try:
                json_str = content.split("```json")[1].split("```")[0].strip()
                plan_data = json.loads(json_str)
                if isinstance(plan_data, list):
                    for i, step_data in enumerate(plan_data):
                        steps.append(PlanStep(
                            id=i + 1,
                            tool_name=step_data.get("tool", step_data.get("tool_name", "")),
                            description=step_data.get("description", ""),
                            params=step_data.get("params", {}),
                        ))
                    return self._apply_tool_constraints(steps, task)
            except (json.JSONDecodeError, IndexError):
                pass

        return self._generate_fallback_plan(task)

    def _generate_fallback_plan(self, task: str, context: str = "", analysis_depth: str = "standard") -> list[PlanStep]:
        """Generate the deterministic tool plan for enzyme/protein analysis.

        This is the fallback when the LLM fails to produce a valid plan. Enzyme
        engineering follows the platform's manual analysis flow: validate input,
        acquire or summarize structure status, build a minimal enzyme profile,
        then route objective-specific deep analysis and candidate ranking.
        Slow external tools such as BLAST and MD are still opt-in.
        """
        core_fallback_tools = {"predict_properties", "sequence_search", "esmfold_folding"}
        if not core_fallback_tools.issubset(ToolRegistry._tools):
            ToolRegistry.discover()

        steps = []
        combined_task = f"{task}\n{context}".strip()
        lower = combined_task.lower()
        analysis_depth = (analysis_depth or "standard").strip().lower()
        if analysis_depth not in {"fast", "standard", "deep"}:
            analysis_depth = "standard"
        depth_allows_slow = analysis_depth == "deep"
        tool_names = set(ToolRegistry._tools.keys())
        seq = self._extract_sequence(combined_task) or ""
        pdb_object_name = self._extract_attached_object_name(combined_task)
        requested_positions = self._extract_requested_positions(combined_task)
        if self._task_requests_no_tools(combined_task):
            return []
        if self._is_governance_evidence_request(combined_task) and "external_research_evidence" in tool_names:
            return [PlanStep(
                1,
                "external_research_evidence",
                "Read audited local training, model-claim, customer-delivery, and release evidence",
                {"scope": "all"},
            )]
        if self._wants_live_literature_search(combined_task) and "literature_live_search" in tool_names:
            return [PlanStep(
                1,
                "literature_live_search",
                "Search live PubMed and Crossref literature evidence for the user's query",
                {"query": self._clean_literature_query(combined_task), "max_results": 8},
            )]

        # Detect enzyme engineering intent
        is_enzyme_eng = any(kw in lower for kw in [
            "enzyme", "酶", "ph", "酸性", "碱性", "最适", "酶活", "engineering", "改造",
            "mutation", "stability", "stabilize", "activity", "catalytic",
            "substrate", "kcat", "km", "specificity", "optimum",
            "耐酸", "耐碱", "耐热", "热稳定", "比活力",
        ])

        objectives = self._classify_engineering_objectives(combined_task)
        eng_goal = self._primary_engineering_goal(objectives)

        # Detect binder / de novo protein design intent
        is_binder_design = any(kw in lower for kw in [
            "binder", "bind", "de novo", "backbone", "scaffold",
            "design a", "design binder", "结合蛋白", "蛋白设计",
            "从头设计", "骨架设计", "设计蛋白",
        ])
        wants_deep = depth_allows_slow or any(kw in lower for kw in [
            "deep", "deep analysis", "comprehensive", "full report", "full pipeline",
            "深入", "深度", "全面", "完整", "全量", "完整版", "详细报告",
        ])
        wants_quick = analysis_depth == "fast" or any(kw in lower for kw in [
            "quick", "fast", "rapid", "screen", "summary",
            "快速", "尽快", "先粗筛", "先给结论", "简要", "摘要",
        ])
        wants_structure = any(kw in lower for kw in [
            "structure", "fold", "folding", "pdb", "3d", "surface", "active site",
            "结构", "折叠", "三维", "pdb", "表面", "活性位点",
        ])
        wants_blast = any(kw in lower for kw in [
            "blast", "homolog", "homology", "conservation", "family", "motif",
            "同源", "保守", "家族", "模体", "比对",
        ])
        wants_md = any(kw in lower for kw in [
            "gromacs", "md", "molecular dynamics", "rmsd", "rmsf", "flexibility",
            "分子动力学", "动力学", "柔性", "波动", "rmsd", "rmsf",
        ])
        wants_scan = any(kw in lower for kw in [
            "scan", "saturation", "alanine", "all mutations", "systematic scan",
            "扫描", "全位点", "饱和突变", "丙氨酸扫描", "系统扫描",
        ])
        wants_variant_scoring = any(kw in lower for kw in [
            "protssn", "variant effect", "effect score", "突变效应", "效应评分",
        ])
        wants_rosetta_ddg = any(kw in lower for kw in [
            "rosetta", "ddg", "Δδg", "δδg", "delta delta g", "cartesian_ddg",
            "稳定能量", "突变能量", "负值", "正值", "更稳定", "不稳定",
        ])
        wants_kinetics = any(kw in lower for kw in [
            "kcat", "km", "kinetics", "activity", "specificity",
            "酶活", "活性", "比活", "动力学", "特异性",
        ])

        has_sequence = len(seq) >= 10
        step_id = 0

        if pdb_object_name:
            if "structure_search_foldseek" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "structure_search_foldseek",
                    "Parse and summarize the uploaded experimental structure before any structure-dependent analysis",
                    {
                        "pdb_object_name": pdb_object_name,
                        "database": "pdb",
                        "max_results": 5,
                    }))
            if "residue_mapping_sifts" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "residue_mapping_sifts",
                    "Build a residue numbering map for the uploaded structure before projecting positions or structural claims",
                    {
                        "pdb_object_name": pdb_object_name,
                    }))
            if requested_positions and "residue_numbering_gate" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "residue_numbering_gate",
                    "Validate requested residue numbering before using residue-level structure claims",
                    {
                        "requested_positions": requested_positions,
                        "user_confirmed": False,
                    }))

        # --- Binder Design Pipeline (with sequence) ---
        if has_sequence and is_binder_design:
            # 1. Inverse folding — redesign sequence for the given backbone
            if "proteinmpnn_design" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "proteinmpnn_design",
                    "Inverse folding: design novel sequences that stably fold into the target backbone",
                    {"temperature": 0.1, "num_sequences": 3}))

            # 2. Solubility optimization
            if "soluble_mpnn_design" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "soluble_mpnn_design",
                    "Optimize designed sequences for solubility and expression",
                    {"sequence": seq}))

            # 3. Structure validation — verify designed sequences fold correctly
            if "esmfold_folding" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "esmfold_folding",
                    "Validate folding of designed sequences — high pLDDT confirms stable backbone",
                    {"sequence": seq}))

            # 4. Physicochemical baseline
            if "predict_properties" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "predict_properties",
                    "Compute MW, pI, stability, GRAVY for designed sequences",
                    {"sequence": seq}))

            return self._apply_tool_constraints(steps, task, context)

        if has_sequence:
            # Follow the manual enzyme analysis flow: basic sequence validation,
            # structure status, minimal enzyme profile, then objective-specific tools.
            # Only external/long-running tools such as BLAST and MD remain opt-in.
            quick_mode = wants_quick or not wants_deep
            run_structure = is_enzyme_eng or wants_deep or wants_structure
            run_blast = wants_deep or wants_blast
            run_scan = wants_deep or wants_scan
            run_md = wants_deep or wants_md
            run_protssn = wants_deep or wants_variant_scoring
            run_kinetics = wants_deep or wants_kinetics

            # 1. Physicochemical properties — baseline metrics (instant)
            if "predict_properties" in tool_names:
                prop_subset = None
                if objectives & {"thermostability", "ph_lowering", "ph_raising"}:
                    prop_subset = ["molecular_weight", "isoelectric_point", "instability_index", "gravy", "secondary_structure"]
                elif "solubility" in objectives and objectives.isdisjoint({"activity", "specificity", "thermostability", "ph_lowering", "ph_raising"}):
                    prop_subset = ["gravy", "instability_index", "disorder", "amino_acid_composition"]
                params = {"sequence": seq}
                if prop_subset:
                    params["properties"] = prop_subset
                step_id += 1
                steps.append(PlanStep(step_id, "predict_properties",
                    "Compute objective-relevant physicochemical sequence features",
                    params))

            run_family_context = is_enzyme_eng or wants_deep or wants_blast or bool(objectives & {"activity", "specificity"})
            annotation_uniprot_id = self._extract_uniprot_reference(combined_task)

            # 3. Curated annotation evidence — family/function/site data must be
            # resolved before the profile translates them into engineering guardrails.
            if "annotation_bundle" in tool_names and is_enzyme_eng:
                step_id += 1
                annotation_params = {"sequence": seq}
                if annotation_uniprot_id:
                    annotation_params["uniprot_id"] = annotation_uniprot_id
                steps.append(PlanStep(step_id, "annotation_bundle",
                    "Resolve curated family/domain, EC, catalytic-site, cofactor, and signal-peptide evidence before engineering",
                    annotation_params))

            # 4. Identity profile — gate family / key residues before ranking and function calls
            if "enzyme_identity_profile" in tool_names and is_enzyme_eng:
                step_id += 1
                profile_params = {"sequence": seq}
                if annotation_uniprot_id:
                    profile_params["uniprot_id"] = annotation_uniprot_id
                steps.append(PlanStep(step_id, "enzyme_identity_profile",
                    "Identify enzyme family, catalytic motifs, protected residues, and numbering guardrails before candidate ranking",
                    profile_params))

            # 4.5. Objective module gate — separates thermostability, activity,
            # specificity, pH, and expression evidence before candidate tables.
            if "enzyme_objective_module_plan" in tool_names and is_enzyme_eng:
                step_id += 1
                steps.append(PlanStep(step_id, "enzyme_objective_module_plan",
                    "Gate the objective-specific module and decide whether mutation candidate output is allowed",
                    {
                        "objective": eng_goal,
                        "assay_context": self._extract_assay_context(combined_task),
                    }))

            # 5. Protein benchmark — minimal family/motif/catalytic profile before target-specific claims
            if "protein_benchmark" in tool_names and is_enzyme_eng and run_family_context:
                step_id += 1
                steps.append(PlanStep(step_id, "protein_benchmark",
                    "Characterize enzyme family, motifs, catalytic residues, and conserved constraints relevant to the objective",
                    {"query_sequence": seq}))

            # 6. Enzyme function prediction — minimal EC/function profile for all enzyme engineering targets
            if is_enzyme_eng and "enzyme_function" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "enzyme_function",
                    "Predict EC number and enzyme class from sequence using curated motifs and ESM-2 embeddings",
                    {"sequence": seq}))

            # 7. Structure prediction follows the identity/function foundation.
            # It is required before pocket/exposure/network interpretation, not
            # before sequence-based retrieval and catalytic-site mapping.
            if run_structure and not pdb_object_name and "esmfold_folding" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "esmfold_folding",
                    "Predict 3D structure for subsequent pocket, exposure, and catalytic-network interpretation",
                    {"sequence": seq}))

            # 8. Mutation priority scoring — target-specific residue ranking
            run_priority = is_enzyme_eng and (
                bool(objectives & {
                    "thermostability",
                    "ph_lowering",
                    "ph_raising",
                    "activity",
                    "specificity",
                })
                or wants_deep
                or any(kw in lower for kw in ["突变", "mutation", "mutant", "variant", "位点", "residue"])
            )
            if run_priority and "mutation_priority_score" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "mutation_priority_score",
                    f"Score residues for {eng_goal} engineering and rank Tier 1/2 candidates",
                    {"sequence": seq, "engineering_goal": eng_goal}))

            requested_mutations = self._extract_requested_mutations(combined_task)
            if requested_mutations and wants_rosetta_ddg and "rosetta_ddg" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "rosetta_ddg",
                    "Calculate mutation ΔΔG with Rosetta when runtime is available; otherwise return a blocked/runtime contract",
                    {
                        "sequence": seq,
                        "mutations": requested_mutations,
                        "pdb_object_name": pdb_object_name,
                        "allow_local_estimate": False,
                    }))

            # 6. Enzyme kinetics prediction — activity-focused only unless deep mode asks for all context
            if is_enzyme_eng and (
                "activity" in objectives
                or wants_deep
                or (run_kinetics and "specificity" not in objectives)
            ) and "kcat_predict" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "kcat_predict",
                    "Predict enzyme turnover number (Kcat) and catalytic efficiency",
                    {"protein_sequence": seq}))

            # 7. Residue scan — default for activity/specificity redesign, explicit/deep otherwise
            if (run_scan or bool(objectives & {"activity", "specificity"})) and "mutation_scan" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "mutation_scan",
                    "Scan substitutions around candidate residues for activity/specificity engineering",
                    {"sequence": seq, "scan_type": "saturation" if wants_deep else "alanine"}))

            # 8. Solubility/expression design — only for soluble-expression objectives
            if "solubility" in objectives and "soluble_mpnn_design" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "soluble_mpnn_design",
                    "Redesign sequence positions for soluble expression and lower aggregation propensity",
                    {"sequence": seq, "mode": "soluble", "temperature": 0.1}))

            # 9. ML-enhanced mutation scoring — only when explicitly requested or deep mode
            if is_enzyme_eng and run_protssn and "protssn_score" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "protssn_score",
                    "ML-enhanced mutation scoring with sequence-structure fusion for higher accuracy",
                    {"sequence": seq, "mutations": []}))

            # 10. BLAST search — external and slow; do not run by default in quick mode
            if run_blast and "blast_search" in tool_names:
                blast_db = "swissprot"
                blast_hits = 3 if quick_mode and not wants_deep else 5
                step_id += 1
                steps.append(PlanStep(step_id, "blast_search",
                    "Identify enzyme family homologs and conserved residues via BLAST (external NCBI)",
                    {"sequence": seq, "database": blast_db, "max_results": blast_hits}))

            # 11. MD simulation — never run by default on the chat fast path
            if run_md and "gromacs_md" in tool_names and pdb_object_name:
                md_ns = 1.0 if quick_mode and not wants_deep else 10.0
                step_id += 1
                steps.append(PlanStep(step_id, "gromacs_md",
                    "Submit a molecular dynamics job for stability and flexibility review",
                    {
                        "sequence": seq,
                        "pdb_object_name": pdb_object_name,
                        "simulation_time_ns": md_ns,
                        "replicate_plan_only": False,
                        "upload_artifacts": True,
                    }))

        if (
            pdb_object_name
            and (wants_deep or wants_md)
            and "gromacs_md" in tool_names
            and not any(step.tool_name == "gromacs_md" for step in steps)
        ):
            step_id += 1
            steps.append(PlanStep(step_id, "gromacs_md",
                "Submit a molecular dynamics job from the attached structure",
                {
                    "pdb_object_name": pdb_object_name,
                    "simulation_time_ns": 1.0 if wants_quick and not wants_deep else 10.0,
                    "replicate_plan_only": False,
                    "upload_artifacts": True,
                }))

        # If no sequence, try to extract a protein name and search for it
        if not steps:
            if pdb_object_name:
                return self._apply_tool_constraints(steps, task, context)
            has_lookup_target = self._has_concrete_protein_input(task, context)
            search_query, search_database = self._extract_lookup_target(task) if has_lookup_target else ("", "uniprot")

            # --- Binder Design Pipeline (no sequence) ---
            if is_binder_design:
                if not has_lookup_target:
                    return self._apply_tool_constraints(steps, task, context)
                # 1. Search for target protein sequence
                if "sequence_search" in tool_names:
                    step_id += 1
                    steps.append(PlanStep(step_id, "sequence_search",
                        f"Search for target protein: {search_query}",
                        {"query": search_query, "database": search_database, "max_results": 5}))

                # 2. RFdiffusion — generate binder backbone scaffolds
                if "rfdiffusion_design" in tool_names:
                    step_id += 1
                    steps.append(PlanStep(step_id, "rfdiffusion_design",
                        f"Generate de novo binder backbone scaffolds targeting {search_query}",
                        {"target": "binder", "length": 100, "num_designs": 3}))

                # 3. Chroma — joint structure-sequence generation
                if "chroma_design" in tool_names:
                    step_id += 1
                    steps.append(PlanStep(step_id, "chroma_design",
                        "Joint structure-sequence generation for binder design",
                        {"length": 100, "num_designs": 3, "target_shape": "binder-like globular scaffold"}))

                # 4. ProteinMPNN — inverse folding on generated backbones
                if "proteinmpnn_design" in tool_names:
                    step_id += 1
                    steps.append(PlanStep(step_id, "proteinmpnn_design",
                        "Inverse folding: design sequences for generated binder backbones",
                        {"temperature": 0.1, "num_sequences": 3}))

                # 5. ESMFold — validate folding of designed sequences
                if "esmfold_folding" in tool_names:
                    step_id += 1
                    steps.append(PlanStep(step_id, "esmfold_folding",
                        "Validate designed binder sequences fold into intended backbone",
                        {}))

                return self._apply_tool_constraints(steps, task, context)

            # Generic fallback: search for protein sequence
            if has_lookup_target and "sequence_search" in tool_names:
                step_id += 1
                steps.append(PlanStep(step_id, "sequence_search",
                    f"Search for protein/gene: {search_query}",
                    {"query": search_query, "database": search_database, "max_results": 5}))

        return self._apply_tool_constraints(steps, task, context)

    @staticmethod
    def _extract_protein_name(task: str) -> str:
        """Extract a likely protein/gene name from a natural language query.

        Handles patterns like:
        - "Design a binder for PD-L1" → "PD-L1"
        - "Analyze the structure of EGFR" → "EGFR"
        - "What is the sequence of human p53" → "p53"
        """
        named = AgentOrchestrator._extract_named_protein_reference(task)
        if named:
            return named
        uniprot_id = AgentOrchestrator._extract_uniprot_reference(task)
        if uniprot_id:
            return uniprot_id
        pdb_id = AgentOrchestrator._extract_pdb_id_reference(task)
        if pdb_id:
            return pdb_id

        # Common prefixes that introduce a protein name (case-insensitive)
        prefix_str = (
            r'(?i:design|bind(?:er)?|for|target(?:ing)?|against|of|on|about|analy[sz]e|study|'
            r'investigate|engineer|mutate|optimize|improve|enhance|modify|evolve|screen)\s+'
            r'(?:a\s+|an\s+|the\s+)?'
            r'(?:(?:high|low)[\s-]*(?:affinity|specificity)\s+)?'
            r'(?:protein\s+|enzyme\s+|binder\s+)?'
            r'(?:for\s+|of\s+|to\s+|against\s+|targeting\s+)?'
        )
        # Protein/gene name pattern: UPPERCASE letters, numbers, hyphens (case-sensitive)
        protein_pattern = r'([A-Z][A-Z0-9]+(?:[-/][A-Z0-9]+)*)'

        # Try to find protein names after prefix patterns
        match = re.search(prefix_str + protein_pattern, task)
        if match:
            name = match.group(1).strip()
            if len(name) >= 2:
                return name

        # Fallback: find any uppercase identifier (2-15 chars) in the text
        matches = re.findall(r'\b([A-Z][A-Z0-9]+(?:[-/][A-Z0-9]+)*)\b', task)
        if matches:
            # Prefer longer matches and exclude common English words
            english_upper = {'A', 'I', 'THE', 'IS', 'ARE', 'BE', 'DO', 'FOR', 'AND', 'NOT', 'BUT', 'OR', 'NOR', 'SO', 'YET', 'THIS'}
            candidates = [m for m in matches if m.upper() not in english_upper and len(m) >= 2]
            if candidates:
                return max(candidates, key=len)

        # Last resort: use a cleaned version of the query
        return task[:150]

    async def _review_results_sc(
        self, task: str, tool_results: list[dict], research: str,
        model_id: str | None = None,
    ) -> dict:
        """SC Review: critically examine tool results and identify gaps.

        Returns a dict with:
          - needs_supplement: bool — whether additional tools are needed
          - supplementary_steps: list[dict] — extra tool calls to make
          - critique: str — brief assessment of what's missing
        """
        results_text = "\n".join([
            f"- {r['tool_name']}: {r['status']} | {str(r.get('result', ''))[:200]}"
            for r in tool_results
        ])

        tools_list = "\n".join([
            f"- {t['function']['name']}: {t['function']['description'][:120]}"
            for t in (self.tools_schema or [])[:25]
        ])

        review_prompt = (
            "You are the Scientific Critic (SC) of a protein engineering team. "
            "Your job is to CRITICALLY examine the tool execution results and determine "
            "if they are sufficient to answer the user's question with SPECIFIC, actionable recommendations.\n\n"
            f"User task: {task}\n\n"
            f"Research notes: {research[:300]}\n\n"
            "Tool execution results so far:\n"
            f"{results_text}\n\n"
            "Available additional tools:\n"
            f"{tools_list}\n\n"
            "CRITICAL ASSESSMENT CRITERIA:\n"
            "1. If the task involves enzyme engineering (pH, stability, activity, mutation design):\n"
            "   - Do we know the enzyme FAMILY and catalytic MECHANISM?\n"
            "   - Do we have SPECIFIC residue numbers to recommend (not just generic regions)?\n"
            "   - Do we have a 3D structure or structural model to reason about?\n"
            "   - Have we identified which residues MUST NOT be mutated?\n"
            "2. If the task involves protein analysis:\n"
            "   - Do we have quantitative results with proper units?\n"
            "   - Are there benchmarks or comparisons to known proteins?\n"
            "3. If the task involves binder / de novo protein design:\n"
            "   - Were backbone scaffolds generated (rfdiffusion/chroma)?\n"
            "   - Do we have designed sequences with inverse folding (proteinmpnn)?\n"
            "   - Are folding validation results available (esmfold pLDDT > 70)?\n"
            "   - Is sequence diversity and recovery rate reported?\n\n"
            "Respond with a JSON object:\n"
            '{"needs_supplement": true/false,'
            ' "critique": "one-line assessment of gap",'
            ' "supplementary_steps": ['
            '   {"tool_name": "tool_name", "description": "...", "params": {...}}'
            ' ]}\n\n'
            "Only request supplementary tools if they would SIGNIFICANTLY improve the answer. "
            "If results are already comprehensive, set needs_supplement: false and leave steps empty. "
            "Request at most 3 supplementary steps."
        )

        try:
            resp = await self._call_llm(
                [{"role": "system", "content": review_prompt}],
                model_id=model_id, max_tokens=400,
            )
            content = resp.choices[0].message.content or ""
            # Extract JSON
            json_match = re.search(r'\{[\s\S]*\}', content)
            if json_match:
                parsed = self._safe_parse_json(json_match.group())
                if isinstance(parsed, dict) and parsed:
                    return parsed
                logger.warning("SC review returned non-parseable JSON payload: %s", content[:500])
        except Exception:
            logger.exception("SC review JSON parse failed")

        return {"needs_supplement": False, "supplementary_steps": [], "critique": ""}

    async def _synthesize_sc(
        self, task: str, tool_results: list[dict], research: str, history: list[dict],
        model_id: str | None = None,
    ) -> str:
        """SC: Synthesize phase — validate and create final report."""
        if self._tool_results_have_no_evidence(tool_results):
            return self._build_no_evidence_reply(task, tool_results)
        if self._has_plan_only_md_result(tool_results):
            return self._build_fallback_report(task, tool_results)

        results_text = "\n".join([
            f"Step {i+1}: {r['tool_name']} → {r['status']}\n{self._format_tool_result_for_synthesis(r)}"
            for i, r in enumerate(tool_results)
        ])
        no_hit_context = self._structure_no_hit_synthesis_context(tool_results)
        evidence_context = self._evidence_lineage_synthesis_context(tool_results)
        claim_audit_context = self._claim_audit_synthesis_context(tool_results)

        # Inject relevant domain skill content for deeper synthesis
        domain_context = self._load_relevant_skills(task)

        # Inject knowledge graph + literature context for synthesis
        knowledge_context = await self._get_knowledge_context(task)

        system_content = SC_SYSTEM_PROMPT + domain_context
        if knowledge_context:
            system_content += f"\n\n{knowledge_context}"

        messages = [
            {"role": "system", "content": system_content},
            *history[-4:],
            {"role": "user", "content": (
                f"Task: {task}\n\n"
                f"Research notes: {research[:500]}\n\n"
                f"Tool results:\n{results_text}\n\n"
                f"{no_hit_context}"
                f"{evidence_context}"
                f"{claim_audit_context}"
                "Synthesize a comprehensive scientific report with SPECIFIC residue-level "
                "recommendations. Include: enzyme family classification, catalytic residue "
                "identification, proposed mutations with positions and rationales, tiered "
                "priority ranking, experimental validation plan. "
                "Use explicit evidence sections named 序列级结论, 预测结构结论, 实验结构结论, "
                "and 编号/映射门控 when those evidence types are present. Do not mix predicted "
                "structure evidence with uploaded experimental structure evidence, and do not "
                "reuse task_id/status from prior turns unless it appears in the current Tool results. "
                "Always separate facts, analysis-based inferences, uncertainties, and "
                "items requiring wet-lab validation. If tool evidence is empty or weak, "
                "say so explicitly and ask for missing inputs instead of producing a full "
                "confident report. "
                "Use the Matvenus-derived enzyme engineering report protocol from the system "
                "prompt when the task involves enzyme activity, thermostability, mutation "
                "selection, or wet-lab feedback. "
                "Cite relevant literature (PMIDs) from the knowledge context when available. "
                "NEVER give generic advice."
            )},
        ]
        try:
            resp = await self._call_llm(messages, model_id=model_id, max_tokens=3000)
            content = resp.choices[0].message.content
            if content and content.strip():
                return content.strip()
        except Exception as e:
            logger.exception("SC synthesize LLM call failed")

        # Fallback: build a structured report from tool results
        return self._build_fallback_report(task, tool_results)

    @classmethod
    def _has_plan_only_md_result(cls, tool_results: list[dict]) -> bool:
        for result in tool_results:
            if result.get("tool_name") != "gromacs_md":
                continue
            parsed = cls._safe_parse_json(str(result.get("result", "")))
            if parsed.get("status") == "planned" or parsed.get("is_real_md") is False:
                return True
        return False

    @classmethod
    def _evidence_lineage_synthesis_context(cls, tool_results: list[dict]) -> str:
        sequence_tools = []
        predicted_structure_tools = []
        uploaded_structure_tools = []
        numbering_tools = []
        async_task_ids = []

        for result in tool_results:
            tool_name = str(result.get("tool_name") or "")
            status = str(result.get("status") or "")
            payload = cls._safe_parse_json(str(result.get("result", "")))
            if tool_name in {
                "predict_properties",
                "annotation_bundle",
                "enzyme_objective_module_plan",
                "protein_benchmark",
                "enzyme_function",
                "mutation_priority_score",
                "rosetta_ddg",
                "blast_search",
                "kcat_predict",
                "protssn_score",
            }:
                sequence_tools.append(f"{tool_name}:{status}")
            if tool_name == "esmfold_folding":
                predicted_structure_tools.append(f"{tool_name}:{status}")
            if tool_name == "structure_search_foldseek":
                uploaded_structure_tools.append(f"{tool_name}:{status}")
            if tool_name in {"residue_mapping_sifts", "residue_numbering_gate"}:
                numbering_tools.append(f"{tool_name}:{status}")
            if tool_name == "enzyme_identity_profile":
                identity_status = payload.get("identity_status") if isinstance(payload, dict) else None
                family_candidates = payload.get("family_candidates") if isinstance(payload, dict) else None
                top_family = ""
                if isinstance(family_candidates, list) and family_candidates and isinstance(family_candidates[0], dict):
                    top_family = str(family_candidates[0].get("name") or "")
                label = f"{tool_name}:{status}"
                if identity_status:
                    label += f"({identity_status})"
                if top_family:
                    label += f"[{top_family}]"
                sequence_tools.append(label)
            task_id = payload.get("task_id") if isinstance(payload, dict) else None
            if task_id:
                async_task_ids.append(str(task_id))

        lines = ["Evidence lineage constraints:"]
        lines.append(f"- Sequence-level evidence tools: {', '.join(sequence_tools) if sequence_tools else 'none'}")
        lines.append(f"- Predicted-structure evidence tools: {', '.join(predicted_structure_tools) if predicted_structure_tools else 'none'}")
        lines.append(f"- Uploaded/experimental-structure evidence tools: {', '.join(uploaded_structure_tools) if uploaded_structure_tools else 'none'}")
        lines.append(f"- Numbering/mapping gates: {', '.join(numbering_tools) if numbering_tools else 'none'}")
        lines.append(f"- Current-turn async task IDs: {', '.join(async_task_ids) if async_task_ids else 'none'}")
        lines.append(
            "Report structural claims only under the matching evidence layer. "
            "If numbering/mapping gates are failed or blocked, keep residue-level structural recommendations blocked."
        )
        return "\n".join(lines) + "\n\n"

    @classmethod
    def _structure_no_hit_synthesis_context(cls, tool_results: list[dict]) -> str:
        for result in tool_results:
            if result.get("tool_name") != "structure_search_foldseek":
                continue
            if result.get("status") != "completed":
                continue
            parsed = cls._safe_parse_json(str(result.get("result", "")))
            query_structure = parsed.get("query_structure")
            if not isinstance(query_structure, dict) or not query_structure:
                continue
            results = parsed.get("results")
            results_count = parsed.get("results_count")
            has_hits = bool(results) or (isinstance(results_count, int) and results_count > 0)
            if not has_hits:
                return (
                    "Important synthesis constraint: the uploaded structure was parsed successfully, "
                    "but Foldseek returned zero homolog/template hits. Continue the analysis using the "
                    "query structure summary and explicitly separate structure-intrinsic observations, "
                    "model-based hypotheses, uncertainty, and required wet-lab/MD validation. Do not stop "
                    "only because no homolog was found; do not invent family, catalytic-site, Tm, pH curve, "
                    "or mutation-ranking evidence that is not present.\n\n"
                )
        return ""

    @classmethod
    def _build_claim_audit(cls, tool_results: list[dict]) -> dict[str, Any]:
        """Create report-grade claim controls from current tool outputs."""
        claims: list[dict[str, Any]] = []
        for result in tool_results:
            tool_name = str(result.get("tool_name") or "")
            status = str(result.get("status") or "")
            payload = cls._safe_parse_json(str(result.get("result", "")))
            if not isinstance(payload, dict):
                payload = {}
            evidence_source = payload.get("evidence_source") if isinstance(payload.get("evidence_source"), dict) else {}
            evidence_status = evidence_source.get("status")
            live_query = evidence_source.get("live_query_executed") is True

            if tool_name == "enzyme_identity_profile":
                guardrail = payload.get("guardrail") if isinstance(payload.get("guardrail"), dict) else {}
                ready = payload.get("identity_status") == "identified" and guardrail.get("status") == "ready"
                claims.append({
                    "claim_id": "FOUNDATION_PROFILE",
                    "claim": "Enzyme family/numbering foundation profile is confirmed enough for residue-level recommendations.",
                    "status": "SUPPORTED" if status == "completed" and ready else "MISSING",
                    "source": tool_name,
                })

            if tool_name == "enzyme_objective_module_plan":
                allowed = payload.get("candidate_output_allowed") is True and payload.get("status") == "ready"
                claims.append({
                    "claim_id": "OBJECTIVE_MODULE_READY",
                    "claim": "Objective-specific assay evidence is sufficient for report-grade candidate ranking.",
                    "status": "SUPPORTED" if allowed else "DESIGN_HYPOTHESIS",
                    "source": tool_name,
                    "notes": payload.get("missing_evidence"),
                })

            if tool_name == "annotation_bundle":
                claims.append({
                    "claim_id": "ANNOTATION_BUNDLE_LIVE_QUERY",
                    "claim": "Annotation bundle used live UniProt/InterPro/M-CSA/SignalP evidence in this turn.",
                    "status": "SUPPORTED" if status == "completed" and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode"),
                })

            if tool_name == "blast_search":
                claims.append({
                    "claim_id": "BLAST_LIVE_QUERY",
                    "claim": "BLAST evidence was obtained from a live NCBI query in this turn.",
                    "status": "SUPPORTED" if status == "completed" and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode") or payload.get("warning"),
                })

            if tool_name == "sequence_search":
                claims.append({
                    "claim_id": "SEQUENCE_SEARCH_LIVE_QUERY",
                    "claim": "Sequence search evidence was obtained from a live external UniProt/BLAST query in this turn.",
                    "status": "SUPPORTED" if status == "completed" and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode") or payload.get("warning"),
                })

            if tool_name == "interpro_live_lookup":
                claims.append({
                    "claim_id": "INTERPRO_LIVE_QUERY",
                    "claim": "InterPro evidence was obtained from a live InterPro API query in this turn.",
                    "status": "SUPPORTED" if status == "completed" and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode") or payload.get("warning"),
                })

            if tool_name == "interproscan_sequence_submit":
                claims.append({
                    "claim_id": "INTERPROSCAN_SEQUENCE_SUBMITTED",
                    "claim": "InterProScan sequence analysis was submitted to a live InterProScan service in this turn.",
                    "status": "SUPPORTED" if status in {"completed", "submitted"} and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode") or payload.get("warning"),
                })

            if tool_name == "interproscan_sequence_status":
                result_ready = (
                    payload.get("status") == "completed"
                    and payload.get("result_available") is True
                    and bool(payload.get("results") or payload.get("results_count"))
                )
                claims.append({
                    "claim_id": "INTERPROSCAN_SEQUENCE_RESULT",
                    "claim": "InterProScan sequence annotations were retrieved and parsed from a live InterProScan result in this turn.",
                    "status": "SUPPORTED" if status == "completed" and result_ready and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode") or payload.get("message") or payload.get("warning"),
                })

            if tool_name == "literature_live_search":
                claims.append({
                    "claim_id": "LITERATURE_LIVE_QUERY",
                    "claim": "Literature evidence was obtained from live PubMed/Crossref APIs in this turn.",
                    "status": "SUPPORTED" if status == "completed" and evidence_status == "live" and live_query else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": evidence_source.get("reason") or evidence_source.get("mode") or payload.get("warning"),
                })

            if tool_name == "mutation_priority_score":
                table_status = payload.get("candidate_table_status") or payload.get("summary", {}).get("candidate_table_status")
                has_table = bool(payload.get("experiment_design_table") or payload.get("tier_1_candidates") or payload.get("tier_2_candidates"))
                identity_gate = payload.get("identity_gate") if isinstance(payload.get("identity_gate"), dict) else {}
                objective_gate = payload.get("objective_gate") if isinstance(payload.get("objective_gate"), dict) else {}
                claims.append({
                    "claim_id": "MUTATION_SITE_TABLE",
                    "claim": "Mutation site table is available for experimental planning.",
                    "status": "SUPPORTED" if has_table and identity_gate.get("status") == "passed" else "MISSING",
                    "source": tool_name,
                    "notes": table_status,
                })
                if table_status == "exploratory_requires_objective_evidence":
                    claims.append({
                        "claim_id": "MUTATION_EFFECT_VALIDATED",
                        "claim": "Predicted mutations are validated to improve the requested enzyme property.",
                        "status": "MISSING",
                        "source": tool_name,
                        "notes": objective_gate.get("missing_evidence"),
                    })

            if tool_name in {"kcat_predict", "protssn_score", "alphafold2_folding", "rfdiffusion_design", "proteinmpnn_design", "diffdock_docking"}:
                is_real = payload.get("is_real_inference") is True or payload.get("is_real_runtime") is True
                capability = payload.get("capability_status")
                claims.append({
                    "claim_id": f"{tool_name.upper()}_REAL_RUNTIME",
                    "claim": f"{tool_name} produced report-grade real model/runtime evidence.",
                    "status": "SUPPORTED" if is_real and capability not in {"proxy", "runtime_unverified"} else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": payload.get("report_boundary") or capability,
                })

            if tool_name == "gromacs_md":
                real_md = payload.get("is_real_md") is True
                claims.append({
                    "claim_id": "GROMACS_REAL_MD",
                    "claim": "GROMACS molecular dynamics was executed in this turn and produced report-grade MD artifacts.",
                    "status": "SUPPORTED" if real_md else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": payload.get("note") or payload.get("status"),
                })

            if tool_name == "rosetta_ddg":
                real_rosetta = payload.get("is_real_rosetta") is True
                claims.append({
                    "claim_id": "ROSETTA_REAL_DDG",
                    "claim": "Rosetta ddG was executed and produced report-grade score artifacts.",
                    "status": "SUPPORTED" if real_rosetta else "RUNTIME_UNVERIFIED",
                    "source": tool_name,
                    "notes": payload.get("note") or payload.get("reason"),
                })

        summary_gate = scientific_claim_gate(claims, report_section="summary")
        body_gate = scientific_claim_gate(claims, report_section="body")
        return {
            "claims": claims,
            "summary_gate": summary_gate,
            "body_gate": body_gate,
        }

    @classmethod
    def _claim_audit_synthesis_context(cls, tool_results: list[dict]) -> str:
        audit = cls._build_claim_audit(tool_results)
        summary_gate = audit["summary_gate"]
        body_gate = audit["body_gate"]
        lines = ["Claim audit constraints:"]
        lines.append(
            f"- Summary gate: {summary_gate.get('status')} "
            f"(allowed={summary_gate.get('summary', {}).get('allowed_count', 0)}, "
            f"downgraded={summary_gate.get('summary', {}).get('downgraded_count', 0)}, "
            f"blocked={summary_gate.get('summary', {}).get('blocked_count', 0)})"
        )
        allowed_ids = [str(item.get("claim_id")) for item in summary_gate.get("allowed_claims", [])]
        blocked = summary_gate.get("blocked_claims", [])
        downgraded = summary_gate.get("downgraded_claims", [])
        if allowed_ids:
            lines.append(f"- Claims allowed in summary/conclusion: {', '.join(allowed_ids)}")
        if downgraded:
            lines.append(
                "- Claims downgraded out of summary/conclusion: "
                + "; ".join(f"{item.get('claim_id')}={item.get('status')}" for item in downgraded[:8])
            )
        if blocked:
            lines.append(
                "- Claims blocked as facts: "
                + "; ".join(f"{item.get('claim_id')}={item.get('status')}" for item in blocked[:8])
            )
        lines.append(
            "- Report rule: final summary/conclusion may contain only SUPPORTED claims. "
            "WEAK/DESIGN_HYPOTHESIS can appear only as labeled body/method hypotheses. "
            "MISSING/CONFLICTING/RUNTIME_UNVERIFIED must be written as missing evidence, "
            "runtime boundary, or validation need."
        )
        if body_gate.get("blocked_claims"):
            lines.append(
                "- Body blocked claims: "
                + "; ".join(
                    f"{item.get('claim_id')}={item.get('status')}"
                    for item in body_gate.get("blocked_claims", [])[:8]
                )
            )
        return "\n".join(lines) + "\n\n"

    @classmethod
    def _format_tool_result_for_synthesis(cls, result: dict) -> str:
        result_str = str(result.get("result", ""))
        if result.get("tool_name") != "structure_search_foldseek":
            return result_str[:1200]

        parsed = cls._safe_parse_json(result_str)
        if not parsed:
            return result_str[:1200]

        compact = {
            "found": parsed.get("found"),
            "status": parsed.get("status"),
            "backend": parsed.get("backend"),
            "database": parsed.get("database"),
            "results_count": parsed.get("results_count"),
            "warning": parsed.get("warning"),
            "query_structure": parsed.get("query_structure"),
            "top_results": (parsed.get("results") or [])[:5],
        }
        return json.dumps(compact, ensure_ascii=False, default=str)[:4000]

    def _load_relevant_skills(self, task: str) -> str:
        """Load domain skill content relevant to the task for synthesis context."""
        lower = task.lower()
        relevant = []

        if any(kw in lower for kw in ["ph", "酸性", "碱性", "最适", "耐酸", "耐碱", "酸化"]):
            skill = read_skill("ph_engineering")
            if skill:
                relevant.append(skill)

        if any(kw in lower for kw in ["thermostability", "耐热", "热稳定", "tm", "temperature", "温度"]):
            skill = read_skill("thermostability")
            if skill:
                relevant.append(skill)

        if any(kw in lower for kw in ["mutation", "突变", "mutant", "library", "saturation"]):
            skill = read_skill("mutation_design")
            if skill:
                relevant.append(skill)

        if any(kw in lower for kw in ["kcat", "km", "catalytic", "酶活", "activity", "specificity"]):
            skill = read_skill("enzyme_kinetics")
            if skill:
                relevant.append(skill)

        if any(kw in lower for kw in ["benchmark", "compare", "homolog", "family", "conservation", "比对", "同源"]):
            skill = read_skill("protein_benchmarking")
            if skill:
                relevant.append(skill)

        if any(kw in lower for kw in ["rosetta", "ddg", "ΔΔg", "delta delta g", "稳定能量", "更稳定", "不稳定"]):
            skill = read_skill("mutation_analysis")
            if skill:
                relevant.append(skill)

        if any(kw in lower for kw in ["design", "binder", "de novo", "backbone", "scaffold", "蛋白设计", "从头设计"]):
            skill = read_skill("protein_design")
            if skill:
                relevant.append(skill)

        if not relevant:
            return ""

        return "\n\n--- DOMAIN KNOWLEDGE FOR THIS TASK ---\n\n" + "\n\n".join(relevant)

    def _build_fallback_report(self, task: str, tool_results: list[dict]) -> str:
        """Build a structured scientific report from tool results when LLM fails."""
        # Extract data from results
        seq_data = {}
        props_data = {}
        identity_data = {}
        annotation_data = {}
        objective_data = {}
        mutation_data = {}
        benchmark_data = {}
        enzyme_data = {}
        kcat_data = {}
        md_data = {}
        rosetta_data = {}
        design_data = []  # proteinmpnn / rfdiffusion / chroma results
        blast_sections = []

        for r in tool_results:
            result_str = str(r.get("result", ""))
            tool = r["tool_name"]
            status = r["status"]

            if tool == "predict_properties" and status == "completed":
                props_data = self._safe_parse_json(result_str)
            elif tool == "annotation_bundle" and status == "completed":
                annotation_data = self._safe_parse_json(result_str)
            elif tool == "enzyme_identity_profile" and status == "completed":
                identity_data = self._safe_parse_json(result_str)
            elif tool == "enzyme_objective_module_plan" and status == "completed":
                objective_data = self._safe_parse_json(result_str)
            elif tool == "mutation_scan" and status == "completed":
                mutation_data = self._safe_parse_json(result_str)
            elif tool == "mutation_priority_score" and status == "completed":
                mutation_data = self._safe_parse_json(result_str)
            elif tool == "protein_benchmark" and status == "completed":
                benchmark_data = self._safe_parse_json(result_str)
            elif tool == "enzyme_function" and status == "completed":
                enzyme_data = self._safe_parse_json(result_str)
            elif tool == "kcat_predict" and status == "completed":
                kcat_data = self._safe_parse_json(result_str)
            elif tool == "gromacs_md" and status == "completed":
                md_data = self._safe_parse_json(result_str)
            elif tool == "rosetta_ddg" and status == "completed":
                rosetta_data = self._safe_parse_json(result_str)
            elif tool in ("proteinmpnn_design", "rfdiffusion_design", "chroma_design") and status == "completed":
                design_data.append({"tool": tool, "data": self._safe_parse_json(result_str)})
            elif tool == "blast_search" and status == "completed":
                blast_sections.append(f"```\n{result_str[:500]}\n```\n")

        claim_audit = self._build_claim_audit(tool_results)
        summary_gate = claim_audit.get("summary_gate", {})
        body_gate = claim_audit.get("body_gate", {})

        lines = ["# Protein Engineering Analysis Report\n"]
        lines.append("## Task Understanding\n")
        lines.append(f"- User request: {task[:300]}\n")
        lines.append("- This fallback report is generated from available tool outputs only.\n\n")

        def _mutation_experiment_rows() -> list[dict]:
            experiment_rows = mutation_data.get("experiment_design_table", [])
            if experiment_rows:
                return experiment_rows
            tier1 = mutation_data.get("tier_1_candidates", [])
            tier2 = mutation_data.get("tier_2_candidates", [])
            return [
                {
                    "experiment_priority": c.get("experiment_priority", "P?"),
                    "position": c.get("position"),
                    "wild_type": c.get("wild_type"),
                    "recommended_mutations": [
                        m.get("mutation")
                        for m in c.get("recommended_mutations", [])
                        if isinstance(m, dict)
                    ],
                    "mutation_logic": c.get("logic", "candidate"),
                    "expected_effect": c.get("expected_effect", "需实验确认"),
                    "risk_flags": c.get("risk_flags", []),
                    "candidate_evidence_status": c.get("candidate_evidence_status"),
                    "user_position": c.get("user_position") or c.get("position"),
                    "pdb_position": c.get("pdb_position"),
                    "uniprot_position": c.get("uniprot_position"),
                    "numbering_status": c.get("numbering_status"),
                    "experiment_action": c.get("experiment_action"),
                }
                for c in (tier1 + tier2)[:12]
            ]

        def _format_site(row: dict) -> str:
            wild_type = row.get("wild_type", "")
            position = row.get("position", "?")
            return f"{wild_type}{position}"

        def _format_mutations(row: dict) -> str:
            mutations = row.get("recommended_mutations", [])
            return ", ".join(map(str, mutations[:3])) if isinstance(mutations, list) and mutations else "—"

        def _format_risk(row: dict) -> str:
            risk_flags = row.get("risk_flags", [])
            return "；".join(map(str, risk_flags[:3])) if isinstance(risk_flags, list) and risk_flags else "需实验确认"

        def _format_optional_position(row: dict, key: str) -> str:
            value = row.get(key)
            return str(value) if value not in {None, ""} else "未映射"

        def _format_experiment_action(row: dict) -> str:
            return str(row.get("experiment_action") or "构建单点突变体；与 WT 同批表达纯化；按目标性质做主实验，并复测活性、稳定性和可溶性。")

        mutation_rows = _mutation_experiment_rows() if mutation_data else []
        if mutation_data:
            is_blocked = mutation_data.get("status") == "blocked"
            priorities = {str(row.get("experiment_priority", "")) for row in mutation_rows}
            current_decision = "No-Go" if is_blocked or not mutation_rows else ("Go" if "P1" in priorities else "Watch")
            table_status = (
                mutation_data.get("candidate_table_status")
                or mutation_data.get("summary", {}).get("candidate_table_status")
                or ("blocked" if is_blocked else "candidate_hypotheses")
            )
            lines.append("## 结论卡片 / 状态摘要\n\n")
            lines.append(f"- **当前决策**：{current_decision}\n")
            lines.append(f"- **主表状态**：{table_status}\n")
            lines.append(
                "- **结论边界**：本报告只把已运行工具输出转成实验排单假设；没有实验证据、实时运行证据或编号映射确认时，不写入确定结论。\n"
            )
            lines.append(
                f"- **Claim audit summary**：{summary_gate.get('status', 'N/A')} "
                f"(allowed={summary_gate.get('summary', {}).get('allowed_count', 0)}, "
                f"downgraded={summary_gate.get('summary', {}).get('downgraded_count', 0)}, "
                f"blocked={summary_gate.get('summary', {}).get('blocked_count', 0)})\n\n"
            )

            lines.append("## 突变位点主表（实验排单）\n\n")
            if is_blocked:
                lines.append(f"- **Status**: blocked\n")
                lines.append(f"- **Reason**: {mutation_data.get('reason', 'candidate output is not allowed by gates')}\n")
            objective_gate = mutation_data.get("objective_gate", {})
            if isinstance(objective_gate, dict):
                missing = objective_gate.get("missing_evidence", [])
                if missing:
                    lines.append(f"- **目标证据缺口**：{'；'.join(map(str, missing[:4]))}\n")
            if mutation_rows:
                lines.append("\n| 优先级 | 证据状态 | 用户编号 | PDB编号 | UniProt编号 | 推荐突变 | 突变逻辑 | 预期方向 | 风险提示 | 实验动作 |\n")
                lines.append("|--------|----------|----------|---------|-------------|----------|----------|----------|----------|----------|\n")
                for row in mutation_rows[:12]:
                    lines.append(
                        f"| {row.get('experiment_priority', 'P?')} | {row.get('candidate_evidence_status', '待确认')} | "
                        f"{_format_site(row)} | {_format_optional_position(row, 'pdb_position')} | "
                        f"{_format_optional_position(row, 'uniprot_position')} | {_format_mutations(row)} | "
                        f"{row.get('mutation_logic', 'candidate')} | {row.get('expected_effect', '需实验确认')} | "
                        f"{_format_risk(row)} | {_format_experiment_action(row)} |\n"
                    )
            else:
                lines.append("- 暂无可排单候选；补齐身份、编号、结构或目标实验证据后再生成位点表。\n")
            lines.append("\n")

            lines.append("## 推荐突变与实验批次\n\n")
            if mutation_rows:
                priority_groups: dict[str, list[str]] = {}
                for row in mutation_rows[:12]:
                    priority = str(row.get("experiment_priority", "P?"))
                    priority_groups.setdefault(priority, []).append(f"{_format_site(row)}:{_format_mutations(row)}")
                for priority in sorted(priority_groups):
                    batch_name = {
                        "P1": "第一批单点验证",
                        "P2": "第二批机制互补单点",
                        "P3": "第三批组合前候选",
                    }.get(priority, "待定批次")
                    lines.append(f"- **{priority} {batch_name}**：{'; '.join(priority_groups[priority])}\n")
                lines.append("- **组合原则**：先验证单点；只有机制互补且单点数据通过后，才进入二点组合。\n")
            else:
                lines.append("- No-Go：当前没有足够证据排实验批次。\n")
            lines.append("\n")

            lines.append("## 位点突变逻辑 / 风险 / 实验动作\n\n")
            if mutation_rows:
                for row in mutation_rows[:12]:
                    lines.append(f"### {_format_site(row)} -> {_format_mutations(row)}\n\n")
                    lines.append(f"- **突变逻辑**：{row.get('mutation_logic', 'candidate')}\n")
                    lines.append(f"- **风险提示**：{_format_risk(row)}\n")
                    lines.append(f"- **实验动作**：{_format_experiment_action(row)}\n\n")
            else:
                lines.append("- **实验动作**：先补齐序列/结构编号、目标条件、底物和对照体系，再生成候选位点。\n\n")

            lines.append("## Go / Watch / No-Go\n\n")
            lines.append("- **Go**：仅当单点突变体在目标条件下重复实验优于 WT，且表达/可溶性/基础活性未明显下降时进入组合或放大验证。\n")
            lines.append("- **Watch**：当前主表候选属于计算/规则假设，可进入小批量单点验证，但不得写成已证实增稳或提活。\n")
            lines.append("- **No-Go**：候选命中催化/保守/配体或二硫键关键位点、编号映射冲突、目标证据缺失，或单点实验低于预设阈值时停止。\n\n")

            strategy = mutation_data.get("strategy", {})
            if strategy:
                lines.append("## 改造策略说明\n\n")
                lines.append(f"- **目标**：{strategy.get('objective', 'N/A')}\n")
                lines.append(f"- **设计原则**：{strategy.get('design_principle', 'N/A')}\n")
                for item in strategy.get("screening_logic", [])[:6]:
                    lines.append(f"- **筛选逻辑**：{item}\n")
                lines.append("\n")
            summary = mutation_data.get("summary", {})
            if summary:
                lines.append("## 候选统计与保护位点\n\n")
                lines.append(f"- **Tier 1 candidates**: {summary.get('tier_1_count', 0)}\n")
                lines.append(f"- **Tier 2 candidates**: {summary.get('tier_2_count', 0)}\n")
                identity_gate = mutation_data.get("identity_gate", {})
                if isinstance(identity_gate, dict) and identity_gate:
                    lines.append(f"- **Identity gate**: {identity_gate.get('status', 'N/A')}\n")
                    gate_reason = identity_gate.get("reason")
                    if gate_reason:
                        lines.append(f"- **Gate reason**: {gate_reason}\n")
                    protected_from_profile = identity_gate.get("protected_positions_from_profile", [])
                    if protected_from_profile:
                        lines.append(f"- **Profile-protected positions**: {protected_from_profile}\n")
                never_mutate = summary.get('never_mutate_positions', [])
                if never_mutate:
                    lines.append(f"- **NEVER MUTATE positions**: {never_mutate}\n")
                lines.append("\n")

        lines.append("## Evidence Layer\n\n")
        lines.append("| Layer | Status | Interpretation |\n")
        lines.append("|-------|--------|----------------|\n")
        lines.append("| Known facts | Tool-dependent | Direct values from completed tools are listed below. |\n")
        lines.append("| Analysis-based inferences | Conditional | Recommendations are hypotheses derived from tool outputs. |\n")
        lines.append("| Uncertain items | Present | Missing sequence, structure, literature, or assay context limits confidence. |\n")
        lines.append("| Requires wet-lab validation | Required | Any mutation, activity, stability, or hit-rate claim must be experimentally tested. |\n\n")

        if claim_audit.get("claims"):
            lines.append("## Claim Audit Gate\n\n")
            lines.append(
                f"- **Summary/conclusion gate**: {summary_gate.get('status', 'N/A')} "
                f"(allowed={summary_gate.get('summary', {}).get('allowed_count', 0)}, "
                f"downgraded={summary_gate.get('summary', {}).get('downgraded_count', 0)}, "
                f"blocked={summary_gate.get('summary', {}).get('blocked_count', 0)})\n"
            )
            blocked_claims = summary_gate.get("blocked_claims", [])
            downgraded_claims = summary_gate.get("downgraded_claims", [])
            if downgraded_claims:
                lines.append("- **Downgraded out of summary/conclusion**:\n")
                for item in downgraded_claims[:6]:
                    lines.append(f"  - {item.get('claim_id')}: {item.get('status')}\n")
            if blocked_claims:
                lines.append("- **Blocked as factual claims**:\n")
                for item in blocked_claims[:6]:
                    lines.append(f"  - {item.get('claim_id')}: {item.get('status')}\n")
            if body_gate.get("blocked_claims"):
                lines.append("- **Body/report boundary**: runtime-unverified or missing claims must remain validation needs.\n")
            lines.append("\n")

        for section in blast_sections:
            lines.append("## Enzyme Family Identification (BLAST)\n")
            lines.append(section)

        # Properties section
        if props_data:
            lines.append("## Physicochemical Properties\n")
            lines.append(f"- **Molecular Weight**: {props_data.get('molecular_weight_kda', 'N/A')} kDa\n")
            lines.append(f"- **Isoelectric Point (pI)**: {props_data.get('isoelectric_point', 'N/A')}\n")
            lines.append(f"- **GRAVY**: {props_data.get('gravy', 'N/A')}\n")
            lines.append(f"- **Stability**: {props_data.get('stability', 'N/A')}\n")
            lines.append(f"- **Length**: {props_data.get('length', 'N/A')} residues\n\n")

        if identity_data:
            lines.append("## Enzyme Foundation Profile\n\n")
            family_candidates = identity_data.get("family_candidates", [])
            ec_candidates = identity_data.get("ec_candidates", [])
            key_residues = identity_data.get("key_residues", [])
            protected_positions = identity_data.get("protected_positions", [])
            if family_candidates and isinstance(family_candidates[0], dict):
                top_family = family_candidates[0]
                lines.append(f"- **Family**: {top_family.get('name', 'N/A')}\n")
                lines.append(f"- **Family confidence**: {top_family.get('confidence', 'N/A')}\n")
            if ec_candidates and isinstance(ec_candidates[0], dict):
                top_ec = ec_candidates[0]
                lines.append(f"- **EC candidate**: {top_ec.get('ec', 'N/A')} ({top_ec.get('status', 'N/A')})\n")
            lines.append(f"- **Identity status**: {identity_data.get('identity_status', 'N/A')}\n")
            numbering = identity_data.get("numbering", {})
            if isinstance(numbering, dict):
                lines.append(f"- **Numbering status**: {numbering.get('status', 'N/A')}\n")
                lines.append(f"- **Mapping basis**: {numbering.get('mapping_basis', 'N/A')}\n")
            if protected_positions:
                lines.append(f"- **Protected positions**: {protected_positions}\n")
            if key_residues:
                residue_bits = []
                for residue in key_residues[:8]:
                    if not isinstance(residue, dict):
                        continue
                    residue_bits.append(
                        f"{residue.get('residue', '?')}{residue.get('position', '?')} ({residue.get('role', 'key residue')})"
                    )
                if residue_bits:
                    lines.append(f"- **Key residues**: {', '.join(residue_bits)}\n")
            domains = identity_data.get("functional_domains", [])
            if domains:
                domain_bits = [
                    f"{item.get('name', 'domain')} ({item.get('accession', 'N/A')})"
                    for item in domains[:5] if isinstance(item, dict)
                ]
                if domain_bits:
                    lines.append(f"- **Domains**: {', '.join(domain_bits)}\n")
            cofactors = identity_data.get("cofactors", [])
            if cofactors:
                lines.append(f"- **Cofactors**: {', '.join(map(str, cofactors))}\n")
            signal = identity_data.get("signal_peptide")
            if isinstance(signal, dict):
                lines.append(
                    f"- **Signal peptide**: {signal.get('has_signal_peptide', 'N/A')} "
                    f"({signal.get('cleavage_site') or 'no cleavage site'})\n"
                )
            missing_evidence = identity_data.get("missing_evidence", [])
            if missing_evidence:
                lines.append(f"- **Missing evidence**: {'; '.join(map(str, missing_evidence[:3]))}\n")
            conflicts = identity_data.get("conflicts", [])
            if conflicts:
                lines.append(f"- **Conflicts**: {len(conflicts)}\n")
            lines.append("\n")

        if annotation_data and not identity_data:
            lines.append("## Enzyme Foundation Evidence\n\n")
            coordinate = annotation_data.get("coordinate_system", {})
            protein = annotation_data.get("protein", {})
            lines.append(f"- **Curated record**: {annotation_data.get('query', {}).get('has_curated_enzyme', False)}\n")
            if isinstance(coordinate, dict):
                lines.append(f"- **Coordinate status**: {coordinate.get('status', 'N/A')}\n")
            if isinstance(protein, dict) and protein.get("protein_name"):
                lines.append(f"- **Protein**: {protein['protein_name']}\n")
            lines.append("\n")

        if objective_data:
            lines.append("## Objective Module Gate\n\n")
            lines.append(f"- **Module**: {objective_data.get('module', objective_data.get('objective', 'N/A'))}\n")
            lines.append(f"- **Status**: {objective_data.get('status', 'N/A')}\n")
            lines.append(f"- **Candidate output allowed**: {objective_data.get('candidate_output_allowed', False)}\n")
            question = objective_data.get("primary_question")
            if question:
                lines.append(f"- **Primary question**: {question}\n")
            missing = objective_data.get("missing_evidence", [])
            if missing:
                lines.append("- **Missing evidence**:\n")
                for item in missing[:6]:
                    lines.append(f"  - {item}\n")
            forbidden = objective_data.get("forbidden_shortcuts", [])
            if forbidden:
                lines.append("- **Forbidden shortcuts**:\n")
                for item in forbidden[:4]:
                    lines.append(f"  - {item}\n")
            lines.append("\n")

        # Benchmark section
        if benchmark_data:
            lines.append("## Family & Conservation Analysis\n\n")
            family = benchmark_data.get("family", {})
            if family:
                lines.append(f"- **Family**: {family.get('name', 'Unknown')}\n")
                lines.append(f"- **EC**: {family.get('ec', 'N/A')}\n")
                lines.append(f"- **Mechanism**: {family.get('mechanism', 'N/A')}\n\n")

            motifs_found = benchmark_data.get("family_motifs", [])
            if motifs_found:
                lines.append("### Conserved Motifs\n\n")
                for m in motifs_found:
                    lines.append(f"- **{m.get('region', '?')}** ({m['pattern']}): {m.get('found_at', 'not found')}\n")
                lines.append("\n")

            known_successes = benchmark_data.get("known_engineering_successes", [])
            if known_successes:
                lines.append("### Known Engineering Successes in this Family\n\n")
                for s in known_successes:
                    if isinstance(s, dict):
                        lines.append(f"- {s.get('mutation', '?')}: {s.get('effect', '?')} ({s.get('organism', '?')})\n")
                lines.append("\n")

        # Enzyme function section
        if enzyme_data:
            lines.append("## Enzyme Function Prediction (EC Number)\n\n")
            predictions = enzyme_data.get("predictions", [])
            if predictions:
                lines.append("| # | EC Number | Class | Confidence | Name |\n")
                lines.append("|---|-----------|-------|------------|------|\n")
                for i, p in enumerate(predictions[:5]):
                    conf = p.get("confidence", "?")
                    lines.append(
                        f"| {i+1} | {p.get('ec_number', '?')} | {p.get('class', '?')} | "
                        f"{conf} | {p.get('name', '?')} |\n"
                    )
                lines.append("\n")
            lines.append(f"- **Model**: {enzyme_data.get('model', 'N/A')}\n\n")

        # Kcat kinetics section
        if kcat_data:
            lines.append("## Catalytic Kinetics (Kcat Prediction)\n\n")
            kcat = kcat_data.get("predicted_kcat_s1")
            if kcat is not None:
                lines.append(f"- **Predicted Kcat**: {kcat:.4f} s⁻¹\n")
                lines.append(f"- **Log10(Kcat)**: {kcat_data.get('predicted_log10_kcat', 'N/A')}\n")
                lines.append(f"- **Enzyme Class**: {kcat_data.get('enzyme_class', 'N/A')}\n")
                ci = kcat_data.get("confidence_interval_kcat_s1", [None, None])
                if ci[0] is not None:
                    lines.append(f"- **95% CI**: {ci[0]:.4f} — {ci[1]:.4f} s⁻¹\n")
                lines.append(f"- **Assessment**: {kcat_data.get('efficiency_assessment', 'N/A')}\n")
                lines.append(f"- **Method**: {kcat_data.get('method', 'N/A')}\n")
                lines.append("\n")

        # MD plan-only section
        if md_data:
            lines.append("## Molecular Dynamics Execution Plan\n\n")
            lines.append(f"- **Status**: {md_data.get('status', 'N/A')}\n")
            lines.append(f"- **Real MD executed**: {md_data.get('is_real_md', 'N/A')}\n")
            if md_data.get("note"):
                lines.append(f"- **Note**: {md_data['note']}\n")
            review = md_data.get("protocol_review") or {}
            if isinstance(review, dict) and review:
                lines.append(f"- **Protocol review**: {review.get('status', 'available')}\n")
            plan = md_data.get("replicate_execution_plan") or {}
            tasks = plan.get("tasks") if isinstance(plan, dict) else []
            if tasks:
                lines.append("\n| Task | Variant | Replicate | Time (ns) | Force Field | Water |\n")
                lines.append("|------|---------|-----------|-----------|-------------|-------|\n")
                for task_item in tasks[:8]:
                    lines.append(
                        f"| {task_item.get('task_id', 'N/A')} | {task_item.get('variant', 'N/A')} | "
                        f"{task_item.get('replicate_index', 'N/A')} | {task_item.get('simulation_time_ns', 'N/A')} | "
                        f"{task_item.get('force_field', 'N/A')} | {task_item.get('water_model', 'N/A')} |\n"
                    )
                lines.append("\n")
            lines.append(
                "This chat response did not execute GROMACS inline. Submit the real MD run "
                "from the PDB workspace or background task runner to avoid blocking the chat stream.\n\n"
            )

        if rosetta_data:
            lines.append("## Rosetta ΔΔG Mutation Stability\n\n")
            lines.append(f"- **Status**: {rosetta_data.get('status', 'N/A')}\n")
            lines.append(f"- **Real Rosetta executed**: {rosetta_data.get('is_real_rosetta', False)}\n")
            if rosetta_data.get("reason"):
                lines.append(f"- **Blocked reason**: {rosetta_data.get('reason')}\n")
            if rosetta_data.get("missing"):
                lines.append(f"- **Missing**: {', '.join(map(str, rosetta_data.get('missing', [])))}\n")
            if rosetta_data.get("note"):
                lines.append(f"- **Note**: {rosetta_data.get('note')}\n")
            lines.append("\n### ΔΔG Interpretation Thresholds\n\n")
            lines.append("| Range (kcal/mol) | Label | Interpretation |\n")
            lines.append("|------------------|-------|----------------|\n")
            lines.append("| <= -2.0 | strong_stabilizing | Strong stabilizing candidate; manual structural review required. |\n")
            lines.append("| (-2.0, -1.0] | stabilizing | Likely stabilizing. |\n")
            lines.append("| (-1.0, 1.0] | neutral_or_uncertain | Small/uncertain effect; do not over-interpret. |\n")
            lines.append("| (1.0, 2.0] | destabilizing | Likely destabilizing. |\n")
            lines.append("| > 2.0 | strong_destabilizing | High destabilization risk. |\n\n")
            results = rosetta_data.get("results", [])
            if isinstance(results, list) and results:
                lines.append("### Mutation Results\n\n")
                lines.append("| Mutation | ΔΔG | Class | Manual Review |\n")
                lines.append("|----------|-----|-------|---------------|\n")
                for item in results[:12]:
                    flags = item.get("manual_review_flags", [])
                    flag_text = "; ".join(map(str, flags[:2])) if isinstance(flags, list) else "required"
                    lines.append(
                        f"| {item.get('mutation', '?')} | {item.get('ddg_kcal_mol', '—')} | "
                        f"{item.get('ddg_label', '—')} | {flag_text} |\n"
                    )
                lines.append("\n")
            lines.append(
                "Manual review is required before execution: confirm residue numbering, chain mapping, "
                "active-site/cofactor/disulfide overlap, local packing, and agreement with other tools or experiments.\n\n"
            )

        # Design results section (binder / de novo design)
        if design_data:
            lines.append("## Protein Design Results\n\n")
            for d in design_data:
                tool = d["tool"]
                data = d["data"]

                if tool == "proteinmpnn_design":
                    lines.append("### Inverse Folding (ProteinMPNN)\n\n")
                    lines.append(f"- **Target length**: {data.get('target_length', 'N/A')} residues\n")
                    lines.append(f"- **Best recovery rate**: {data.get('best_recovery_rate', 'N/A')}\n")
                    lines.append(f"- **Best confidence**: {data.get('best_confidence', 'N/A')}\n")
                    lines.append(f"- **Sequences generated**: {data.get('num_sequences_generated', 'N/A')}\n\n")
                    designs = data.get("designs", [])
                    if designs:
                        lines.append("| Rank | Sequence (first 40 aa) | Recovery | Confidence | Mutations |\n")
                        lines.append("|------|------------------------|----------|------------|----------|\n")
                        for des in designs[:5]:
                            seq_preview = des.get("sequence", "")[:40] + "…"
                            lines.append(
                                f"| {des.get('rank', '?')} | `{seq_preview}` | "
                                f"{des.get('recovery_rate', '?')} | {des.get('mean_confidence', '?')} | "
                                f"{des.get('num_mutations', '?')} |\n"
                            )
                        lines.append("\n")

                elif tool == "rfdiffusion_design":
                    lines.append("### Backbone Generation (RFdiffusion)\n\n")
                    lines.append(f"```\n{str(data)[:500]}\n```\n\n")

                elif tool == "chroma_design":
                    lines.append("### Joint Structure-Sequence (Chroma)\n\n")
                    lines.append(f"```\n{str(data)[:500]}\n```\n\n")

        # Recommendations
        lines.append("## Recommendations & Experimental Plan\n\n")
        lines.append("### DO NOT MUTATE\n")
        lines.append("- Catalytic triad residues (Asp/Glu nucleophile, acid/base, stabilizer)\n")
        lines.append("- Ca²⁺/Zn²⁺ binding site residues\n")
        lines.append("- Conserved Cys in disulfide bonds\n\n")

        lines.append("### Experimental Validation Pipeline\n")
        lines.append("1. **Design confirmation**: Manually confirm sequence/PDB/UniProt numbering, chain ID, catalytic residues, cofactors, disulfides, and selected mutation list.\n")
        lines.append("2. **Single-mutant construction**: Build top single mutants first; include WT, empty vector, and known positive/negative controls when available.\n")
        lines.append("3. **Expression/solubility check**: Compare expression level, soluble fraction, SDS-PAGE/Western, SEC monomer ratio, and aggregation/degradation.\n")
        lines.append("4. **Primary activity screen**: Assay target condition and original condition side-by-side, n>=3 biological or technical replicates.\n")
        lines.append("5. **Stability screen**: Measure Tm/DSF, residual activity after heat or pH challenge, and half-life under process-relevant conditions.\n")
        lines.append("6. **Kinetics confirmation**: Determine kcat/Km for top hits and check substrate specificity or inhibition when relevant.\n")
        lines.append("7. **Combination gradient**: Combine validated single mutants into two-site variants first; higher-order combinations only after two-site data passes Go/No-Go.\n")
        lines.append("8. **Final verification**: Re-purify top 3 candidates and repeat full kinetics, stability, and structural/MD review if needed.\n\n")

        lines.append("---\n")
        lines.append("*Report generated by Protein AI Platform — Expert Cluster Analysis Engine*\n")

        return "\n".join(lines)

    @staticmethod
    def _compact_result(tool_name: str, result: Any) -> str:
        """Build a compact JSON string from a tool result, prioritizing key fields.

        Large results (e.g., mutation_priority_score at 80KB) need key field extraction
        so the LLM and fallback report can see the summary and top candidates.
        """
        if not isinstance(result, dict):
            return str(result)[:5000]

        # Tools with known large outputs — extract key fields into a compact dict
        if tool_name == "enzyme_identity_profile":
            compact = {}
            for key in (
                "profile_version",
                "identity_status",
                "family_candidates",
                "ec_candidates",
                "protected_positions",
                "key_residues",
                "functional_domains",
                "cofactors",
                "signal_peptide",
                "numbering",
                "missing_evidence",
                "conflicts",
                "guardrail",
                "confidence_summary",
            ):
                if key in result:
                    compact[key] = result[key]
            if isinstance(compact.get("family_candidates"), list):
                compact["family_candidates"] = compact["family_candidates"][:3]
            if isinstance(compact.get("ec_candidates"), list):
                compact["ec_candidates"] = compact["ec_candidates"][:3]
            if isinstance(compact.get("key_residues"), list):
                compact["key_residues"] = compact["key_residues"][:8]
            try:
                return json.dumps(compact, ensure_ascii=False, default=str)
            except Exception:
                logger.debug("Compact JSON failed for enzyme_identity_profile, falling through")

        if tool_name == "enzyme_objective_module_plan":
            compact = {}
            for key in (
                "status",
                "objective",
                "module",
                "primary_question",
                "foundation_gate",
                "missing_evidence",
                "candidate_output_allowed",
                "ranking_boundary",
                "validation_metrics",
                "forbidden_shortcuts",
            ):
                if key in result:
                    compact[key] = result[key]
            try:
                return json.dumps(compact, ensure_ascii=False, default=str)
            except Exception:
                logger.debug("Compact JSON failed for enzyme_objective_module_plan, falling through")

        if tool_name == "mutation_priority_score":
            compact = {}
            for key in ("status", "reason", "identity_gate", "objective_gate",
                        "candidate_table_status", "experiment_design_table",
                        "summary", "strategy", "tier_1_candidates", "tier_2_candidates",
                        "engineering_goal", "sequence_length"):
                if key in result:
                    compact[key] = result[key]
            if isinstance(compact.get("experiment_design_table"), list):
                compact["experiment_design_table"] = compact["experiment_design_table"][:12]
            # Limit tier lists to top 10
            for tier_key in ("tier_1_candidates", "tier_2_candidates"):
                if tier_key in compact and isinstance(compact[tier_key], list):
                    compact[tier_key] = compact[tier_key][:10]
            try:
                return json.dumps(compact, ensure_ascii=False, default=str)
            except Exception:
                logger.debug("Compact JSON failed for mutation_priority_score, falling through")

        if tool_name == "mutation_scan":
            compact = {}
            for key in ("sequence_length", "scan_type", "positions_scanned", "results"):
                if key in result:
                    compact[key] = result[key] if key != "results" else result[key][:15]
            try:
                return json.dumps(compact, ensure_ascii=False, default=str)
            except Exception:
                logger.debug("Compact JSON failed for mutation_scan, falling through")

        if tool_name == "rosetta_ddg":
            compact = {}
            for key in (
                "status", "requested_mutations", "thresholds", "manual_review_required",
                "manual_review_checklist", "runtime", "pdb_input", "sequence_validation_errors",
                "reason", "missing", "recovery", "is_real_rosetta", "evidence_level",
                "results", "note",
            ):
                if key in result:
                    compact[key] = result[key]
            if isinstance(compact.get("results"), list):
                compact["results"] = compact["results"][:20]
            try:
                return json.dumps(compact, ensure_ascii=False, default=str)
            except Exception:
                logger.debug("Compact JSON failed for rosetta_ddg, falling through")

        # Default: JSON-serialized full result (much more compact than Python repr)
        try:
            return json.dumps(result, ensure_ascii=False, default=str)
        except Exception:
            logger.debug("JSON serialization failed, truncating raw result")
            return str(result)[:5000]

    @staticmethod
    def _safe_parse_json(text: str) -> dict:
        """Try to parse a string as JSON or Python repr, return empty dict on failure."""
        if not isinstance(text, str) or not text.strip():
            return {}
        # Try JSON first
        try:
            return json.loads(text)
        except (json.JSONDecodeError, TypeError):
            pass
        # Try ast.literal_eval for Python repr strings (safe — no code execution)
        try:
            import ast
            return ast.literal_eval(text)
        except (ValueError, SyntaxError):
            pass
        # Handle truncated Python repr: trim to last complete closing bracket
        try:
            import ast
            trimmed = text[:text.rfind('}')+1] if '}' in text else text
            if trimmed.strip():
                return ast.literal_eval(trimmed)
        except (ValueError, SyntaxError):
            pass
        return {}

    async def _chat_reply(
        self, message: str, history: list[dict],
        model_id: str | None = None,
    ) -> str:
        """Direct LLM chat reply for non-protein general conversation."""
        wants_document = self._is_document_reply_request(message)
        system_prompt = (
            "You are a helpful protein engineering AI assistant. "
            "The user's message does not appear to contain a specific protein analysis task. "
            "Respond naturally and helpfully. If you can, guide them toward describing "
            "a protein engineering goal — such as analyzing a sequence, designing a binder, "
            "predicting a structure, or scanning mutations."
        )
        if wants_document:
            system_prompt += (
                " The user is asking for an execution document, SOP, checklist, schedule, "
                "template, or table. Preserve clear Markdown structure, section breaks, "
                "lists, and tables. Do not shorten the document unless the user asks for a summary. "
                "When the document concerns enzyme mutation design, stability, activity, or "
                "experimental feedback, follow this protocol:\n"
                f"{ENZYME_ENGINEERING_REPORT_PROTOCOL}"
            )
        else:
            system_prompt += " Keep your response concise."
        try:
            resp = await self._call_llm(
                [{"role": "system", "content": system_prompt}, *history[-4:], {"role": "user", "content": message}],
                model_id=model_id, max_tokens=2200 if wants_document else 512,
            )
            return resp.choices[0].message.content or "Hello! How can I help with your protein research today?"
        except Exception:
            logger.exception("Chat reply LLM call failed")
            return "Hello! I'm a protein engineering AI assistant. How can I help you today?"

    @staticmethod
    def _sanitize_messages(messages: list[dict]) -> list[dict]:
        """Sanitize messages for API compatibility.

        Dashscope/Qwen and some other providers require 'content' to be a string.
        This strips tool_calls fields and coerces non-string content to str.
        """
        sanitized = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            # Coerce non-string content (list, dict, None) to string
            if content is None:
                content = ""
            elif isinstance(content, list):
                # Multi-modal content list → extract text parts
                text_parts = []
                for item in content:
                    if isinstance(item, dict):
                        text_parts.append(item.get("text", ""))
                    elif isinstance(item, str):
                        text_parts.append(item)
                content = "\n".join(text_parts)
            elif not isinstance(content, str):
                content = str(content)

            clean: dict = {"role": role, "content": content}

            # Preserve tool_call_id for tool response messages
            if role == "tool" and "tool_call_id" in msg:
                clean["tool_call_id"] = msg["tool_call_id"]

            # Drop assistant messages with no content (pure tool_calls)
            if role == "assistant" and not content.strip():
                continue

            sanitized.append(clean)
        return sanitized

    async def _call_llm(self, messages: list[dict], model_id: str | None = None, **kwargs) -> Any:
        """Run the unified LLM gateway in a thread pool to avoid blocking the event loop."""
        messages = self._sanitize_messages(messages)
        loop = asyncio.get_running_loop()
        future = loop.run_in_executor(
            None,
            functools.partial(llm_gateway.complete_sync, messages, model_id=model_id, **kwargs),
        )
        return await asyncio.wait_for(
            future,
            timeout=max(float(settings.LLM_REQUEST_TIMEOUT), 0.05),
        )

    # Errors that are transient and worth retrying once
    _RETRYABLE_ERRORS = ("connection", "timeout", "rate_limit", "rate_limited", "503", "502", "429")

    def _should_retry(self, step: PlanStep) -> bool:
        """Determine if a failed step should be retried once for transient errors."""
        error_lower = str(step.error).lower()
        return any(pattern in error_lower for pattern in self._RETRYABLE_ERRORS)


orchestrator = AgentOrchestrator()
