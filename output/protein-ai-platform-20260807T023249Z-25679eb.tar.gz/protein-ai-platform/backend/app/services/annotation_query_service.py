"""Reusable query service for annotation-centric protein lookups."""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.domain import (
    AlphaFoldStructure,
    CatalyticSite,
    DirectedEvolutionEntry,
    DomainArchitecture,
    EnzymeECLink,
    EnzymeInterProLink,
    EnzymeRecord,
    KineticParameter,
    PDBStructure,
    SignalPeptidePrediction,
    StabilityRecord,
    Taxonomy,
)


class AnnotationQueryService:
    """Single entry point for annotation-focused read operations."""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_enzyme(self, uniprot_id: str) -> EnzymeRecord | None:
        row = await self.session.execute(
            select(EnzymeRecord).where(EnzymeRecord.uniprot_id == uniprot_id)
        )
        return row.scalar_one_or_none()

    async def get_enzyme_with_annotations(self, uniprot_id: str) -> EnzymeRecord | None:
        row = await self.session.execute(
            self._enzyme_with_annotations_query().where(EnzymeRecord.uniprot_id == uniprot_id)
        )
        return row.scalar_one_or_none()

    async def get_enzyme_by_exact_sequence_with_annotations(self, sequence: str) -> EnzymeRecord | None:
        """Resolve only exact sequence matches; similarity search belongs to BLAST/HMM tools."""
        row = await self.session.execute(
            self._enzyme_with_annotations_query().where(EnzymeRecord.sequence == sequence)
        )
        return row.scalar_one_or_none()

    @staticmethod
    def _enzyme_with_annotations_query():
        return (
            select(EnzymeRecord)
            .options(
                selectinload(EnzymeRecord.taxonomy),
                selectinload(EnzymeRecord.ec_numbers).selectinload(EnzymeECLink.ec_number),
                selectinload(EnzymeRecord.interpro_links).selectinload(EnzymeInterProLink.interpro_entry),
                selectinload(EnzymeRecord.domains).selectinload(DomainArchitecture.domain),
                selectinload(EnzymeRecord.catalytic_sites).selectinload(CatalyticSite.residues),
                selectinload(EnzymeRecord.signal_peptide_predictions),
                selectinload(EnzymeRecord.pdb_structures),
                selectinload(EnzymeRecord.alphafold_structures),
            )
        )

    async def get_protein_summary(self, uniprot_id: str) -> dict | None:
        enzyme = await self.get_enzyme_with_annotations(uniprot_id)
        if enzyme is None:
            return None

        kp_count = await self.session.scalar(
            select(func.count(KineticParameter.id)).where(KineticParameter.enzyme_id == enzyme.id)
        )
        stab_count = await self.session.scalar(
            select(func.count(StabilityRecord.id)).where(StabilityRecord.enzyme_id == enzyme.id)
        )
        evo_count = await self.session.scalar(
            select(func.count(DirectedEvolutionEntry.id)).where(DirectedEvolutionEntry.enzyme_id == enzyme.id)
        )

        annotations_payload = self.build_annotations_payload(enzyme)
        catalytic_payload = self.build_catalytic_sites_payload(enzyme)
        signal_payload = self.build_signal_peptide_payload(enzyme)

        return {
            "uniprot_id": enzyme.uniprot_id,
            "entry_name": enzyme.entry_name,
            "protein_name": enzyme.protein_name,
            "gene_name": enzyme.gene_name,
            "sequence": enzyme.sequence,
            "seq_length": enzyme.seq_length,
            "function": enzyme.function_annotation,
            "catalytic_activity": enzyme.catalytic_activity,
            "cofactors": enzyme.cofactors,
            "organism": self.taxonomy_to_dict(enzyme.taxonomy),
            "ec_numbers": [
                {"ec": link.ec_number.ec_number, "name": link.ec_number.name, "primary": link.is_primary}
                for link in enzyme.ec_numbers
                if link.ec_number is not None
            ],
            "pdb_structures": [
                {"pdb_id": s.pdb_id, "method": s.method, "resolution": s.resolution}
                for s in enzyme.pdb_structures
            ],
            "annotation_summary": {
                "interpro_annotations": annotations_payload["counts"]["interpro_annotations"],
                "catalytic_sites": catalytic_payload["count"],
                "protected_positions": catalytic_payload["protected_positions"],
                "signal_peptide": signal_payload,
            },
            "alphafold": {
                "plddt_mean": enzyme.alphafold_structures[0].plddt_mean,
                "model_url": enzyme.alphafold_structures[0].model_url,
            } if enzyme.alphafold_structures else None,
            "counts": {
                "kinetic_params": kp_count or 0,
                "stability_records": stab_count or 0,
                "evolution_entries": evo_count or 0,
                "pdb_structures": len(enzyme.pdb_structures),
                "interpro_annotations": annotations_payload["counts"]["interpro_annotations"],
                "catalytic_sites": catalytic_payload["count"],
            },
        }

    def build_annotations_payload(self, enzyme: EnzymeRecord) -> dict:
        annotations = [
            {
                "interpro_id": link.interpro_entry.interpro_id if link.interpro_entry else None,
                "name": link.interpro_entry.name if link.interpro_entry else None,
                "entry_type": link.interpro_entry.entry_type if link.interpro_entry else None,
                "source": link.interpro_entry.source_db if link.interpro_entry else None,
                "go_terms": link.interpro_entry.go_terms if link.interpro_entry else [],
                "start_pos": link.start_pos,
                "end_pos": link.end_pos,
                "score": link.score,
                "evidence": link.evidence,
            }
            for link in enzyme.interpro_links
        ]
        pfam_domains = [
            {
                "pfam_id": arch.domain.pfam_id if arch.domain else None,
                "name": arch.domain.name if arch.domain else None,
                "description": arch.domain.description if arch.domain else None,
                "start_pos": arch.start_pos,
                "end_pos": arch.end_pos,
                "evalue": arch.evalue,
            }
            for arch in enzyme.domains
        ]
        return {
            "uniprot_id": enzyme.uniprot_id,
            "annotations": annotations,
            "pfam_domains": pfam_domains,
            "counts": {
                "interpro_annotations": len(annotations),
                "pfam_domains": len(pfam_domains),
            },
        }

    def build_catalytic_sites_payload(self, enzyme: EnzymeRecord) -> dict:
        sites = []
        protected_positions = set()
        for site in enzyme.catalytic_sites:
            residues = []
            for residue in sorted(site.residues, key=lambda item: item.residue_pos):
                residues.append(
                    {
                        "position": residue.residue_pos,
                        "residue": residue.residue_aa,
                        "role": residue.role,
                        "confidence": residue.confidence,
                        "pdb_chain": residue.pdb_chain,
                        "pdb_residue_no": residue.pdb_residue_no,
                    }
                )
                if residue.residue_pos:
                    protected_positions.add(residue.residue_pos)
            sites.append(
                {
                    "source": site.source,
                    "mechanism_name": site.mechanism_name,
                    "reaction_text": site.reaction_text,
                    "evidence": site.evidence_json,
                    "residues": residues,
                }
            )

        return {
            "uniprot_id": enzyme.uniprot_id,
            "sites": sites,
            "protected_positions": sorted(protected_positions),
            "count": len(sites),
        }

    def build_signal_peptide_payload(self, enzyme: EnzymeRecord) -> dict | None:
        if not enzyme.signal_peptide_predictions:
            return None
        prediction = sorted(
            enzyme.signal_peptide_predictions,
            key=lambda item: item.created_at,
            reverse=True,
        )[0]
        return prediction.raw_json or {
            "found": True,
            "query": {"uniprot_id": enzyme.uniprot_id, "sequence_length": enzyme.seq_length},
            "has_signal_peptide": prediction.has_signal,
            "cleavage_site": prediction.cleavage_site,
            "model": prediction.model_name,
        }

    @staticmethod
    def taxonomy_to_dict(tax: Taxonomy | None) -> dict | None:
        if tax is None:
            return None
        return {
            "taxid": tax.ncbi_taxid,
            "name": tax.scientific_name,
            "common": tax.common_name,
            "lineage": tax.lineage,
        }
