"""Conservative epistasis risk check before combining mutations."""

from __future__ import annotations

import itertools
import re
from typing import Any

from app.tools.registry import ToolRegistry


MUT_RE = re.compile(r"^([A-Z])([0-9]+)([A-Z])$")


def _position(code: str) -> int | None:
    match = MUT_RE.match(str(code).strip().upper())
    return int(match.group(2)) if match else None


def _pair_key(a: str, b: str) -> str:
    return ":".join(sorted([a.upper(), b.upper()]))


def _phenotype_status(feedback: dict[str, Any] | None) -> str:
    if not feedback:
        return "unknown"
    decision = feedback.get("decision") or feedback.get("status")
    if decision in {"go", "positive", "validated"}:
        return "go"
    if decision in {"no_go", "negative", "failed"}:
        return "no_go"
    metrics = feedback.get("metrics") or {}
    activity = metrics.get("activity_retention_pct")
    tm_delta = metrics.get("tm_delta_c")
    try:
        if activity is not None and float(activity) < 50:
            return "no_go"
        if tm_delta is not None and float(tm_delta) <= -2:
            return "watch"
    except (TypeError, ValueError):
        pass
    return "watch"


async def mutation_epistasis_check(
    mutations: list[str],
    mechanism_tags: dict[str, list[str]] | None = None,
    structural_distances: dict[str, float] | None = None,
    same_region_groups: list[list[str]] | None = None,
    single_mutant_feedback: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Assess whether single mutations are safe to combine."""
    normalized = [str(item).strip().upper() for item in mutations or [] if str(item).strip()]
    if len(normalized) < 2:
        return {
            "status": "blocked",
            "blocked_reason": "need_at_least_two_mutations",
            "required_inputs": ["mutations"],
        }

    mechanism_tags = mechanism_tags or {}
    structural_distances = structural_distances or {}
    single_mutant_feedback = single_mutant_feedback or {}
    region_lookup: dict[str, str] = {}
    for idx, group in enumerate(same_region_groups or [], start=1):
        for mutation in group:
            region_lookup[str(mutation).strip().upper()] = f"region_{idx}"

    pairwise: list[dict[str, Any]] = []
    total_score = 0
    blockers: list[str] = []
    warnings: list[str] = []

    for a, b in itertools.combinations(normalized, 2):
        reasons: list[str] = []
        score = 0
        distance = structural_distances.get(_pair_key(a, b))
        pos_a = _position(a)
        pos_b = _position(b)

        if distance is None and pos_a is not None and pos_b is not None:
            sequence_gap = abs(pos_a - pos_b)
            if sequence_gap <= 5:
                score += 3
                reasons.append("nearby_in_sequence_without_structure_distance")
        elif distance is not None:
            if distance < 5:
                score += 5
                reasons.append("too_close_may_erase_local_effect_or_destabilize")
            elif distance < 10:
                score += 2
                reasons.append("same_local_neighborhood")

        if region_lookup.get(a) and region_lookup.get(a) == region_lookup.get(b):
            score += 3
            reasons.append("same_region_or_pocket")

        tags_a = set(mechanism_tags.get(a) or [])
        tags_b = set(mechanism_tags.get(b) or [])
        overlap = sorted(tags_a & tags_b)
        if overlap:
            score += 2
            reasons.append(f"shared_mechanism:{','.join(overlap)}")
        if "charge_change" in tags_a and "charge_change" in tags_b:
            score += 2
            reasons.append("repeated_charge_change")
        if "loop_rigidification" in tags_a and "loop_rigidification" in tags_b:
            score += 2
            reasons.append("repeated_loop_rigidification")

        status_a = _phenotype_status(single_mutant_feedback.get(a))
        status_b = _phenotype_status(single_mutant_feedback.get(b))
        if "no_go" in {status_a, status_b}:
            score += 6
            reasons.append("single_mutant_no_go")
        elif "unknown" in {status_a, status_b}:
            score += 1
            reasons.append("missing_single_mutant_feedback")

        if score >= 7:
            risk = "high"
            blockers.append(f"{a}+{b}")
        elif score >= 3:
            risk = "medium"
            warnings.append(f"{a}+{b}")
        else:
            risk = "low"

        total_score += score
        pairwise.append({
            "pair": [a, b],
            "risk": risk,
            "score": score,
            "distance_angstrom": distance,
            "reasons": reasons or ["orthogonal_by_available_evidence"],
        })

    high_count = sum(1 for item in pairwise if item["risk"] == "high")
    medium_count = sum(1 for item in pairwise if item["risk"] == "medium")
    if high_count:
        recommendation = "no_go"
    elif medium_count:
        recommendation = "watch"
    else:
        recommendation = "go"

    gradient_plan = []
    if recommendation == "go":
        gradient_plan.append({"step": 1, "variant": "+".join(normalized), "purpose": "direct_combination_validation"})
    else:
        go_single = [
            mutation for mutation in normalized
            if _phenotype_status(single_mutant_feedback.get(mutation)) == "go"
        ]
        if go_single:
            gradient_plan.append({"step": 1, "variant": go_single[0], "purpose": "validated_parent"})
        gradient_plan.append({"step": 2, "variant": "pairwise_subset", "purpose": "test lowest-risk pairs before higher-order combination"})

    return {
        "status": "ok",
        "recommendation": recommendation,
        "mutations": normalized,
        "pairwise_risks": pairwise,
        "summary": {
            "high_risk_pairs": high_count,
            "medium_risk_pairs": medium_count,
            "risk_score_total": total_score,
            "blocked_pairs": blockers,
            "watch_pairs": warnings,
        },
        "gradient_experiment_plan": gradient_plan,
        "required_missing_evidence": [
            item for item in [
                "pairwise_structural_distances" if any(row["distance_angstrom"] is None for row in pairwise) else None,
                "single_mutant_feedback" if any("missing_single_mutant_feedback" in row["reasons"] for row in pairwise) else None,
            ]
            if item
        ],
    }


ToolRegistry.register(
    name="mutation_epistasis_check",
    description=(
        "Check epistasis and combination risk before merging validated single mutations. "
        "Flags same-pocket, close-distance, repeated mechanism, repeated charge/loop changes, "
        "and single-mutant No-Go evidence. Use before proposing multi-mutant constructs."
    ),
    parameters={
        "type": "object",
        "properties": {
            "mutations": {"type": "array", "items": {"type": "string"}},
            "mechanism_tags": {
                "type": "object",
                "description": "Mapping mutation -> tags such as charge_change, loop_rigidification, activity_gain, stability_gain.",
            },
            "structural_distances": {
                "type": "object",
                "description": "Mapping pair key like A10V:D55N -> C-alpha distance in Angstrom.",
            },
            "same_region_groups": {
                "type": "array",
                "items": {"type": "array", "items": {"type": "string"}},
                "description": "Groups of mutations in the same pocket/loop/function surface.",
            },
            "single_mutant_feedback": {
                "type": "object",
                "description": "Mapping mutation -> wet-lab interpretation with decision/status and optional metrics.",
            },
        },
        "required": ["mutations"],
    },
    handler=mutation_epistasis_check,
    category="engineering",
    timeout_seconds=30,
)
