"""Foldseek/template structure search entrypoint.

The first deployable layer exposes a stable tool contract and a deterministic
local fallback. If a Foldseek endpoint is configured later, the call site can
be upgraded without changing planner/tool integration.
"""

from __future__ import annotations

import asyncio
import csv
from pathlib import Path
import subprocess
import tempfile
from typing import Any

import httpx

from app.core.config import settings
from app.services import storage
from app.services.pdb_parser import parse_pdb
from app.services.tool_cache import get_cached_result, set_cached_result
from app.tools.registry import ToolRegistry

_LOCAL_RESULT_FIELDS = (
    "query",
    "target",
    "evalue",
    "bits",
    "alntmscore",
    "qtmscore",
    "ttmscore",
    "prob",
)


class LocalFoldseekConfigError(RuntimeError):
    pass


def _to_float(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _structure_summary(pdb_data: str) -> dict[str, Any]:
    analysis = parse_pdb(pdb_data)
    chains = analysis.get("chains") or []
    return {
        "chain_count": len(chains),
        "total_residues": analysis.get("total_residues") or 0,
        "total_atoms": analysis.get("total_atoms") or 0,
        "chains": [
            {
                "chain_id": chain.get("chain_id"),
                "residue_count": chain.get("residue_count"),
                "residue_range": chain.get("residue_range"),
            }
            for chain in chains
        ],
    }


async def _load_pdb_data(pdb_data: str, pdb_object_name: str) -> str:
    if pdb_data.strip():
        return pdb_data
    if pdb_object_name:
        return (await storage.download_file(pdb_object_name)).decode("utf-8", errors="replace")
    return ""


def _resolve_local_database_path(database: str) -> str:
    def _resolve_db_prefix(path: Path) -> str:
        if path.is_file():
            return str(path)
        if not path.is_dir():
            return ""

        # Prefer base DB prefixes like `protein_ai_pdb` over auxiliary files
        # such as `.idx`, `_ca`, `_ss`, `.lookup`, or `.index`.
        for dbtype_file in sorted(path.glob("*.dbtype")):
            stem = dbtype_file.name.removesuffix(".dbtype")
            if any(
                token in stem
                for token in (".idx", "_ca", "_ss", "_h", ".lookup", ".source", ".index")
            ):
                continue
            candidate = path / stem
            if candidate.exists():
                return str(candidate)
        return ""

    explicit_attr = f"FOLDSEEK_DATABASE_{database.upper()}"
    explicit_path = getattr(settings, explicit_attr, "") or ""
    if explicit_path.strip():
        resolved = _resolve_db_prefix(Path(explicit_path.strip()).expanduser())
        return resolved or explicit_path.strip()

    root = getattr(settings, "FOLDSEEK_DATABASE_ROOT", "") or ""
    if not root.strip():
        return ""
    database_dir = (Path(root).expanduser() / database).resolve()
    resolved = _resolve_db_prefix(database_dir)
    return resolved or str(database_dir)


def _parse_local_results(result_path: Path, max_results: int) -> list[dict[str, Any]]:
    if not result_path.exists():
        return []

    results: list[dict[str, Any]] = []
    with result_path.open("r", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle, fieldnames=_LOCAL_RESULT_FIELDS, delimiter="\t")
        for rank, row in enumerate(reader, start=1):
            if rank > max_results:
                break
            target = (row.get("target") or "").strip()
            if not target:
                continue
            results.append(
                {
                    "rank": rank,
                    "query": (row.get("query") or "").strip(),
                    "target": target,
                    "evalue": _to_float(row.get("evalue") or ""),
                    "bits": _to_float(row.get("bits") or ""),
                    "aligned_tm_score": _to_float(row.get("alntmscore") or ""),
                    "query_tm_score": _to_float(row.get("qtmscore") or ""),
                    "target_tm_score": _to_float(row.get("ttmscore") or ""),
                    "probability": _to_float(row.get("prob") or ""),
                    "source": "local_cli",
                }
            )
    return results


def _execute_local_foldseek_command(
    *,
    binary: str,
    query_path: Path,
    database_path: str,
    result_path: Path,
    work_dir: Path,
    max_results: int,
) -> None:
    work_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        binary,
        "easy-search",
        str(query_path),
        database_path,
        str(result_path),
        str(work_dir),
        "--max-seqs",
        str(max_results),
        "--format-output",
        ",".join(_LOCAL_RESULT_FIELDS),
    ]
    proc = subprocess.run(
        cmd,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if proc.returncode != 0:
        stderr = (proc.stderr or "").strip()
        stdout = (proc.stdout or "").strip()
        detail = stderr or stdout or f"exit code {proc.returncode}"
        raise RuntimeError(detail)


async def _run_local_foldseek_search(
    loaded_pdb: str,
    database: str,
    max_results: int,
) -> dict[str, Any]:
    binary = (getattr(settings, "FOLDSEEK_BINARY", "") or "").strip()
    database_path = _resolve_local_database_path(database)
    if not binary and not database_path:
        raise LocalFoldseekConfigError("Local Foldseek CLI is not configured.")
    if not binary:
        raise LocalFoldseekConfigError("FOLDSEEK_BINARY is not configured.")
    if not database_path:
        raise LocalFoldseekConfigError(
            f"Foldseek database path is not configured for database '{database}'."
        )

    with tempfile.TemporaryDirectory(prefix="foldseek_search_") as tmp_dir:
        tmp_path = Path(tmp_dir)
        query_path = tmp_path / "query.pdb"
        result_path = tmp_path / "results.tsv"
        work_dir = tmp_path / "work"
        query_path.write_text(loaded_pdb, encoding="utf-8")
        await asyncio.to_thread(
            _execute_local_foldseek_command,
            binary=binary,
            query_path=query_path,
            database_path=database_path,
            result_path=result_path,
            work_dir=work_dir,
            max_results=max_results,
        )
        return {
            "backend": "local_cli",
            "database_path": database_path,
            "results": _parse_local_results(result_path, max_results),
        }


async def structure_search_foldseek(
    pdb_data: str = "",
    pdb_object_name: str = "",
    database: str = "pdb",
    max_results: int = 10,
) -> dict[str, Any]:
    """Search for structural templates using Foldseek when configured.

    Without a configured Foldseek backend this returns a clear degraded result
    with parsed structure context, rather than pretending a search was run.
    """

    loaded_pdb = await _load_pdb_data(pdb_data, pdb_object_name)
    if not loaded_pdb.strip():
        return {
            "found": False,
            "status": "failed",
            "error_code": "MISSING_PDB",
            "error": "Provide pdb_data or pdb_object_name.",
            "results": [],
        }

    max_results = max(1, min(int(max_results or 10), 50))
    endpoint = getattr(settings, "FOLDSEEK_API_URL", "") or ""
    local_database_path = _resolve_local_database_path(database)
    cache_params = {
        "pdb_data": loaded_pdb[:2000],
        "pdb_object_name": pdb_object_name,
        "database": database,
        "max_results": max_results,
        "foldseek_endpoint": endpoint,
        "foldseek_binary": getattr(settings, "FOLDSEEK_BINARY", "") or "",
        "foldseek_database_path": local_database_path,
    }
    cached = await get_cached_result("structure_search_foldseek", cache_params)
    if cached is not None:
        return cached

    if not endpoint:
        try:
            local_payload = await _run_local_foldseek_search(loaded_pdb, database, max_results)
        except LocalFoldseekConfigError:
            local_payload = None
        except Exception as exc:
            stale = await get_cached_result("structure_search_foldseek", cache_params, allow_stale=True)
            if stale is not None:
                stale["status"] = "stale_cache"
                stale["warning"] = (
                    "Foldseek local CLI unavailable; returned cached result. "
                    f"Cause: {exc}"
                )
                stale["backend"] = "local_cli"
                stale.setdefault("cache", {})
                stale["cache"]["stale"] = True
                return stale
            return {
                "found": False,
                "status": "degraded",
                "error_code": "FOLDSEEK_DEGRADED",
                "warning": f"Foldseek local CLI failed: {exc}",
                "backend": "local_cli",
                "database": database,
                "results_count": 0,
                "results": [],
                "query_structure": _structure_summary(loaded_pdb),
                "cache": {"hit": False, "stale": False},
            }

        if local_payload is not None:
            completed = {
                "found": bool(local_payload["results"]),
                "status": "completed",
                "backend": "local_cli",
                "database": database,
                "database_path": local_payload["database_path"],
                "results_count": len(local_payload["results"]),
                "results": local_payload["results"],
                "query_structure": _structure_summary(loaded_pdb),
                "cache": {"hit": False, "stale": False},
            }
            await set_cached_result("structure_search_foldseek", cache_params, completed)
            return completed

        degraded = {
            "found": False,
            "status": "degraded",
            "error_code": "FOLDSEEK_NOT_CONFIGURED",
            "warning": (
                "Foldseek endpoint/local CLI is not configured; returned local structure summary only."
            ),
            "backend": "summary_only",
            "database": database,
            "results_count": 0,
            "results": [],
            "query_structure": _structure_summary(loaded_pdb),
            "cache": {"hit": False, "stale": False},
        }
        await set_cached_result("structure_search_foldseek", cache_params, degraded, ttl_seconds=300)
        return degraded

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(60.0)) as client:
            response = await client.post(
                endpoint.rstrip("/") + "/search",
                json={"pdb": loaded_pdb, "database": database, "max_results": max_results},
            )
            response.raise_for_status()
            payload = response.json()
    except Exception as exc:
        stale = await get_cached_result("structure_search_foldseek", cache_params, allow_stale=True)
        if stale is not None:
            stale["status"] = "stale_cache"
            stale["warning"] = f"Foldseek live query unavailable; returned cached result. Cause: {exc}"
            stale["backend"] = "http"
            stale.setdefault("cache", {})
            stale["cache"]["stale"] = True
            return stale
        return {
            "found": False,
            "status": "degraded",
            "error_code": "FOLDSEEK_DEGRADED",
            "warning": f"Foldseek request failed: {exc}",
            "backend": "http",
            "database": database,
            "results_count": 0,
            "results": [],
            "query_structure": _structure_summary(loaded_pdb),
            "cache": {"hit": False, "stale": False},
        }

    results = payload.get("results") if isinstance(payload, dict) else []
    if not isinstance(results, list):
        results = []

    completed = {
        "found": bool(results),
        "status": "completed",
        "backend": "http",
        "database": database,
        "results_count": len(results),
        "results": results[:max_results],
        "query_structure": _structure_summary(loaded_pdb),
        "cache": {"hit": False, "stale": False},
    }
    await set_cached_result("structure_search_foldseek", cache_params, completed)
    return completed


ToolRegistry.register(
    name="structure_search_foldseek",
    description=(
        "Search for structurally similar templates with Foldseek via remote "
        "endpoint or local CLI when configured. Returns a degraded local "
        "structure summary if Foldseek is unavailable, preserving a stable tool contract."
    ),
    parameters={
        "type": "object",
        "properties": {
            "pdb_data": {"type": "string", "description": "Raw PDB text."},
            "pdb_object_name": {"type": "string", "description": "Stored PDB object name."},
            "database": {
                "type": "string",
                "enum": ["pdb", "alphafold", "custom"],
                "description": "Structure database to search.",
                "default": "pdb",
            },
            "max_results": {
                "type": "integer",
                "minimum": 1,
                "maximum": 50,
                "description": "Maximum number of template hits to return.",
                "default": 10,
            },
        },
    },
    handler=structure_search_foldseek,
    is_async=True,
    category="structure",
    timeout_seconds=60,
)
