"""Multi-dimensional mutation priority scoring for enzyme engineering.

Implements the 5-dimension scoring framework from mutation_design/SKILL.md:
  1. Surface Exposure (ASA %) — weight 0.20
  2. Distance from Active Site (Å) — weight 0.25
  3. Evolutionary Conservation (ConSurf score) — weight 0.25
  4. Mutation ΔΔG (kcal/mol) — weight 0.15
  5. Functional Relevance — weight 0.15

Composite Priority = sum(score_i × weight_i), 0-10 scale.
Tier 1: >7.0  |  Tier 2: 5.0-7.0  |  Tier 3: <5.0
"""

from __future__ import annotations

import math

from app.core.database import session_scope
from app.services.lipase_db_status import build_lipase_evidence_context
from app.tools.catalytic_site_lookup import _infer_catalytic_residues
from app.tools.registry import ToolRegistry

# ---------------------------------------------------------------------------
# Residue property tables
# ---------------------------------------------------------------------------

_AA_LIST = list("ACDEFGHIKLMNPQRSTVWY")
_AA_INDEX: dict[str, int] = {aa: i for i, aa in enumerate(_AA_LIST)}

# Kyte-Doolittle hydropathy (proxy for surface exposure likelihood)
_KD: dict[str, float] = {
    "A": 1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5,
    "E": -3.5, "Q": -3.5, "G": -0.4, "H": -3.2, "I": 4.5,
    "L": 3.8, "K": -3.9, "M": 1.9, "F": 2.8, "P": -1.6,
    "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2,
}

# Side-chain pKa values
_PKA_SIDE: dict[str, float | None] = {
    "D": 3.86, "E": 4.25, "C": 8.33, "Y": 10.0,
    "H": 6.00, "K": 10.53, "R": 12.48,
}

# Residue volumes (Å³)
_AA_VOLUME: dict[str, float] = {
    "A": 88.6, "R": 173.4, "N": 117.7, "D": 111.1, "C": 108.5,
    "Q": 143.9, "E": 138.4, "G": 60.1, "H": 153.2, "I": 166.7,
    "L": 166.7, "K": 168.6, "M": 162.9, "F": 189.9, "P": 122.7,
    "S": 89.0, "T": 116.1, "W": 227.8, "Y": 193.6, "V": 140.0,
}

# Simplified ASA propensity: charged + polar → surface, hydrophobic → buried
# Higher score → higher likelihood of surface exposure
_SURFACE_PROPENSITY: dict[str, float] = {
    "R": 9.0, "K": 8.5, "D": 8.0, "E": 8.0, "N": 7.0, "Q": 7.0,
    "H": 6.5, "S": 6.0, "T": 6.0, "P": 5.5, "G": 5.0,
    "Y": 4.0, "W": 3.5, "M": 3.0, "C": 2.5, "A": 2.0,
    "V": 1.5, "L": 1.0, "I": 1.0, "F": 0.5,
}

# ConSurf-like conservation: frequency-based score from UniProt amino acid distribution
# Higher = more conserved (appears less frequently in nature)
_CONSERVATION_BIAS: dict[str, float] = {
    "W": 9.0, "C": 8.5, "H": 7.5, "M": 7.0, "F": 6.5, "Y": 6.0,
    "P": 5.5, "R": 5.0, "N": 4.5, "Q": 4.5, "D": 4.0, "E": 4.0,
    "G": 3.5, "K": 3.5, "T": 3.0, "S": 2.5, "A": 2.0, "I": 1.5,
    "V": 1.0, "L": 1.0,
}

# Catalytic residue motifs (NEVER mutate these)
_CATALYTIC_MOTIFS: dict[str, list[str]] = {
    "GH13": ["D", "E", "D"],           # α-amylase catalytic triad
    "serine_protease": ["H", "D", "S"],
    "cysteine_protease": ["C", "H", "N"],
    "aspartyl_protease": ["D", "D"],
    "kinase": ["D", "N", "D"],
    "general_acid_base": ["D", "E", "H"],
    "metal_binding": ["H", "C", "D", "E"],
    "disulfide": ["C"],
}

# Known enzyme family active-site motifs (position patterns)
_ACTIVE_SITE_PATTERNS: dict[str, list[dict]] = {
    "GH13_amylase": [
        {"region": "β4 strand", "pattern": "D[AVL][IV][LN]H", "role": "nucleophile"},
        {"region": "β5 strand", "pattern": "G[FY]R[LI][DN]A[AV]K[HN]", "role": "acid/base catalyst"},
        {"region": "β7 strand", "pattern": "F[LI][VA][DN][NH]HD", "role": "transition state stabilizer"},
    ],
}

# Residue categories that MUST NOT be mutated
_NEVER_MUTATE = {
    "catalytic": ["catalytic triad/center residues", 9],
    "metal_binding": ["metal-binding residues (Ca²⁺, Zn²⁺)", 9],
    "disulfide": ["Cys in disulfide bonds", 8],
    "cis_proline": ["cis-Proline residues (structural)", 8],
    "unusual_gly": ["Gly with unusual φ/ψ angles", 7],
    "invariant": ["totally invariant residues across family", 9],
}

# High-value engineering targets
_HIGH_VALUE_TARGETS = {
    "surface_K_R": {"replace": ["E", "D", "Q"], "purpose": "pH lowering", "score_boost": 1.0},
    "surface_G_loop": {"replace": ["P"], "purpose": "thermostability", "score_boost": 1.0},
    "unpaired_C": {"replace": ["A", "S"], "purpose": "remove reactive thiol", "score_boost": 0.5},
    "core_cavity": {"replace": ["I", "L", "V", "F"], "purpose": "fill cavity", "score_boost": 0.5},
    "surface_N_Q": {"replace": ["D", "E"], "purpose": "acid resistance", "score_boost": 0.5},
}


def _score_surface_exposure(aa: str, position: int, seq_len: int) -> tuple[float, str]:
    """Score surface exposure likelihood (0-10).

    Uses hydropathy + charge + positional heuristics.
    N/C-terminal bias: first and last 10% of sequence are more likely exposed.
    """
    base = _SURFACE_PROPENSITY.get(aa, 5.0)

    # N/C-terminal boost (termini tend to be surface-exposed)
    if position <= max(3, seq_len * 0.1):
        base = min(10, base + 2.0)
    elif position >= seq_len - max(2, int(seq_len * 0.1)):
        base = min(10, base + 1.5)

    # Charged residues are almost always surface
    if aa in ("R", "K", "D", "E"):
        base = max(base, 8.0)

    # Very hydrophobic → likely buried
    if aa in ("I", "L", "V", "F", "W") and not (position <= 5 or position >= seq_len - 5):
        base = min(base, 3.0)

    rationale = f"ASA propensity={base:.1f}"
    return base, rationale


def _score_active_site_distance(
    position: int, active_site_positions: list[int], seq_len: int,
) -> tuple[float, str]:
    """Score distance from active site (0-10).

    10: >20 Å (distant, very safe)
    5: 10-20 Å (moderate)
    0: <10 Å (active site proximal — HIGH risk)
    """
    if not active_site_positions:
        # No known active site → assume moderate safety, penalize center
        center = seq_len // 2
        dist_proxy = abs(position - center)
        norm_dist = dist_proxy / (seq_len / 2)
        score = min(10, 5.0 + 5.0 * norm_dist)
        return score, f"no known active site; distance from center proxy={norm_dist:.1f}"

    min_dist = min(abs(position - ap) for ap in active_site_positions)
    # Approximate: 1 residue ≈ 3.8 Å along backbone
    approx_angstrom = min_dist * 3.8

    if approx_angstrom < 8:
        score = 0.0
    elif approx_angstrom < 15:
        score = 5.0
    elif approx_angstrom < 20:
        score = 7.0
    else:
        score = 10.0

    return score, f"~{approx_angstrom:.0f}Å from active site (min {min_dist} residues)"


def _score_conservation(aa: str, position: int, family_conserved: dict[int, str] | None = None) -> tuple[float, str]:
    """Score evolutionary conservation (0-10, reversed).

    10: Variable (safe to mutate) — ConSurf 1-3
    5: Average — ConSurf 4-6
    0: Conserved (DO NOT MUTATE) — ConSurf 7-9

    We invert: low conservation bias → high mutate-ability score.
    """
    # If we know specific conserved positions
    if family_conserved and position in family_conserved:
        return 0.0, f"conserved in family ({family_conserved[position]})"

    # General conservation bias
    cons = _CONSERVATION_BIAS.get(aa, 5.0)
    # Invert: rare amino acids (high conservation bias) → low mutability
    score = max(0.0, 10.0 - cons)
    return score, f"conservation bias={cons:.1f} → mutability={score:.1f}"


def _score_mutation_ddg(aa: str, proposed_mutation: str | None = None) -> tuple[float, str]:
    """Score mutation ΔΔG (0-10).

    10: Stabilizing (ΔΔG < -1.0)
    5: Neutral (-1.0 to +1.0)
    0: Destabilizing (> +1.0, avoid)

    Simplified model based on volume and hydrophobicity changes.
    """
    if proposed_mutation is None:
        return 5.0, "no mutation specified; assumed neutral"

    mt = proposed_mutation
    d_vol = _AA_VOLUME.get(mt, 150.0) - _AA_VOLUME.get(aa, 150.0)
    d_hydro = _KD.get(mt, 0.0) - _KD.get(aa, 0.0)

    # Predict ddG
    ddg = 0.5 + 1.2 * abs(d_vol / 150.0) + 1.0 * (d_hydro / 9.0)

    if ddg < 0.5:
        score = 10.0
        label = "stabilizing"
    elif ddg < 1.5:
        score = 7.0
        label = "mildly stabilizing"
    elif ddg < 2.5:
        score = 4.0
        label = "neutral"
    elif ddg < 4.0:
        score = 1.5
        label = "destabilizing"
    else:
        score = 0.0
        label = "highly destabilizing"

    return score, f"ΔΔG~{ddg:.1f} kcal/mol ({label})"


def _score_functional_relevance(
    aa: str, position: int, active_site_positions: list[int],
    is_charged: bool, family_info: dict | None = None,
) -> tuple[float, str]:
    """Score functional relevance (0-10, reversed).

    10: No known function in the region
    5: Part of a functional domain but not core
    0: Catalytic, substrate-binding, metal-binding, or structurally essential
    """
    # Near active site → high functional relevance → low score
    if active_site_positions:
        min_dist = min(abs(position - ap) for ap in active_site_positions)
        if min_dist <= 2:
            return 0.0, f"adjacent to catalytic residue (dist={min_dist})"
        if min_dist <= 5:
            return 3.0, f"near catalytic residue (dist={min_dist})"

    # Metal-binding residues
    if aa in ("H", "C", "D", "E") and family_info:
        metal_binding = family_info.get("metal_binding_sites", [])
        if position in metal_binding:
            return 0.0, "predicted metal-binding site"

    # Cysteine — potential disulfide
    if aa == "C":
        return 2.0, "Cys — may form disulfide; verify before mutating"

    # Gly with potential unusual angles
    if aa == "G":
        return 4.0, "Gly — may have unusual backbone angles"

    # Charged surface residue → often not functionally critical
    if is_charged:
        return 8.0, "charged surface residue; unlikely functional core"

    return 6.0, "no known functional role in this region"


def _detect_engineering_target_type(aa: str, position: int, seq_len: int, surface_score: float) -> str | None:
    """Detect if this residue is a high-value engineering target type."""
    if surface_score >= 7.0:
        if aa in ("K", "R"):
            return "surface_K_R"
        if aa == "G":
            return "surface_G_loop"
        if aa in ("N", "Q"):
            return "surface_N_Q"
        if aa == "C":
            return "unpaired_C"
    if surface_score <= 3.0 and aa in ("A", "S", "G", "V"):
        return "core_cavity"
    return None


def _identify_category(aa: str, position: int, active_site_positions: list[int]) -> list[str]:
    """Classify a residue into NEVER-MUTATE or HIGH-VALUE categories."""
    categories = []

    # Check NEVER-MUTATE
    if active_site_positions and position in active_site_positions:
        categories.append("catalytic")
    if aa == "C":
        categories.append("potential_disulfide")
    if aa == "P":
        categories.append("potential_cis_proline")
    if aa == "G":
        categories.append("potential_unusual_gly")

    # Check HIGH-VALUE
    if _SURFACE_PROPENSITY.get(aa, 5.0) >= 6.0:
        categories.append("surface_exposed")

    return categories


def _build_engineering_strategy(
    engineering_goal: str,
    *,
    target_ph: float | None = None,
    target_tm: float | None = None,
) -> dict:
    """Return the target-level design logic that sits above residue ranking.

    The score is only a screening signal.  This structured strategy makes the
    intended design direction, guardrails, and experiment order explicit so a
    ranked list cannot be mistaken for a complete engineering plan.
    """
    if engineering_goal == "thermostability":
        return {
            "goal": "thermostability",
            "objective": f"提高热稳定性{f'，目标 Tm {target_tm}°C' if target_tm is not None else ''}，同时尽量保持催化活性、表达和可溶性。",
            "design_principle": "优先加固非催化、可突变的柔性环和局部疏松区域；避免直接改造催化中心及其近邻，先做单点验证，再逐步组合。",
            "screening_logic": [
                "排除催化/金属结合/结构性保护位点及其近邻。",
                "优先筛选表面暴露、保守性较低且远离活性中心的位点。",
                "按具体残基类型选择机制：Gly→Pro 侧重降低 loop 构象熵，疏松核心位点侧重改善 packing，非配对 Cys 侧重降低错误氧化风险。",
                "把活性保持、可溶表达和聚集风险作为反向约束，而不是只按稳定性分数排序。",
            ],
            "preserved_constraints": [
                "催化残基、金属结合位点和已知二硫键 Cys 不进入首轮突变。",
                "任何预测增稳候选都必须复测表达、可溶性、活性和 Tm/残余活性。",
            ],
            "experiment_plan": [
                {"priority": "P1", "scope": "单点候选", "purpose": "先验证最高优先级位点的增稳方向及活性保持", "gate": "表达/可溶性通过，Tm 或热处理残余活性有改善，活性无明显下降"},
                {"priority": "P2", "scope": "第二梯队单点", "purpose": "扩展机制不同的候选，避免只押注同一类突变", "gate": "与 P1 相同，并检查聚集/降解"},
                {"priority": "P3", "scope": "双位点组合", "purpose": "仅组合已通过单点验证且机制互补的位点", "gate": "先做上位性/空间冲突检查，再进入组合实验"},
            ],
            "confidence_boundary": "位点排序是计算筛选假设，不等同于实测 ΔTm；预期幅度需以实验为准。",
        }
    if engineering_goal in {"ph_lowering", "ph_raising"}:
        direction = "降低" if engineering_goal == "ph_lowering" else "提高"
        charge = "正电荷" if engineering_goal == "ph_lowering" else "负电荷"
        return {
            "goal": engineering_goal,
            "objective": f"{direction}酶的最适/耐受 pH{f'，目标 pH {target_ph}' if target_ph is not None else ''}，同时保持催化效率。",
            "design_principle": f"优先调整远离催化核心的表面 {charge} 残基，改变局部电荷和 pKa 环境；活性中心附近只作为高风险备选。",
            "screening_logic": [
                "先锁定催化、金属结合和底物识别的保护位点。",
                "优先选择表面暴露且远离活性中心的电荷位点。",
                "用同一位点的多个替换方向形成小梯度，而不是只押注一个氨基酸。",
                "同时比较目标 pH 和原始 pH 下的活性，识别活性保持与 pH 偏移的权衡。",
            ],
            "preserved_constraints": ["不以牺牲催化残基、底物结合位点或金属配位为代价换取 pH 偏移。"],
            "experiment_plan": [
                {"priority": "P1", "scope": "表面电荷单点梯度", "purpose": "验证 pH 方向是否正确并测量活性保持", "gate": "目标 pH 下活性改善且原始条件活性可接受"},
                {"priority": "P2", "scope": "不同机制的单点", "purpose": "区分电荷、pKa 和局部构象贡献", "gate": "重复实验和稳定性检查通过"},
                {"priority": "P3", "scope": "组合突变", "purpose": "仅组合已验证且不共享同一局部电荷冲突的位点", "gate": "完成上位性和编号复核"},
            ],
            "confidence_boundary": "pH 变化方向和幅度属于计算假设，必须通过 pH-activity 曲线验证。",
        }
    if engineering_goal in {"activity", "specificity"}:
        label = "比活力/催化效率" if engineering_goal == "activity" else "底物特异性"
        return {
            "goal": engineering_goal,
            "objective": f"优化{label}，同时保护整体折叠、表达和热稳定性。",
            "design_principle": "围绕催化中心、底物通道和口袋边缘区分层设计；催化核心保守，优先改变可调节的二壳层/入口位点。",
            "screening_logic": [
                "先确定催化残基和底物结合约束，再筛选邻近但非核心的可调位点。",
                "把结构距离、保守性、替换后的物化性质和已有实验/文献证据交叉判断。",
                "候选需要同时看活性收益、底物谱变化、表达和稳定性风险。",
            ],
            "preserved_constraints": ["催化三联体、金属结合和关键底物锚定位点默认不作为首轮突变。"],
            "experiment_plan": [
                {"priority": "P1", "scope": "口袋边缘/通道单点", "purpose": "先验证方向性和底物谱变化", "gate": "目标底物活性改善且非目标副作用可接受"},
                {"priority": "P2", "scope": "二壳层单点", "purpose": "扩大可调空间并保持折叠", "gate": "表达、稳定性和动力学复核通过"},
                {"priority": "P3", "scope": "组合设计", "purpose": "仅组合机制互补且上位性风险可控的单点", "gate": "完成结构/编号/上位性检查"},
            ],
            "confidence_boundary": "活性和特异性预测对底物、结构和实验条件敏感，候选不能替代动力学实测。",
        }
    return {
        "goal": "general",
        "objective": "在用户约束下寻找可解释、可验证的改造位点。",
        "design_principle": "先保护功能核心，再按暴露度、保守性、结构距离和物化变化筛选候选。",
        "screening_logic": ["候选必须有明确突变逻辑、风险提示和实验优先级。", "不把单一模型分数当作确定性结论。"],
        "preserved_constraints": ["催化、金属结合、二硫键和编号不确定位点需人工复核。"],
        "experiment_plan": [
            {"priority": "P1", "scope": "最高优先级单点", "purpose": "验证候选方向", "gate": "表达、活性和目标性质均需实测"},
            {"priority": "P2", "scope": "第二梯队单点", "purpose": "扩大验证覆盖", "gate": "通过同样的质量门控"},
            {"priority": "P3", "scope": "组合突变", "purpose": "仅组合已验证单点", "gate": "完成上位性检查"},
        ],
        "confidence_boundary": "当前结果用于实验设计排序，不代表已验证的工程效果。",
    }


def _experiment_action_for_goal(engineering_goal: str) -> str:
    """Return a bench-facing validation action for candidate rows."""
    if engineering_goal == "thermostability":
        return "构建单点突变体；与 WT 同批表达纯化；测 Tm/热处理残余活性；同步复测比活、可溶性和聚集风险。"
    if engineering_goal in {"ph_lowering", "ph_raising"}:
        return "构建单点突变体；测 pH-activity 曲线；比较目标 pH 与原始 pH 活性；同步检查稳定性和表达。"
    if engineering_goal == "activity":
        return "构建单点突变体；同批测 WT 与突变体比活；优先补 kcat/Km；同步复测稳定性避免提活降稳。"
    if engineering_goal == "specificity":
        return "构建单点突变体；用目标/非目标底物并行测 kcat/Km 或初速；计算选择性比值并复核表达稳定性。"
    return "构建单点突变体；与 WT 同批表达纯化；按目标性质做主实验，并复测活性、稳定性和可溶性。"


async def _load_curated_catalytic_positions(uniprot_id: str) -> list[int]:
    if not uniprot_id:
        return []

    from sqlalchemy import select
    from sqlalchemy.orm import selectinload
    from app.models.domain import CatalyticSite, EnzymeRecord

    async with session_scope() as session:
        result = await session.execute(
            select(EnzymeRecord)
            .options(selectinload(EnzymeRecord.catalytic_sites).selectinload(CatalyticSite.residues))
            .where(EnzymeRecord.uniprot_id == uniprot_id)
        )
        enzyme = result.scalar_one_or_none()
        if not enzyme:
            return []

        positions = {
            residue.residue_pos
            for site in enzyme.catalytic_sites
            for residue in site.residues
            if residue.residue_pos
        }
        return sorted(positions)


async def mutation_priority_score(
    sequence: str,
    active_site_positions: list[int] | None = None,
    target_ph: float | None = None,
    target_tm: float | None = None,
    engineering_goal: str = "general",
    family_conserved: dict[str, list[int]] | None = None,
    uniprot_id: str = "",
    identity_profile: dict | None = None,
    objective_module_plan: dict | None = None,
    include_lipase_evidence: bool = True,
    lipase_evidence_query: str | None = None,
) -> dict:
    """Score every residue for mutation priority using 5 dimensions.

    Args:
        sequence: Amino acid sequence
        active_site_positions: 1-indexed positions of known catalytic residues
        target_ph: Target pH (for pH engineering context)
        target_tm: Target melting temperature (for thermostability context)
        engineering_goal: "ph_lowering" | "ph_raising" | "thermostability" |
                         "activity" | "specificity" | "general"
        family_conserved: {motif_name: [positions]} of conserved residues
        uniprot_id: optional UniProt accession used to load curated catalytic sites
        identity_profile: optional enzyme_identity_profile output for key-residue guardrails
        objective_module_plan: optional enzyme_objective_module_plan output for target evidence gating
        include_lipase_evidence: enrich recommendations with KWB lipase evidence
        lipase_evidence_query: optional query used for lipase evidence context

    Returns:
        Dict with per-residue scores, tier classification, and recommended mutations.
    """
    seq = sequence.strip().upper()
    n = len(seq)

    # Validation
    if n < 5:
        raise ValueError(f"SEQUENCE_TOO_SHORT: {n} residues; minimum 5 required")
    invalid = set(seq) - set(_AA_LIST)
    if invalid:
        raise ValueError(f"INVALID_AA: {''.join(sorted(invalid))}")

    objective_gate = objective_module_plan if isinstance(objective_module_plan, dict) else {}
    objective_missing = objective_gate.get("missing_evidence", []) if objective_gate else []
    objective_candidate_table_status = (
        "ready"
        if not objective_gate or objective_gate.get("candidate_output_allowed") is True
        else "exploratory_requires_objective_evidence"
    )

    profile = identity_profile if isinstance(identity_profile, dict) else {}
    profile_status = str(profile.get("identity_status") or "")
    profile_guardrail = profile.get("guardrail") if isinstance(profile.get("guardrail"), dict) else {}
    profile_ready = profile_status == "identified" and profile_guardrail.get("status") == "ready"
    profile_positions: list[int] = []
    for value in profile.get("protected_positions", []) if isinstance(profile.get("protected_positions"), list) else []:
        try:
            pos = int(value)
        except (TypeError, ValueError):
            continue
        if 1 <= pos <= n:
            profile_positions.append(pos)

    explicit_active_positions = sorted(set((active_site_positions or []) + profile_positions))
    curated_positions = await _load_curated_catalytic_positions(uniprot_id)
    inferred_positions = []
    if not explicit_active_positions and not curated_positions:
        inferred_positions = sorted({item["position"] for item in _infer_catalytic_residues(seq)})

    active_positions = sorted(set(explicit_active_positions + curated_positions + inferred_positions))
    active_position_sources: dict[int, list[str]] = {}
    for pos in explicit_active_positions:
        active_position_sources.setdefault(pos, []).append("input")
    for pos in curated_positions:
        active_position_sources.setdefault(pos, []).append("curated")
    for pos in inferred_positions:
        active_position_sources.setdefault(pos, []).append("heuristic")
    for pos in profile_positions:
        active_position_sources.setdefault(pos, []).append("identity_profile")

    # Convert family_conserved from {motif: [positions]} to {position: motif}
    conserved_map: dict[int, str] = {}
    if family_conserved:
        for motif, positions in family_conserved.items():
            for p in positions:
                conserved_map[p] = motif

    # Detect engineering context for mutation recommendation
    is_ph_lowering = engineering_goal == "ph_lowering" or (target_ph is not None and target_ph < 7.0)
    is_ph_raising = engineering_goal == "ph_raising" or (target_ph is not None and target_ph > 7.0)
    is_thermo = engineering_goal == "thermostability" or (target_tm is not None)

    results: list[dict] = []
    tier1_count = 0
    tier2_count = 0

    for i, aa in enumerate(seq):
        pos = i + 1  # 1-indexed

        is_charged = aa in ("R", "K", "D", "E", "H")

        # ---- Dimension scores ----
        asa_score, asa_why = _score_surface_exposure(aa, pos, n)
        dist_score, dist_why = _score_active_site_distance(pos, active_positions, n)
        cons_score, cons_why = _score_conservation(aa, pos, conserved_map if conserved_map else None)
        func_score, func_why = _score_functional_relevance(aa, pos, active_positions, is_charged)

        # ---- Composite priority ----
        composite = (
            asa_score * 0.20
            + dist_score * 0.25
            + cons_score * 0.25
            + 5.0 * 0.15      # ddG baseline (no specific mutation yet)
            + func_score * 0.15
        )

        # ---- Adjust for engineering goal ----
        if is_ph_lowering and aa in ("K", "R") and asa_score >= 7.0:
            composite += 1.5  # boost surface K/R for pH lowering
        elif is_ph_lowering and aa in ("H") and dist_score >= 5.0:
            composite += 0.5  # His pH switch near active site
        if is_thermo and aa == "G" and asa_score >= 5.0:
            composite += 1.0  # boost Gly→Pro candidates
        if is_ph_raising and aa in ("D", "E") and asa_score >= 7.0:
            composite += 1.5

        min_active_dist = min((abs(pos - ap) for ap in active_positions), default=999)
        is_protected = pos in active_positions
        if is_protected:
            composite = 0.0
        elif min_active_dist <= 1:
            composite = max(0.0, composite - 4.5)
        elif min_active_dist <= 2:
            composite = max(0.0, composite - 2.5)
        elif min_active_dist <= 4:
            composite = max(0.0, composite - 1.0)

        composite = round(min(10.0, composite), 1)

        # ---- Tier ----
        if is_protected:
            tier = 3
        elif composite >= 7.0:
            tier = 1
            tier1_count += 1
        elif composite >= 5.0:
            tier = 2
            tier2_count += 1
        else:
            tier = 3

        # ---- Categories ----
        categories = _identify_category(aa, pos, active_positions)
        if is_protected and "protected_catalytic" not in categories:
            categories.append("protected_catalytic")
        target_type = _detect_engineering_target_type(aa, pos, n, asa_score)

        # ---- Recommended mutations (no fake predictions) ----
        recommended_mutations = []
        mutation_type = None
        if not is_protected and composite >= 4.0:
            if is_thermo and aa == "G" and asa_score >= 5.0:
                mutation_type = "增加loop刚性"
                recommended_mutations.append({
                    "mutation": f"{aa}{pos}P",
                    "type": mutation_type,
                    "purpose": "Gly→Pro减少主链构象熵，优先用于加固暴露loop；需要确认该位置不是催化/底物通道关键柔性位点",
                })
            elif is_thermo and target_type == "unpaired_C":
                mutation_type = "降低氧化风险"
                recommended_mutations.extend([
                    {
                        "mutation": f"{aa}{pos}S",
                        "type": mutation_type,
                        "purpose": "Cys→Ser移除潜在游离巯基，降低错误氧化和聚集风险；需先排除二硫键作用",
                    },
                    {
                        "mutation": f"{aa}{pos}A",
                        "type": mutation_type,
                        "purpose": "Cys→Ala移除潜在反应性侧链，作为保守的对照方向",
                    },
                ])
            elif is_thermo and target_type == "core_cavity":
                mutation_type = "核心packing优化"
                packing_target = {"A": "V", "S": "V", "G": "A", "V": "I"}.get(aa)
                if packing_target:
                    recommended_mutations.append({
                        "mutation": f"{aa}{pos}{packing_target}",
                        "type": mutation_type,
                        "purpose": f"{aa}→{packing_target}增加局部侧链体积，尝试填补疏松核心；需警惕空间冲突和折叠损失",
                    })
            elif is_thermo and aa in ("K", "R") and asa_score >= 7.0:
                mutation_type = "表面电荷网络优化"
                recommended_mutations.extend([
                    {
                        "mutation": f"{aa}{pos}E",
                        "type": mutation_type,
                        "purpose": "表面K/R→E用于重排表面电荷网络，尝试形成新的盐桥或降低局部电荷斥力；需实验确认不影响表达和活性",
                    },
                    {
                        "mutation": f"{aa}{pos}Q",
                        "type": mutation_type,
                        "purpose": "表面K/R→Q降低局部正电荷和柔性水化扰动，作为较温和的热稳定性验证方向",
                    },
                ])
            elif is_thermo and aa in ("D", "E") and asa_score >= 7.0:
                mutation_type = "表面电荷网络优化"
                recommended_mutations.extend([
                    {
                        "mutation": f"{aa}{pos}K",
                        "type": mutation_type,
                        "purpose": "表面D/E→K用于测试反向盐桥或电荷网络重排的增稳可能；需警惕局部pI和表达变化",
                    },
                    {
                        "mutation": f"{aa}{pos}Q",
                        "type": mutation_type,
                        "purpose": "表面D/E→Q中和局部负电荷，作为较温和的热稳定性验证方向",
                    },
                ])
            elif is_ph_lowering and aa in ("K", "R"):
                mutation_type = "表面电荷翻转"
                for mt in ["E", "D", "Q"]:
                    recommended_mutations.append({
                        "mutation": f"{aa}{pos}{mt}",
                        "type": mutation_type,
                        "purpose": f"将表面正电荷({aa})替换为负电荷或极性残基，降低局部pKa，适应酸性环境",
                    })
            elif is_ph_lowering and aa == "H" and dist_score <= 5.0:
                mutation_type = "活性中心电荷中和"
                for mt in ["N", "F", "Q"]:
                    recommended_mutations.append({
                        "mutation": f"{aa}{pos}{mt}",
                        "type": mutation_type,
                        "purpose": "消除活性中心附近的pH敏感His开关，减少pH依赖的活性波动",
                    })
            elif is_thermo and aa == "G" and asa_score >= 5.0:
                mutation_type = "增加loop刚性"
                recommended_mutations.append({
                    "mutation": f"{aa}{pos}P",
                    "type": mutation_type,
                    "purpose": "Gly→Pro减少主链构象熵，提高loop区刚性，增强热稳定性",
                })
            elif is_ph_raising and aa in ("D", "E"):
                mutation_type = "表面电荷翻转"
                for mt in ["K", "R", "H"]:
                    recommended_mutations.append({
                        "mutation": f"{aa}{pos}{mt}",
                        "type": mutation_type,
                        "purpose": f"将表面负电荷({aa})替换为正电荷残基，提升局部pKa，适应碱性环境",
                    })
            # Fallback for general candidates
            if not recommended_mutations:
                if aa in ("K", "R") and asa_score >= 7.0:
                    mutation_type = "表面电荷优化"
                    recommended_mutations.append({
                        "mutation": f"{aa}{pos}E",
                        "type": mutation_type,
                        "purpose": "表面K/R→E，优化电荷分布，可调节pH适应性",
                    })
                if aa == "G" and asa_score >= 5.0:
                    mutation_type = mutation_type or "loop稳定性"
                    recommended_mutations.append({
                        "mutation": f"{aa}{pos}P",
                        "type": mutation_type,
                        "purpose": "Gly→Pro减少loop柔性，提升整体结构稳定性",
                    })

        # ---- Build Chinese engineering logic ----
        logic_parts = []

        if asa_score >= 7.0:
            logic_parts.append("位于蛋白表面，高度溶剂可及")
        elif asa_score >= 5.0:
            logic_parts.append("部分暴露于溶剂")
        else:
            logic_parts.append("位于蛋白内部，参与疏水核心")

        if active_positions:
            ang = min_active_dist * 3.8
            if is_protected:
                source_text = "/".join(active_position_sources.get(pos, ["guardrail"]))
                logic_parts.append(f"命中催化保护位点({source_text})，默认禁止突变")
            elif ang > 20:
                logic_parts.append(f"远离活性中心(~{ang:.0f}Å)，突变不影响催化功能")
            elif ang > 10:
                logic_parts.append(f"与活性中心距离适中(~{ang:.0f}Å)")
            else:
                logic_parts.append(f"靠近活性中心(~{ang:.0f}Å)，需谨慎设计突变")
        else:
            logic_parts.append("未标注活性中心位置")

        if cons_score >= 7.0:
            logic_parts.append("序列保守性低，可突变空间大")
        elif cons_score >= 4.0:
            logic_parts.append("保守性中等")
        else:
            logic_parts.append("序列高度保守，突变风险较高")

        if func_score >= 7.0:
            logic_parts.append("位于非功能核心区域")
        elif func_score >= 4.0:
            logic_parts.append("可能参与结构维持")
        else:
            logic_parts.append("位于功能关键区域，需谨慎评估")

        if is_ph_lowering and aa in ("K", "R") and asa_score >= 7.0:
            logic_parts.append("表面正电荷残基是pH降低改造的优先靶点")
        elif is_thermo and aa == "G" and asa_score >= 5.0:
            logic_parts.append("Gly→Pro可减少主链构象熵，是热稳定性改造的经典策略")
        elif is_ph_raising and aa in ("D", "E") and asa_score >= 7.0:
            logic_parts.append("表面负电荷残基是pH升高改造的优先靶点")

        logic = "；".join(logic_parts)

        risk_flags: list[str] = []
        if is_protected:
            risk_flags.append("催化/功能保护位点，禁止作为首轮候选")
        elif min_active_dist <= 4:
            risk_flags.append("靠近活性中心，需复核催化和底物结合影响")
        if aa == "C":
            risk_flags.append("需确认是否参与二硫键或金属配位")
        if aa == "G" and is_thermo:
            risk_flags.append("Gly→Pro可能误伤必要柔性")
        if target_type == "core_cavity":
            risk_flags.append("核心packing改变可能造成空间冲突或表达下降")
        if not recommended_mutations and not is_protected:
            risk_flags.append("当前仅支持位点级排序，尚未形成可信的具体替换方向")
        if objective_candidate_table_status != "ready" and not is_protected:
            risk_flags.append("目标实验上下文不足，候选为探索性排单，需先补基线/对照实验")

        if is_protected:
            experiment_priority = "No-Go"
        elif tier == 1 and recommended_mutations:
            experiment_priority = "P1"
        elif tier == 2 and recommended_mutations:
            experiment_priority = "P2"
        else:
            experiment_priority = "P3"

        if engineering_goal == "thermostability":
            expected_effect = "候选用于提高局部结构稳定性；Tm/热处理残余活性需实验确认"
        elif engineering_goal in {"ph_lowering", "ph_raising"}:
            expected_effect = "候选用于改变局部电荷/pKa环境；pH-activity曲线和活性保持需实验确认"
        elif engineering_goal == "specificity":
            expected_effect = "候选用于调整底物通道或口袋微环境；底物谱变化需动力学实测"
        elif engineering_goal == "activity":
            expected_effect = "候选用于改善催化效率或底物进入；kcat/Km和稳定性需实验确认"
        else:
            expected_effect = "候选改造方向需结合目标性质和实验数据确认"

        results.append({
            "position": pos,
            "user_position": pos,
            "pdb_position": None,
            "uniprot_position": None,
            "numbering_status": "user_sequence_only",
            "wild_type": aa,
            "scores": {
                "surface_exposure": round(asa_score, 1),
                "active_site_distance": round(dist_score, 1),
                "conservation_mutability": round(cons_score, 1),
                "functional_relevance": round(func_score, 1),
            },
            "composite_priority": composite,
            "tier": tier,
            "categories": categories,
            "target_type": target_type,
            "is_protected": is_protected,
            "active_site_distance_residues": None if min_active_dist == 999 else min_active_dist,
            "active_site_sources": active_position_sources.get(pos, []),
            "recommended_mutations": recommended_mutations,
            "mutation_type": mutation_type,
            "logic": logic,
            "design_logic": logic,
            "expected_effect": expected_effect,
            "risk_flags": risk_flags,
            "experiment_action": _experiment_action_for_goal(engineering_goal),
            "experiment_priority": experiment_priority,
            "candidate_evidence_status": objective_candidate_table_status,
            "objective_missing_evidence": objective_missing[:5] if isinstance(objective_missing, list) else [],
        })

    # Sort by composite score descending (best candidates first)
    results.sort(key=lambda r: r["composite_priority"], reverse=True)

    lipase_evidence_context: dict | None = None
    if include_lipase_evidence:
        recommended_codes = sorted(
            {
                str(item.get("mutation") or "")
                for row in results
                for item in row.get("recommended_mutations", [])
                if item.get("mutation")
            }
        )
        candidate_positions = [int(row["position"]) for row in results if row["tier"] in {1, 2}]
        lipase_evidence_context = build_lipase_evidence_context(
            mutations=recommended_codes,
            positions=candidate_positions[:100],
            q=lipase_evidence_query or engineering_goal,
            limit=50,
        )
        exact_by_mutation: dict[str, list[dict]] = {}
        for match in lipase_evidence_context.get("exact_mutation_matches") or []:
            code = str(match.get("mutation_code") or "").upper()
            exact_by_mutation.setdefault(code, []).append(match)
        position_counts: dict[int, int] = {}
        for match in lipase_evidence_context.get("position_matches") or []:
            try:
                position = int(match.get("position"))
            except (TypeError, ValueError):
                continue
            position_counts[position] = position_counts.get(position, 0) + 1

        for row in results:
            row["lipase_position_evidence_count"] = position_counts.get(int(row["position"]), 0)
            for recommendation in row.get("recommended_mutations", []):
                code = str(recommendation.get("mutation") or "").upper()
                matches = exact_by_mutation.get(code, [])
                recommendation["lipase_evidence"] = {
                    "exact_match_count": len(matches),
                    "matches": matches[:3],
                    "source": "kwb_lipase_db",
                    "interpretation": (
                        "exact literature evidence exists for this mutation in the KWB lipase database"
                        if matches
                        else "no exact mutation evidence found in the KWB lipase database"
                    ),
                }

    # Tier summaries
    tier1 = [r for r in results if r["tier"] == 1]
    tier2 = [r for r in results if r["tier"] == 2]
    never_mutate = [r for r in results if "catalytic" in r["categories"]]
    identity_gate = {
        "status": "passed" if profile_ready else "blocked",
        "identity_status": profile_status or None,
        "reason": (
            None if profile_ready else (
                "enzyme_identity_profile is required before P1/P2 mutation ranking"
                if not profile else "enzyme identity or residue numbering is not confirmed enough for P1/P2 mutation ranking"
            )
        ),
        "protected_positions_from_profile": profile_positions,
    }
    if identity_gate["status"] == "blocked":
        tier1 = []
        tier2 = []
        tier1_count = 0
        tier2_count = 0

    return {
        "sequence_length": n,
        "sequence_preview": seq[:60] + ("..." if n > 60 else ""),
        "engineering_goal": engineering_goal,
        "strategy": _build_engineering_strategy(
            engineering_goal,
            target_ph=target_ph,
            target_tm=target_tm,
        ),
        "target_ph": target_ph,
        "target_tm": target_tm,
        "uniprot_id": uniprot_id or None,
        "active_site_positions": active_positions,
        "active_site_position_sources": active_position_sources,
        "identity_gate": identity_gate,
        "objective_gate": {
            "status": objective_gate.get("status") if objective_gate else None,
            "objective": objective_gate.get("objective") if objective_gate else engineering_goal,
            "module": objective_gate.get("module") if objective_gate else None,
            "candidate_output_allowed": objective_gate.get("candidate_output_allowed") if objective_gate else True,
            "missing_evidence": objective_missing if isinstance(objective_missing, list) else [],
            "ranking_boundary": objective_gate.get("ranking_boundary") if objective_gate else None,
        },
        "candidate_table_status": (
            objective_candidate_table_status if identity_gate["status"] == "passed" else "blocked_by_identity_gate"
        ),
        "summary": {
            "total_positions": n,
            "tier_1_count": tier1_count,
            "tier_2_count": tier2_count,
            "tier_3_count": n - tier1_count - tier2_count,
            "never_mutate_count": len(never_mutate),
            "never_mutate_positions": [r["position"] for r in never_mutate],
            "catalytic_guardrail_enabled": len(active_positions) > 0,
            "identity_gate_status": identity_gate["status"],
            "candidate_table_status": (
                objective_candidate_table_status if identity_gate["status"] == "passed" else "blocked_by_identity_gate"
            ),
        },
        "guardrails": {
            "protected_positions": active_positions,
            "sources": active_position_sources,
            "rule": "Protected catalytic positions and adjacent residues are penalized or blocked from recommendation.",
        },
        "lipase_evidence_context": lipase_evidence_context,
        "tier_1_candidates": [
            {
                "position": r["position"],
                "user_position": r.get("user_position"),
                "pdb_position": r.get("pdb_position"),
                "uniprot_position": r.get("uniprot_position"),
                "numbering_status": r.get("numbering_status"),
                "wild_type": r["wild_type"],
                "composite_priority": r["composite_priority"],
                "tier": 1,
                "mutation_type": r["mutation_type"],
                "logic": r["logic"],
                "recommended_mutations": r["recommended_mutations"],
                "active_site_distance_residues": None if r["active_site_distance_residues"] == 999 else r["active_site_distance_residues"],
                "expected_effect": r["expected_effect"],
                "risk_flags": r["risk_flags"],
                "experiment_action": r.get("experiment_action"),
                "experiment_priority": r["experiment_priority"],
                "candidate_evidence_status": r.get("candidate_evidence_status"),
                "objective_missing_evidence": r.get("objective_missing_evidence", []),
                "lipase_position_evidence_count": r.get("lipase_position_evidence_count", 0),
            }
            for r in tier1
        ],
        "tier_2_candidates": [
            {
                "position": r["position"],
                "user_position": r.get("user_position"),
                "pdb_position": r.get("pdb_position"),
                "uniprot_position": r.get("uniprot_position"),
                "numbering_status": r.get("numbering_status"),
                "wild_type": r["wild_type"],
                "composite_priority": r["composite_priority"],
                "tier": 2,
                "mutation_type": r["mutation_type"],
                "logic": r["logic"],
                "recommended_mutations": r["recommended_mutations"],
                "active_site_distance_residues": None if r["active_site_distance_residues"] == 999 else r["active_site_distance_residues"],
                "expected_effect": r["expected_effect"],
                "risk_flags": r["risk_flags"],
                "experiment_action": r.get("experiment_action"),
                "experiment_priority": r["experiment_priority"],
                "candidate_evidence_status": r.get("candidate_evidence_status"),
                "objective_missing_evidence": r.get("objective_missing_evidence", []),
                "lipase_position_evidence_count": r.get("lipase_position_evidence_count", 0),
            }
            for r in tier2
        ],
        "experiment_design_table": [
            {
                "experiment_priority": r["experiment_priority"],
                "tier": r["tier"],
                "position": r["position"],
                "user_position": r.get("user_position"),
                "pdb_position": r.get("pdb_position"),
                "uniprot_position": r.get("uniprot_position"),
                "numbering_status": r.get("numbering_status"),
                "wild_type": r["wild_type"],
                "recommended_mutations": [m.get("mutation") for m in r.get("recommended_mutations", []) if m.get("mutation")],
                "mutation_logic": r["logic"],
                "expected_effect": r["expected_effect"],
                "risk_flags": r["risk_flags"],
                "experiment_action": r.get("experiment_action"),
                "candidate_evidence_status": r.get("candidate_evidence_status"),
                "objective_missing_evidence": r.get("objective_missing_evidence", []),
            }
            for r in (tier1 + tier2)[:20]
        ],
        "all_positions": results if identity_gate["status"] == "passed" else [],
    }


# ===================================================================
# Registration
# ===================================================================

ToolRegistry.register(
    name="mutation_priority_score",
    description=(
        "Multi-dimensional mutation priority scoring for enzyme engineering. "
        "Scores every residue on 5 dimensions: surface exposure, distance from "
        "active site, evolutionary conservation, functional relevance, and "
        "predicted ΔΔG. Weights: ASA(0.20), Distance(0.25), Conservation(0.25), "
        "ΔΔG(0.15), Functional(0.15). Returns Tier 1 (>7.0) and Tier 2 (5.0-7.0) "
        "candidates with mutation positions, Chinese engineering logic, specific "
        "recommended mutations, and priority scores. "
        "Use for pH engineering, thermostability, or general mutation design."
    ),
    parameters={
        "type": "object",
        "properties": {
            "sequence": {
                "type": "string",
                "description": "Amino acid sequence (single-letter code)",
            },
            "active_site_positions": {
                "type": "array",
                "items": {"type": "integer"},
                "description": (
                    "1-indexed positions of known catalytic residues. "
                    "Residues at these positions are flagged as NEVER-MUTATE."
                ),
            },
            "target_ph": {
                "type": "number",
                "description": "Target optimal pH for enzyme engineering",
            },
            "target_tm": {
                "type": "number",
                "description": "Target melting temperature (°C) for thermostability engineering",
            },
            "engineering_goal": {
                "type": "string",
                "enum": ["ph_lowering", "ph_raising", "thermostability", "activity", "specificity", "general"],
                "description": "Engineering objective — determines mutation recommendations",
                "default": "general",
            },
            "family_conserved": {
                "type": "object",
                "description": (
                    "Known conserved motifs as {motif_name: [positions]}. "
                    "Residues in these positions get conservation score=0."
                ),
            },
            "uniprot_id": {
                "type": "string",
                "description": (
                    "Optional UniProt accession. If provided, the tool loads curated "
                    "catalytic residues from the local database and applies them as "
                    "hard mutation guardrails."
                ),
            },
            "identity_profile": {
                "type": "object",
                "description": "Optional enzyme_identity_profile output used to gate and protect key residues.",
            },
            "objective_module_plan": {
                "type": "object",
                "description": "Optional enzyme_objective_module_plan output. Blocks candidate tables unless candidate_output_allowed=true.",
            },
            "include_lipase_evidence": {
                "type": "boolean",
                "description": "Attach read-only KWB lipase literature evidence to recommended mutations.",
                "default": True,
            },
            "lipase_evidence_query": {
                "type": "string",
                "description": "Optional KWB lipase evidence search query, e.g. CALB, thermostability, D223G.",
            },
        },
        "required": ["sequence"],
    },
    handler=mutation_priority_score,
    category="engineering",
    timeout_seconds=60,
    errors=[
        {
            "reason": "invalid_input",
            "code": "SEQUENCE_TOO_SHORT",
            "when": "sequence length < 5 residues",
            "recovery": "Provide a protein sequence of at least 5 amino acids.",
        },
        {
            "reason": "validation_failed",
            "code": "INVALID_AA",
            "when": "sequence contains non-standard amino acid characters",
            "recovery": "Use only the 20 standard letters (ACDEFGHIKLMNPQRSTVWY).",
        },
    ],
)
