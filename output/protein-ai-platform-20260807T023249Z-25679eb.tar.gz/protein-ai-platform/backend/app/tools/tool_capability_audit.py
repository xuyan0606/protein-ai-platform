"""Runtime/capability audit for tool outputs.

This is a product-safety layer: it prevents tool names from being interpreted as
proof that official model weights, databases, or command-line runtimes ran.
"""

from __future__ import annotations

from typing import Any

from app.tools.registry import ToolRegistry


_CAPABILITIES: dict[str, dict[str, Any]] = {
    "annotation_bundle": {
        "capability_status": "evidence_synthesis",
        "boundary": "Aggregates curated/local annotations and conservative predictions; not a live BLAST/InterProScan substitute.",
        "minimum_artifacts": ["record provenance", "coordinate status", "source versions when available"],
    },
    "enzyme_identity_profile": {
        "capability_status": "evidence_synthesis",
        "boundary": "Foundation profile and guardrail; short motifs are clues, not family proof.",
        "minimum_artifacts": ["family candidates", "key residues", "numbering status", "evidence table"],
    },
    "protein_benchmark": {
        "capability_status": "foundation_dependent_explainer",
        "boundary": "Explains confirmed families only after enzyme_identity_profile guardrail is ready.",
        "minimum_artifacts": ["identity_profile reference", "foundation_gate"],
    },
    "mutation_priority_score": {
        "capability_status": "proxy_ranker",
        "boundary": "Rule/model-assisted candidate ranking; not wet-lab evidence and not a Rosetta/ddG/pKa calculation.",
        "minimum_artifacts": ["identity_gate", "protected positions", "ranking rationale"],
    },
    "kcat_predict": {
        "capability_status": "proxy",
        "boundary": "Heuristic/statistical estimate; must not be presented as calibrated quantitative kcat without model card and validation artifacts.",
        "minimum_artifacts": ["model card or proxy label", "training/validation scope", "input hash"],
    },
    "protssn_score": {
        "capability_status": "proxy",
        "boundary": "Sequence/structure-neighborhood scoring proxy unless real model/runtime artifact is attached.",
        "minimum_artifacts": ["runtime type", "model version", "score provenance"],
    },
    "alphafold2_folding": {
        "capability_status": "proxy",
        "boundary": "Current local entry is not official AlphaFold2 inference unless MSA, weights, logs, and structure artifacts are present.",
        "minimum_artifacts": ["model version", "MSA/template provenance", "PDB/mmCIF", "PAE/pLDDT", "logs"],
    },
    "alphafold_folding": {
        "capability_status": "proxy_or_external_lookup",
        "boundary": "Must distinguish AlphaFold DB lookup from true folding inference.",
        "minimum_artifacts": ["source", "database version or runtime logs", "structure artifact"],
    },
    "esmfold_folding": {
        "capability_status": "runtime_unverified",
        "boundary": "Can support structure interpretation only when runtime/model version and output PDB are recorded.",
        "minimum_artifacts": ["model version", "PDB", "pLDDT", "logs"],
    },
    "rfdiffusion_design": {
        "capability_status": "proxy",
        "boundary": "Not report-grade RFdiffusion unless official checkpoint, run_inference config, PDB/TRB/trajectory artifacts exist.",
        "minimum_artifacts": ["checkpoint hash", "Hydra config", "backbone PDB", "TRB", "trajectory", "GPU runtime"],
    },
    "proteinmpnn_design": {
        "capability_status": "proxy",
        "boundary": "Not report-grade ProteinMPNN unless official weights and protein_mpnn_run.py outputs are recorded.",
        "minimum_artifacts": ["checkpoint/model", "fixed/designed chains", "FASTA", "scores", "seed", "logs"],
    },
    "diffdock_docking": {
        "capability_status": "proxy",
        "boundary": "DiffDock confidence is pose confidence, not affinity; current simplified entry must not be called real DiffDock without artifacts.",
        "minimum_artifacts": ["model version", "3D ligand source", "pose ensemble", "confidence", "logs"],
    },
    "ligand_preprocess": {
        "capability_status": "real_runtime_gated",
        "boundary": "Real OpenBabel/Vina/ACPYPE stages only when runtimes exist; missing runtimes must return blocked.",
        "minimum_artifacts": ["stage results", "tool versions", "PDBQT/pose/topology files", "logs"],
    },
    "rosetta_ddg": {
        "capability_status": "real_runtime_gated",
        "boundary": "Real Rosetta only when runtime and structure are available; local estimate is explicitly non-Rosetta.",
        "minimum_artifacts": ["Rosetta binary", "mutation file", "scorefile", "logs"],
    },
    "gromacs_md": {
        "capability_status": "real_runtime_gated",
        "boundary": "Real MD only when GROMACS preprocessing and mdrun artifacts exist; plan-only is not MD evidence.",
        "minimum_artifacts": ["MDP", "TPR", "XTC/TRR", "EDR/XVG", "stdout/stderr", "runtime versions"],
    },
}


def tool_capability_audit(tool_names: list[str] | None = None) -> dict[str, Any]:
    """Return capability status and minimum artifacts for selected tools."""
    names = tool_names if isinstance(tool_names, list) and tool_names else sorted(_CAPABILITIES)
    rows = []
    unknown = []
    for name in names:
        key = str(name)
        capability = _CAPABILITIES.get(key)
        if not capability:
            unknown.append(key)
            rows.append({
                "tool": key,
                "capability_status": "unknown",
                "boundary": "No capability audit entry exists yet; do not promote outputs as report-grade evidence.",
                "minimum_artifacts": ["capability audit entry"],
                "report_action": "block_report_grade_claims",
            })
            continue
        status = capability["capability_status"]
        rows.append({
            "tool": key,
            **capability,
            "report_action": (
                "allow_with_artifacts"
                if status in {"real_runtime_gated", "evidence_synthesis", "foundation_dependent_explainer"}
                else "label_as_proxy_or_block_until_artifacts_exist"
            ),
        })
    return {
        "status": "ready" if not unknown else "partial",
        "capabilities": rows,
        "unknown_tools": unknown,
        "rules": {
            "real_runtime": "Requires versioned runtime, command/config, logs, and output artifacts.",
            "proxy": "May support triage only; must not be phrased as official model inference.",
            "blocked": "Missing runtime or input evidence must block report-grade conclusions.",
        },
    }


ToolRegistry.register(
    name="tool_capability_audit",
    description=(
        "Return capability_status, scientific boundary, and minimum artifact requirements "
        "for protein R&D tools so reports distinguish real runtime, external service, proxy, and blocked states."
    ),
    parameters={
        "type": "object",
        "properties": {
            "tool_names": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional list of tool names to audit. Defaults to all audited tools.",
            }
        },
    },
    handler=tool_capability_audit,
    category="analysis",
    timeout_seconds=30,
)
