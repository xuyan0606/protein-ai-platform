import pandas as pd
import numpy as np
import os
import subprocess
import sys

# 计算距离
trj = "pull.xtc"
tpr = "pull.tpr"
ndx = "pull.ndx"
grp1 = "YI"
grp2 = "ER"

print("Calculating distance between {} and {}...".format(grp1, grp2))

# 使用subprocess运行命令，可以捕获错误
def run_command(cmd):
    print(f"Running: {cmd}")
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error: {result.stderr}")
            return False
        return True
    except Exception as e:
        print(f"Exception: {e}")
        return False

# 计算距离
cmd = f'gmx pairdist -f {trj} -s {tpr} -n {ndx} -ref "com of group {grp1}" -sel "com of group {grp2}" -o dist.xvg -quiet'
if not run_command(cmd):
    print("Failed to calculate distance. Exiting.")
    sys.exit(1)

def read_csv_skip_comments(file_path):
    # 定义一个函数来判断是否应该跳过某行
    def skip_line(line):
        line = line.strip()
        return (not line) or line.startswith('#') or line.startswith('@')
    
    # 使用生成器逐行读取文件，跳过不需要的行
    with open(file_path, 'r') as f:
        lines = [line for line in f if not skip_line(line)]
    
    # 使用pd.read_csv读取处理后的内容
    with open("dist-temp.csv", "w") as f:
        f.writelines("Time(ps) Distance(nm)\n")
        f.writelines(''.join(lines))
    df = pd.read_csv("dist-temp.csv", sep=r'\s+')
    
    return df

# 读取距离数据
file_path = 'dist.xvg'
data = read_csv_skip_comments(file_path)
print(f"Read {len(data)} data points from {file_path}")

# 显示距离范围
min_dist = data.iloc[:, 1].min()
max_dist = data.iloc[:, 1].max()
print(f"Distance range in trajectory: {min_dist:.3f} to {max_dist:.3f} nm")

# 根据实际距离范围设置默认值
default_start = max(0.1, round(min_dist - 0.1, 1))
default_end = round(max_dist + 0.1, 1)

# 获取用户输入，但根据实际距离范围提供合理的默认值
dist_range_input = input(f"Input distance range splitted by \"-\" (unit: nm), suggested: {default_start:.1f}-{default_end:.1f}: ") or f"{default_start:.1f}-{default_end:.1f}"
start, end = dist_range_input.split("-")
start = float(start.strip())
end = float(end.strip())

# 确保输入范围在轨迹距离范围内
if start < min_dist:
    print(f"Warning: Start distance {start} nm is less than minimum distance {min_dist:.3f} nm in trajectory.")
    print(f"Using {min_dist:.1f} nm as start distance.")
    start = min_dist

if end > max_dist:
    print(f"Warning: End distance {end} nm is greater than maximum distance {max_dist:.3f} nm in trajectory.")
    print(f"Using {max_dist:.1f} nm as end distance.")
    end = max_dist

window = input("Input sampling window length (unit: nm, usually 0.1-0.2 nm), default 0.1: ") or "0.1"
window = float(window)
tolerance = input("Input distance tolerance (unit: nm), default {}: ".format(window / 10)) or window / 10
tolerance = float(tolerance)
centers = np.arange(start, end, window)

print(f"Sampling from {start:.1f} to {end:.1f} nm, window = {window} nm, {len(centers)} windows")

def find_best_match_in_window(data_dist, data_time, centers, tolerance):
    """为每个窗口中心找到最接近的时间点，确保实际距离在目标距离附近"""
    indices = []
    times = []
    dists = []
    actual_target_diffs = []  # 实际距离与目标距离的差异
    
    # 确保数据按时间排序
    data_sorted = data.sort_values('Time(ps)')
    distances = data_sorted.iloc[:, 1].values
    times_all = data_sorted.iloc[:, 0].values
    
    # 用于记录已经使用过的时间点，避免重复
    used_indices = set()
    
    for i, target_center in enumerate(centers):
        # 计算每个数据点与目标中心的距离差
        dist_diffs = np.abs(distances - target_center)
        
        # 找出在容忍度范围内的所有点
        valid_indices = np.where(dist_diffs < tolerance)[0]
        
        # 过滤掉已经使用过的点
        valid_indices = [idx for idx in valid_indices if idx not in used_indices]
        
        if valid_indices:
            # 选择距离目标中心最近的点
            best_idx = valid_indices[np.argmin(dist_diffs[valid_indices])]
            indices.append(best_idx)
            times.append(times_all[best_idx])
            dists.append(distances[best_idx])
            actual_target_diffs.append(dist_diffs[best_idx])
            used_indices.add(best_idx)
            print(f"  Window {i+1}/{len(centers)}: target={target_center:.2f}nm, found={distances[best_idx]:.3f}nm at {times_all[best_idx]}ps (diff={dist_diffs[best_idx]:.3f}nm)")
        else:
            # 没有找到合适的点
            indices.append(-1)
            times.append(np.nan)
            dists.append(np.nan)
            actual_target_diffs.append(np.nan)
            print(f"  Window {i+1}/{len(centers)}: target={target_center:.2f}nm, NO MATCH found within tolerance {tolerance}nm")
    
    return np.array(indices), np.array(times), np.array(dists), np.array(actual_target_diffs)

indices, times, dists, diffs = find_best_match_in_window(data.iloc[:, 1], data.iloc[:, 0], centers, tolerance)

# 过滤掉无效的（NaN）数据点
valid_mask = ~np.isnan(times)
valid_times = times[valid_mask]
valid_dists = dists[valid_mask]
valid_centers = centers[valid_mask]
valid_diffs = diffs[valid_mask]

print(f"\nFound {len(valid_times)} valid frames out of {len(centers)} windows")

# 如果没有找到任何有效的帧，退出
if len(valid_times) == 0:
    print("Error: No frames found within the specified distance range and tolerance.")
    print("Try increasing the tolerance or adjusting the distance range.")
    sys.exit(1)

# 创建输出目录
output_dir = "extracted_frames"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 提取构象帧
print("\nExtracting frames...")
successful_extractions = 0
for i, (time_point, target_dist, actual_dist) in enumerate(zip(valid_times, valid_centers, valid_dists)):
    print(f"Extracting frame {i+1}/{len(valid_times)}: time={time_point} ps, target={target_dist:.2f}nm, actual={actual_dist:.3f}nm")
    
    # 构建输出文件名
    output_file = os.path.join(output_dir, f"conf_{i:03d}_t{int(time_point)}_target{target_dist:.2f}_actual{actual_dist:.3f}.gro")
    
    # 构建命令 - 添加-b和-e参数确保正确提取
    cmd = f"echo 0 | gmx trjconv -f {trj} -s {tpr} -n {ndx} -b {max(0, time_point-1)} -e {time_point+1} -dump {time_point} -o {output_file} -quiet"
    
    # 执行命令并显示输出
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"  Error extracting frame at time {time_point} ps:")
        # 只显示错误的前200个字符
        error_msg = result.stderr[:200] if result.stderr else "Unknown error"
        print(f"  {error_msg}")
    else:
        # 检查文件是否创建成功
        if os.path.exists(output_file):
            file_size = os.path.getsize(output_file)
            print(f"  Success: {output_file} ({file_size} bytes)")
            successful_extractions += 1
        else:
            print(f"  Warning: Command succeeded but {output_file} was not created")

print("\n" + "="*50)
print(f"Extracted {start:.1f} to {end:.1f} nm, window = {window} nm, tolerance = {tolerance} nm")
print(f"Successfully extracted {successful_extractions} out of {len(valid_times)} frames")

# 创建结果数据框
df = pd.DataFrame({
    "Target_Distance_nm": valid_centers,
    "Time_ps": valid_times,
    "Actual_Distance_nm": valid_dists,
    "Difference_nm": valid_diffs,
    "File": [f"conf_{i:03d}_t{int(t)}_target{c:.2f}_actual{d:.3f}.gro" 
             for i, (t, c, d) in enumerate(zip(valid_times, valid_centers, valid_dists))]
})

print("\nExtracted frames summary:")
print(df[["Target_Distance_nm", "Time_ps", "Actual_Distance_nm", "Difference_nm"]])

# 保存结果 - 添加错误处理
try:
    # 如果文件已存在，先删除它
    if os.path.exists("extract_frames.csv"):
        os.remove("extract_frames.csv")
    
    df.to_csv("extract_frames.csv", index=None, float_format='%.3f')
    print(f"\nNote: Table saved to extract_frames.csv")
except PermissionError as e:
    print(f"\nError: Cannot save to extract_frames.csv - Permission denied")
    print(f"Trying to save to extract_frames_new.csv instead...")
    try:
        df.to_csv("extract_frames_new.csv", index=None, float_format='%.3f')
        print(f"Table saved to extract_frames_new.csv")
    except Exception as e2:
        print(f"Failed to save to any file: {e2}")

print(f"Frames saved to {output_dir}/ directory")

# 如果有些窗口没有找到帧，显示警告
if len(valid_times) < len(centers):
    missing = len(centers) - len(valid_times)
    print(f"\nWarning: Could not find frames for {missing} windows")
    print("This may be because:")
    print("1. The distance range doesn't cover all windows")
    print("2. The tolerance is too small")
    print("3. The trajectory doesn't have enough frames in those distance ranges")
    
    # 显示缺失的窗口
    missing_mask = np.isnan(times)
    missing_centers = centers[missing_mask]
    if len(missing_centers) > 0:
        print(f"\nMissing windows (target distances):")
        for center in missing_centers:
            print(f"  {center:.2f} nm")

# 显示统计信息
print("\n" + "="*50)
print("SUMMARY:")
print(f"Total windows: {len(centers)}")
print(f"Frames found: {len(valid_times)}")
print(f"Frames extracted: {successful_extractions}")
print(f"Average difference between target and actual distance: {np.mean(valid_diffs):.3f} nm")
print(f"Maximum difference: {np.max(valid_diffs):.3f} nm")
print(f"Minimum difference: {np.min(valid_diffs):.3f} nm")